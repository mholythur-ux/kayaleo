#!/usr/bin/env bash
# ============================================================
# KAYA LEO — API smoke test (run against a demo-mode server)
# Usage:  DATA_MODE=demo npm run dev   then   npm run smoke
# Exercises every major journey: signup → profile → host apply
# → create listing → admin approve → public search → favorites
# → messaging → review → inquiry → report → moderation.
# ============================================================
set -u
BASE="${BASE:-http://localhost:4000/api}"
PASS=0; FAIL=0
BODY=/tmp/kayaleo_last_body.json

req() { # method path token json_body
  local method="$1" path="$2" token="${3:-}" body="${4:-}"
  local args=(-s -w '\n%{http_code}' -X "$method" "$BASE$path" -H 'Content-Type: application/json')
  [ -n "$token" ] && args+=(-H "Authorization: Bearer $token")
  [ -n "$body" ] && args+=(-d "$body")
  curl "${args[@]}"
}

check() { # name expected_status response  → writes response body to $BODY
  local name="$1" expected="$2" resp="$3"
  local code; code="$(echo "$resp" | tail -1)"
  local body; body="$(echo "$resp" | sed '$d')"
  echo "$body" > "$BODY"
  if [ "$code" = "$expected" ]; then
    PASS=$((PASS+1)); echo "✔ $name ($code)"
  else
    FAIL=$((FAIL+1)); echo "✘ $name (expected $expected, got $code): $body"
  fi
}

assert() { # name condition_result (0/1)
  if [ "$2" = "0" ]; then PASS=$((PASS+1)); echo "✔ $1"; else FAIL=$((FAIL+1)); echo "✘ $1"; fi
}

echo "== Kaya Leo smoke test → $BASE =="

R=$(req GET /health); check "health" 200 "$R"

# --- public browsing ---
R=$(req GET /amenities); check "list amenities" 200 "$R"
R=$(req GET "/properties?page_size=5&sort=newest"); check "list public properties" 200 "$R"
PROP=$(jq -r '.items[0].id' "$BODY")
R=$(req GET "/properties?q=Mikocheni"); check "search by neighborhood (Mikocheni)" 200 "$R"
R=$(req GET "/properties?property_type=ROOM"); check "filter by type ROOM" 200 "$R"
R=$(req GET "/properties?max_price=300000&sort=price_asc"); check "filter max price + sort" 200 "$R"
R=$(req GET "/properties/$PROP"); check "property details" 200 "$R"
R=$(req GET "/properties/$PROP/reviews"); check "property reviews" 200 "$R"
R=$(req GET /location/regions); check "curated regions" 200 "$R"

# --- signup / profile ---
EMAIL="test$(date +%s)@kayaleo.app"
R=$(req POST /auth/register "" "{\"full_name\":\"Neema Test\",\"phone\":\"+255 700 111 222\",\"email\":\"$EMAIL\",\"password\":\"secret1234\"}")
check "register new user" 201 "$R"
USER=$(jq -r '.user.id' "$BODY"); TOKEN=$(jq -r '.token' "$BODY")

R=$(req POST /auth/register "" "{\"full_name\":\"Dup\",\"email\":\"$EMAIL\",\"password\":\"secret1234\"}")
check "duplicate email rejected" 409 "$R"

R=$(req GET /users/me "$TOKEN"); check "GET /users/me" 200 "$R"
R=$(req PUT /users/me "$TOKEN" '{"bio":"Napenda Maasai niishi Dar.","phone":"+255 700 999 888"}'); check "update profile" 200 "$R"
R=$(req GET /users/me); check "users/me without token → 401" 401 "$R"

# --- favorites (own only) ---
R=$(req POST "/favorites/$PROP" "$TOKEN"); check "add favorite" 201 "$R"
R=$(req GET /favorites "$TOKEN"); check "list favorites contains it" 200 "$R"
[ "$(jq -r --arg id "$PROP" '[.items[].id] | index($id) != null' "$BODY")" = "true" ]; assert "favorite persisted in DB list" $?
R=$(req GET /favorites/ids "$TOKEN"); check "favorite ids" 200 "$R"
R=$(req DELETE "/favorites/$PROP" "$TOKEN"); check "remove favorite" 200 "$R"
[ "$(jq -r --arg id "$PROP" '[.ids] | index($id) == null' "$BODY")" = "true" ]; assert "favorite removed" $?

# --- messaging with a host ---
R=$(req POST /conversations "$TOKEN" "{\"property_id\":\"$PROP\"}")
check "start conversation" 201 "$R"
CONV=$(jq -r '.conversation_id' "$BODY")
R=$(req POST "/conversations/$CONV/messages" "$TOKEN" '{"message":"Habari, nyumba bado ipo?"}')
check "send message" 201 "$R"
R=$(req GET "/conversations/$CONV/messages" "$TOKEN"); check "get messages + mark read" 200 "$R"
[ "$(jq -r '[.messages[].message] | index("Habari, nyumba bado ipo?") != null' "$BODY")" = "true" ]; assert "message persisted" $?
R=$(req GET /conversations "$TOKEN"); check "conversation list with unread" 200 "$R"

# participant isolation: another user cannot read it
R=$(req POST /auth/register "" "{\"full_name\":\"Sneaky\",\"email\":\"sneaky$(date +%s)@kayaleo.app\",\"password\":\"secret1234\"}")
SNEAK=$(jq -r '.token' <(echo "$R" | sed '$d'))
R=$(req GET "/conversations/$CONV/messages" "$SNEAK"); check "stranger blocked from conversation" 403 "$R"

# --- become a host ---
R=$(req POST /host/apply "$TOKEN" "{\"full_name\":\"Neema Test\",\"phone\":\"+255 700 111 222\",\"email\":\"$EMAIL\"}")
check "host apply" 200 "$R"

# --- create listing (goes to pending) ---
R=$(req POST /properties "$TOKEN" '{
  "title":"Ghorofa mpya Tegeta","description":"Ghorofa safi yenye vyumba 2, maji 24/7.",
  "property_type":"APARTMENT","price_monthly":650000,"bedrooms":2,"bathrooms":1,
  "size_m2":95,"furnished":true,"floor_number":3,"max_occupants":4,
  "latitude":-6.738,"longitude":39.229,"region":"Dar es Salaam","city":"Dar es Salaam",
  "district":"Kinondoni","neighborhood":"Tegeta","street":"Tegeta Rd","landmark":"Tegeta Darajani",
  "house_rules":"Hakuna sherehe.","amenities":["Wi-Fi","Parking","Generator"],
  "images":[{"image_url":"https://example.com/img1.jpg","category":"EXTERIOR","is_cover":true,"sort_order":0}],
  "status":"pending"}')
check "create listing (pending)" 201 "$R"
NEWPROP=$(jq -r '.property.id' "$BODY")

R=$(req GET "/properties?q=Ghorofa%20mpya"); check "public search while pending" 200 "$R"
[ "$(jq -r '.total' "$BODY")" = "0" ]; assert "pending listing hidden from public search" $?

R=$(req GET /host/properties "$TOKEN"); check "host sees own listing" 200 "$R"
R=$(req GET /host/dashboard "$TOKEN"); check "host dashboard stats" 200 "$R"

R=$(req POST /properties "$SNEAK" '{"title":"X","property_type":"ROOM","price_monthly":1}')
check "non-host blocked from creating" 403 "$R"

# --- images ---
R=$(req POST "/properties/$NEWPROP/images" "$TOKEN" '{"images":[{"image_url":"https://example.com/new.jpg","category":"BEDROOM","is_cover":true,"sort_order":0}]}')
check "replace property images" 200 "$R"

# --- admin moderation ---
R=$(req POST /auth/login "" '{"email":"admin@kayaleo.app","password":"kayaleo123"}')
check "admin login" 200 "$R"
ADMIN=$(jq -r '.token' "$BODY")

R=$(req GET /admin/stats "$ADMIN"); check "admin stats" 200 "$R"
R=$(req GET "/admin/properties?status=pending" "$ADMIN"); check "admin pending queue" 200 "$R"
R=$(req POST "/admin/properties/$NEWPROP/moderate" "$ADMIN" '{"action":"approve"}')
check "admin approve listing" 200 "$R"

R=$(req GET "/properties?q=Ghorofa%20mpya"); check "public search after approval" 200 "$R"
GOT=$(jq -r '.items[0].id // "null"' "$BODY")
[ "$GOT" = "$NEWPROP" ] || echo "   (debug: got=$GOT expected=$NEWPROP total=$(jq -r '.total' "$BODY"))"
[ "$GOT" = "$NEWPROP" ]; assert "approved listing now public" $?

R=$(req GET /admin/stats "$TOKEN"); check "non-admin blocked" 403 "$R"

# --- review (cannot review own) ---
R=$(req POST "/properties/$NEWPROP/reviews" "$TOKEN" '{"rating":5,"comment":"Nimeweka mimi mwenyewe"}')
check "host cannot review own listing" 409 "$R"
R=$(req POST "/properties/$PROP/reviews" "$TOKEN" '{"rating":5,"comment":"Kizuri sana!"}')
check "renter reviews property" 201 "$R"

# --- inquiry / booking request ---
R=$(req POST "/properties/$PROP/inquiries" "$TOKEN" '{"message":"Naomba kukodisha kuanzia mwezi ujao."}')
check "create inquiry (omba kukodisha)" 201 "$R"
R=$(req GET /inquiries/mine "$TOKEN"); check "my inquiries" 200 "$R"

# --- report ---
R=$(req POST "/properties/$NEWPROP/report" "$SNEAK" '{"reason":"WRONG_INFORMATION","details":"Bei si sahihi."}')
check "report listing" 201 "$R"
R=$(req GET /admin/reports "$ADMIN"); check "admin sees reports" 200 "$R"
REPORT=$(jq -r '.items[0].id' "$BODY")
R=$(req PUT "/admin/reports/$REPORT/status" "$ADMIN" '{"status":"resolved"}')
check "admin resolve report" 200 "$R"

# --- host lifecycle: publish / pause / edit / delete ---
R=$(req POST /properties "$TOKEN" '{"title":"Rasimu ya chumba maalum 777","description":"Bado","property_type":"ROOM","price_monthly":100000,"status":"draft","images":[]}')
check "save draft listing" 201 "$R"
DRAFT=$(jq -r '.property.id' "$BODY")
R=$(req POST "/properties/$DRAFT/publish" "$TOKEN"); check "publish draft → pending" 200 "$R"
R=$(req PUT "/properties/$DRAFT" "$TOKEN" '{"price_monthly":120000,"title":"Chumba safi Sinza 777"}')
check "edit listing price/title" 200 "$R"
R=$(req POST "/properties/$DRAFT/pause" "$TOKEN"); check "pause listing" 200 "$R"
R=$(req DELETE "/properties/$DRAFT" "$TOKEN"); check "delete listing" 200 "$R"

# --- admin user management ---
R=$(req GET /admin/users "$ADMIN"); check "admin list users" 200 "$R"
UID2=$(jq -r --arg email "$EMAIL" '.items[] | select(.email==$email) | .id' "$BODY")
R=$(req PUT "/admin/users/$UID2/verified" "$ADMIN" '{"is_verified":true}')
check "admin verify host" 200 "$R"

# --- logout ---
R=$(req POST /auth/logout); check "logout" 200 "$R"

echo ""
echo "== RESULTS: $PASS passed, $FAIL failed =="
[ "$FAIL" = "0" ]
