import { NextFunction, Request, RequestHandler, Response } from 'express';

/** Wrap async controllers so rejected promises hit the error handler. */
export function asyncHandler(fn: (req: Request, res: Response, next: NextFunction) => Promise<unknown>): RequestHandler {
  return (req, res, next) => {
    fn(req, res, next).catch(next);
  };
}
