import { Request } from 'express';

export interface AuthUser {
  id: string;
  email: string | null;
  role: 'USER' | 'HOST' | 'ADMIN';
  is_host: boolean;
}

export function getAuthUser(req: Request): AuthUser | null {
  return (req as Request & { authUser?: AuthUser }).authUser || null;
}

export function requireAuthUser(req: Request): AuthUser {
  const u = getAuthUser(req);
  if (!u) throw new Error('unreachable');
  return u;
}
