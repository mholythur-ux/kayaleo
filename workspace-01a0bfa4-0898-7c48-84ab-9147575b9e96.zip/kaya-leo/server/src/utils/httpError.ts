export class HttpError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

export const badRequest = (m = 'Ombi batili') => new HttpError(400, m);
export const unauthorized = (m = 'Tafadhali ingia kwanza.') => new HttpError(401, m);
export const forbidden = (m = 'Huna ruhusa ya kufanya hili.') => new HttpError(403, m);
export const notFound = (m = 'Haipatikani.') => new HttpError(404, m);
export const conflict = (m: string) => new HttpError(409, m);
