import { Router } from 'express';
import { asyncHandler } from '../utils/asyncHandler';
import { optionalAuth, requireAuth, requireAdmin, requireHost } from '../middleware/auth';
import { validate } from '../middleware/validate';
import * as auth from '../controllers/authController';
import * as props from '../controllers/propertyController';
import * as favs from '../controllers/favoritesController';
import * as host from '../controllers/hostController';
import * as conv from '../controllers/conversationController';
import * as reviews from '../controllers/reviewController';
import * as inquiries from '../controllers/inquiryController';
import * as reports from '../controllers/reportController';
import * as admin from '../controllers/adminController';
import * as loc from '../controllers/locationController';
import * as misc from '../controllers/miscController';
import * as images from '../controllers/imageController';
import * as v from '../validators';

export function buildRouter(): Router {
  const r = Router();

  // ---------- health / meta ----------
  r.get('/health', (_req, res) =>
    res.json({ ok: true, app: 'Kaya Leo API', version: '1.0.0', time: new Date().toISOString() })
  );
  r.get('/amenities', asyncHandler(misc.listAmenities));

  // ---------- locations ----------
  r.get('/location/search', asyncHandler(loc.searchLocation));
  r.get('/location/reverse', asyncHandler(loc.reverseGeocode));
  r.get('/location/regions', asyncHandler(loc.regions));

  // ---------- auth ----------
  r.post('/auth/register', validate(v.registerSchema), asyncHandler(auth.register));
  r.post('/auth/login', validate(v.loginSchema), asyncHandler(auth.login));
  r.post('/auth/logout', asyncHandler(auth.logout));

  // ---------- profile ----------
  r.get('/users/me', requireAuth, asyncHandler(auth.me));
  r.put('/users/me', requireAuth, validate(v.profileUpdateSchema), asyncHandler(auth.updateMe));
  r.put('/users/me/password', requireAuth, asyncHandler(auth.changePassword));

  // ---------- properties ----------
  r.get('/properties', optionalAuth, validate(v.searchQuerySchema, 'query'), asyncHandler(props.listProperties));
  r.get('/properties/:id', optionalAuth, asyncHandler(props.getProperty));
  r.post('/properties', requireAuth, requireHost, validate(v.propertyCreateSchema), asyncHandler(props.createProperty));
  r.put('/properties/:id', requireAuth, validate(v.propertyUpdateSchema), asyncHandler(props.updateProperty));
  r.delete('/properties/:id', requireAuth, asyncHandler(props.deleteProperty));
  r.post('/properties/:id/publish', requireAuth, asyncHandler(props.publishProperty));
  r.post('/properties/:id/pause', requireAuth, asyncHandler(props.pauseProperty));
  r.post('/properties/:id/view', optionalAuth, asyncHandler(props.registerView));
  r.post('/properties/:id/images', requireAuth, validate(v.imagesReplaceSchema), asyncHandler(images.replaceImages));
  r.delete('/properties/:id/images/:imageId', requireAuth, asyncHandler(images.deleteImage));

  // ---------- search (alias of GET /properties) ----------
  r.get('/properties/search', optionalAuth, validate(v.searchQuerySchema, 'query'), asyncHandler(props.listProperties));

  // ---------- favorites ----------
  r.get('/favorites', requireAuth, asyncHandler(favs.listFavorites));
  r.get('/favorites/ids', requireAuth, asyncHandler(favs.favoriteIds));
  r.post('/favorites/:propertyId', requireAuth, asyncHandler(favs.addFavorite));
  r.delete('/favorites/:propertyId', requireAuth, asyncHandler(favs.removeFavorite));

  // ---------- conversations / messages ----------
  r.get('/conversations', requireAuth, asyncHandler(conv.listConversations));
  r.post('/conversations', requireAuth, asyncHandler(conv.startConversation));
  r.get('/conversations/:id/messages', requireAuth, asyncHandler(conv.getMessages));
  r.post('/conversations/:id/messages', requireAuth, validate(v.messageSchema), asyncHandler(conv.sendMessage));

  // ---------- host ----------
  r.post('/host/apply', requireAuth, validate(v.hostApplySchema), asyncHandler(host.applyHost));
  r.get('/host/dashboard', requireAuth, requireHost, asyncHandler(host.dashboard));
  r.get('/host/properties', requireAuth, requireHost, asyncHandler(host.hostProperties));

  // ---------- reviews ----------
  r.get('/properties/:id/reviews', optionalAuth, asyncHandler(reviews.listReviews));
  r.post('/properties/:id/reviews', requireAuth, validate(v.reviewSchema), asyncHandler(reviews.createReview));
  r.get('/reviews/mine', requireAuth, asyncHandler(reviews.myReviews));

  // ---------- inquiries ----------
  r.post('/properties/:id/inquiries', requireAuth, validate(v.inquirySchema), asyncHandler(inquiries.createInquiry));
  r.get('/inquiries/mine', requireAuth, asyncHandler(inquiries.myInquiries));
  r.put('/inquiries/:id/status', requireAuth, validate(v.inquiryStatusSchema), asyncHandler(inquiries.setInquiryStatus));

  // ---------- reports ----------
  r.post('/properties/:id/report', requireAuth, validate(v.reportSchema), asyncHandler(reports.createReport));

  // ---------- admin ----------
  const adminRouter = Router();
  adminRouter.use(requireAdmin);
  adminRouter.get('/stats', asyncHandler(admin.stats));
  adminRouter.get('/properties', asyncHandler(admin.listings));
  adminRouter.post('/properties/:id/moderate', validate(v.moderationSchema), asyncHandler(admin.moderate));
  adminRouter.delete('/properties/:id', asyncHandler(admin.removeListing));
  adminRouter.get('/users', asyncHandler(admin.users));
  adminRouter.put('/users/:id/role', validate(v.roleSchema), asyncHandler(admin.setUserRole));
  adminRouter.put('/users/:id/verified', validate(v.verifiedSchema), asyncHandler(admin.setUserVerified));
  adminRouter.get('/reports', asyncHandler(admin.reports));
  adminRouter.put('/reports/:id/status', validate(v.reportStatusSchema), asyncHandler(admin.setReportStatus));
  r.use('/admin', adminRouter);

  return r;
}
