import { Request, Response } from 'express';
import { repo } from '../repo';
import { getAuthUser } from '../utils/authUser';
import { sanitizeForPublic } from './propertyController';

/** GET /favorites */
export async function listFavorites(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  const items = await repo().listFavorites(auth.id);
  res.json({ items: items.map((p) => ({ ...sanitizeForPublic(p, auth.id), is_favorite: true })), total: items.length });
}

/** POST /favorites/:propertyId */
export async function addFavorite(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  await repo().addFavorite(auth.id, req.params.propertyId);
  res.status(201).json({ is_favorite: true, message: 'Nyumba imehifadhiwa.' });
}

/** DELETE /favorites/:propertyId */
export async function removeFavorite(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  await repo().removeFavorite(auth.id, req.params.propertyId);
  res.json({ is_favorite: false, message: 'Nyumba imeondolewa kwenye uliyopendwa.' });
}

/** GET /favorites/ids — light-weight ids for heart states */
export async function favoriteIds(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  res.json({ ids: await repo().listFavoriteIds(auth.id) });
}
