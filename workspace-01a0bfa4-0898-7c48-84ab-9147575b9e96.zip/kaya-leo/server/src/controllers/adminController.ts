import { Request, Response } from 'express';
import { repo } from '../repo';
import { getAuthUser } from '../utils/authUser';
import { notFound } from '../utils/httpError';
import { ReportStatus } from '../types';

/** GET /admin/stats */
export async function stats(_req: Request, res: Response) {
  res.json({ stats: await repo().adminStats() });
}

/** GET /admin/properties?status=pending */
export async function listings(req: Request, res: Response) {
  const status = (req.query.status as never) || undefined;
  const page = Number(req.query.page || 1);
  const pageSize = Math.min(Number(req.query.page_size || 50), 100);
  const { items, total } = await repo().adminListProperties(status, page, pageSize);
  res.json({ items, total, page, page_size: pageSize });
}

/** POST /admin/properties/:id/moderate — approve | reject | suspend | request_changes */
export async function moderate(req: Request, res: Response) {
  const { action, reason } = req.body as { action: 'approve' | 'reject' | 'suspend' | 'request_changes'; reason?: string };
  const map = {
    approve: 'approved',
    reject: 'rejected',
    suspend: 'suspended',
    request_changes: 'draft',
  } as const;
  const target = await repo().getPropertyRaw(req.params.id);
  if (!target) throw notFound('Nyumba haipatikani.');
  const property = await repo().setPropertyStatus(req.params.id, map[action], reason);
  res.json({ property, message: `Tangazo: ${map[action]}.` });
}

/** DELETE /admin/properties/:id — remove fraudulent listing */
export async function removeListing(req: Request, res: Response) {
  const target = await repo().getPropertyRaw(req.params.id);
  if (!target) throw notFound('Nyumba haipatikani.');
  await repo().deleteProperty(req.params.id);
  res.json({ message: 'Tangazo limefutwa kabisa.' });
}

/** GET /admin/users */
export async function users(req: Request, res: Response) {
  const page = Number(req.query.page || 1);
  const pageSize = Math.min(Number(req.query.page_size || 50), 100);
  const { items, total } = await repo().listUsers(page, pageSize);
  res.json({ items, total, page, page_size: pageSize });
}

/** PUT /admin/users/:id/role */
export async function setUserRole(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  const { role } = req.body as { role: 'USER' | 'HOST' | 'ADMIN' };
  if (req.params.id === auth.id && role !== 'ADMIN') {
    throw notFound('Huwezi kubadilisha jina lako la admin.');
  }
  const user = await repo().setUserRole(req.params.id, role);
  res.json({ user });
}

/** PUT /admin/users/:id/verified — approve/reject host verification */
export async function setUserVerified(req: Request, res: Response) {
  const { is_verified } = req.body as { is_verified: boolean };
  const user = await repo().setUserVerified(req.params.id, is_verified);
  res.json({ user, message: is_verified ? 'Mwenye nyumba amethibitishwa.' : 'Uthibitisho umeondolewa.' });
}

/** GET /admin/reports?status=open */
export async function reports(req: Request, res: Response) {
  const status = (req.query.status as ReportStatus) || undefined;
  const items = await repo().listReports(status);
  res.json({ items, total: items.length });
}

/** PUT /admin/reports/:id/status */
export async function setReportStatus(req: Request, res: Response) {
  const { status } = req.body as { status: ReportStatus };
  const report = await repo().setReportStatus(req.params.id, status);
  res.json({ report });
}
