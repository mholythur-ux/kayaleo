import { Request, Response } from 'express';
import { env } from '../config/env';
import { tanzaniaLocations } from '../repo/demoData';

interface NominatimHit {
  display_name: string;
  lat: string;
  lon: string;
  type?: string;
  address?: Record<string, string>;
}

function addressParts(hit: NominatimHit) {
  const a = hit.address || {};
  return {
    label: hit.display_name,
    latitude: parseFloat(hit.lat),
    longitude: parseFloat(hit.lon),
    country: a.country || 'Tanzania',
    region: a.state || a.region || null,
    city: a.city || a.town || a.municipality || a.village || null,
    district: a.district || a.suburb || a.county || null,
    neighborhood: a.suburb || a.neighbourhood || a.quarter || null,
    street: a.road || null,
    landmark: a.attraction || a.building || null,
  };
}

/** GET /location/search?q= — proxied geocoding (Nominatim / OpenStreetMap) */
export async function searchLocation(req: Request, res: Response) {
  const q = String(req.query.q || '').trim();
  if (q.length < 2) {
    res.json({ items: [] });
    return;
  }
  const url = new URL('/search', env.nominatimBaseUrl);
  url.searchParams.set('q', q.includes('tanzania') || q.includes('tz') ? q : `${q}, Tanzania`);
  url.searchParams.set('format', 'jsonv2');
  url.searchParams.set('addressdetails', '1');
  url.searchParams.set('limit', '8');
  url.searchParams.set('countrycodes', 'tz');

  try {
    const r = await fetch(url.toString(), {
      headers: { 'User-Agent': 'KayaLeoApp/1.0 (support@kayaleo.app)' },
      signal: AbortSignal.timeout(6000),
    });
    if (!r.ok) throw new Error(`geocoder ${r.status}`);
    const hits = (await r.json()) as NominatimHit[];
    res.json({ items: hits.map(addressParts) });
  } catch {
    // Offline / rate limited — client falls back to the curated list
    res.json({ items: [], offline: true });
  }
}

/** GET /location/reverse?lat=&lng= */
export async function reverseGeocode(req: Request, res: Response) {
  const lat = parseFloat(String(req.query.lat || ''));
  const lng = parseFloat(String(req.query.lng || ''));
  if (Number.isNaN(lat) || Number.isNaN(lng)) {
    res.status(400).json({ error: 'lat na lng zinahitajika.' });
    return;
  }
  const url = new URL('/reverse', env.nominatimBaseUrl);
  url.searchParams.set('lat', String(lat));
  url.searchParams.set('lon', String(lng));
  url.searchParams.set('format', 'jsonv2');
  url.searchParams.set('addressdetails', '1');
  try {
    const r = await fetch(url.toString(), {
      headers: { 'User-Agent': 'KayaLeoApp/1.0 (support@kayaleo.app)' },
      signal: AbortSignal.timeout(6000),
    });
    if (!r.ok) throw new Error(`geocoder ${r.status}`);
    const hit = (await r.json()) as NominatimHit;
    res.json({ item: addressParts(hit) });
  } catch {
    res.json({ item: null, offline: true });
  }
}

/** GET /location/regions — curated TZ regions/districts/neighborhoods */
export async function regions(_req: Request, res: Response) {
  res.json(tanzaniaLocations);
}
