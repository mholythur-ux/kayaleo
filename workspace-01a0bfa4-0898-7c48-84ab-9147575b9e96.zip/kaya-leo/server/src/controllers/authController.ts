import { Request, Response } from 'express';
import { repo, isDemoMode } from '../repo';
import { supabaseSignIn } from '../middleware/auth';
import { getAuthUser } from '../utils/authUser';
import { conflict, notFound, unauthorized } from '../utils/httpError';
import { getServiceClient } from '../config/supabase';

/**
 * POST /auth/register
 * Creates the auth user + profile. The client then signs in via
 * supabase-js (mobile) which returns the session.
 */
export async function register(req: Request, res: Response) {
  const { full_name, phone, email, password } = req.body as {
    full_name: string;
    phone?: string;
    email: string;
    password: string;
  };

  const existing = await repo().getProfileByEmail(email);
  if (existing) throw conflict('Email tayari inatumika. Tumia nyingine au ingia.');

  if (isDemoMode()) {
    const profile = await repo().createUser({ email, password, full_name, phone: phone || null });
    return res.status(201).json({ user: profile, token: `demo-${profile.id}`, note: 'demo token' });
  }

  const profile = await repo().createUser({ email, password, full_name, phone: phone || null });
  res.status(201).json({ user: profile, message: 'Akaunda imeundwa. Sasa ingia.' });
}

/** POST /auth/login */
export async function login(req: Request, res: Response) {
  const { email, password } = req.body as { email: string; password: string };

  if (isDemoMode()) {
    const profile = await repo().verifyDemoCredentials(email, password);
    if (!profile) throw unauthorized('Email au nenosiri si sahihi.');
    return res.json({ user: profile, token: `demo-${profile.id}` });
  }

  const { token } = await supabaseSignIn(email, password);
  const profile = await repo().getProfileByEmail(email);
  if (!profile) throw notFound('Profile haipatikani.');
  res.json({ user: profile, token });
}

/** POST /auth/logout — client discards the session; kept for API completeness. */
export async function logout(_req: Request, res: Response) {
  res.json({ message: 'Umeondoka. Kwaheri!' });
}

/** GET /users/me */
export async function me(req: Request, res: Response) {
  const auth = getAuthUser(req);
  const profile = await repo().getProfileById(auth!.id);
  if (!profile) throw notFound('Profile haipatikani.');
  res.json({ user: profile });
}

/** PUT /users/me */
export async function updateMe(req: Request, res: Response) {
  const auth = getAuthUser(req);
  const updated = await repo().updateProfile(auth!.id, req.body);
  res.json({ user: updated });
}

/** PUT /users/me/password (supabase mode helper) */
export async function changePassword(req: Request, res: Response) {
  if (isDemoMode()) {
    res.json({ message: 'Hali hii haipatikani kwenye demo mode.' });
    return;
  }
  const auth = getAuthUser(req);
  const { password } = req.body as { password: string };
  const { error } = await getServiceClient().auth.admin.updateUserById(auth!.id, { password });
  if (error) throw new Error(error.message);
  res.json({ message: 'Nenosiri limebadilishwa.' });
}
