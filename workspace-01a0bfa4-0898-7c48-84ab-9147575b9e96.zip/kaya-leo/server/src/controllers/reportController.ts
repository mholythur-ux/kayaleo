import { Request, Response } from 'express';
import { repo } from '../repo';
import { getAuthUser } from '../utils/authUser';

/** POST /properties/:id/report — "Ripoti tangazo" */
export async function createReport(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  const { reason, details } = req.body as { reason: never; details: string };
  const report = await repo().createReport(auth.id, req.params.id, reason, details);
  res.status(201).json({ report, message: 'Asante. Ripoti yako imetumwa kwa msimamizi.' });
}
