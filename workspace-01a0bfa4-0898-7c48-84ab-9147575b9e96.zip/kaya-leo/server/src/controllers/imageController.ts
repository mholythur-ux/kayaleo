import { Request, Response } from 'express';
import { repo } from '../repo';
import { getAuthUser } from '../utils/authUser';
import { forbidden, notFound } from '../utils/httpError';

/**
 * POST /properties/:id/images
 * Replaces the image metadata set. Binaries are uploaded directly
 * from the mobile app to Supabase Storage (bucket: property-images)
 * using the user's own JWT — the server only records metadata.
 */
export async function replaceImages(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  const existing = await repo().getPropertyRaw(req.params.id);
  if (!existing) throw notFound('Nyumba haipatikani.');
  if (existing.host_id !== auth.id && auth.role !== 'ADMIN') throw forbidden('Hii si nyumba yako.');
  const updated = await repo().updateProperty(req.params.id, {}, undefined, req.body.images);
  res.json({ property: updated });
}

/** DELETE /properties/:id/images/:imageId */
export async function deleteImage(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  const existing = await repo().getPropertyRaw(req.params.id);
  if (!existing) throw notFound('Nyumba haipatikani.');
  if (existing.host_id !== auth.id && auth.role !== 'ADMIN') throw forbidden('Hii si nyumba yako.');
  const property = await repo().getProperty(req.params.id);
  const images = (property?.images || [])
    .filter((i) => i.id !== req.params.imageId)
    .map((i, idx) => ({
      image_url: i.image_url,
      storage_path: i.storage_path,
      category: i.category,
      is_cover: i.is_cover,
      sort_order: i.sort_order ?? idx,
    }));
  await repo().updateProperty(req.params.id, {}, undefined, images);
  res.json({ message: 'Picha imefutwa.' });
}
