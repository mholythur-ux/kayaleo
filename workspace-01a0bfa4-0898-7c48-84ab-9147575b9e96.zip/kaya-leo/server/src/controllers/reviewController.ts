import { Request, Response } from 'express';
import { repo } from '../repo';
import { getAuthUser } from '../utils/authUser';
import { conflict, notFound } from '../utils/httpError';

/** GET /properties/:id/reviews */
export async function listReviews(req: Request, res: Response) {
  const items = await repo().listReviews(req.params.id);
  res.json({ items, total: items.length });
}

/** GET /reviews/mine — reviews written by the signed-in user */
export async function myReviews(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  const items = await repo().listMyReviews(auth.id);
  res.json({ items, total: items.length });
}

/** POST /properties/:id/reviews */
export async function createReview(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  const { rating, comment } = req.body as { rating: number; comment: string };
  const property = await repo().getPropertyRaw(req.params.id);
  if (!property) throw notFound('Nyumba haipatikani.');
  if (property.host_id === auth.id) throw conflict('Huwezi kupima nyumba yako mwenyewe.');
  const review = await repo().createReview(auth.id, req.params.id, rating, comment);
  res.status(201).json({ review, message: 'Asante kwa maoni yako!' });
}
