import { Request, Response } from 'express';
import { repo } from '../repo';
import { getAuthUser } from '../utils/authUser';
import { PropertyStatus } from '../types';

/** POST /host/apply — a USER becomes a HOST (listings still get moderated) */
export async function applyHost(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  const { full_name, phone, email } = req.body as { full_name: string; phone: string; email: string };
  const profile = await repo().getProfileById(auth.id);
  if (!profile) throw new Error('Profile not found');
  const updated = await repo().applyHost(profile, { full_name, phone, email });
  res.json({ user: updated, message: 'Hongera! Sasa wewe ni Mwenye Nyumba. Anza kutangaza nyumba yako.' });
}

/** GET /host/dashboard — counts for the host home */
export async function dashboard(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  const all = await repo().listHostProperties(auth.id);
  const by = (s: PropertyStatus) => all.filter((p) => p.status === s);
  const inquiries = await repo().listHostInquiries(auth.id);
  const conversations = await repo().listConversations(auth.id);
  const favorites = all.reduce((s, p) => s + Number(p.favorites_count || 0), 0);
  const views = all.reduce((s, p) => s + Number(p.views_count || 0), 0);
  res.json({
    stats: {
      active_listings: by('approved').length,
      draft_listings: by('draft').length,
      pending_listings: by('pending').length,
      rejected_listings: by('rejected').length,
      suspended_listings: by('suspended').length,
      views,
      favorites,
      messages: conversations.reduce((s, c) => s + c.unread_count, 0),
      inquiries: inquiries.filter((i) => i.status === 'new').length,
      total_listings: all.length,
    },
    inquiries: inquiries.slice(0, 10),
  });
}

/** GET /host/properties?status= */
export async function hostProperties(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  const status = (req.query.status as PropertyStatus) || undefined;
  const items = await repo().listHostProperties(auth.id, status);
  res.json({ items, total: items.length });
}
