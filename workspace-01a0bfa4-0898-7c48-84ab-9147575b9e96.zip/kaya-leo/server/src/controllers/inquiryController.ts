import { Request, Response } from 'express';
import { repo } from '../repo';
import { getAuthUser } from '../utils/authUser';
import { InquiryStatus } from '../types';

/** POST /properties/:id/inquiries — "Omba kukodisha" */
export async function createInquiry(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  const { message } = req.body as { message: string };
  const inquiry = await repo().createInquiry(auth.id, req.params.id, message);
  res.status(201).json({ inquiry, message: 'Ombi lako limetumwa kwa mwenye nyumba.' });
}

/** GET /inquiries/mine */
export async function myInquiries(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  const items = await repo().listMyInquiries(auth.id);
  res.json({ items, total: items.length });
}

/** PUT /inquiries/:id/status — host updates new → contacted/closed */
export async function setInquiryStatus(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  const { status } = req.body as { status: InquiryStatus };
  const inquiry = await repo().setInquiryStatus(auth.id, req.params.id, status);
  res.json({ inquiry });
}
