import { Request, Response } from 'express';
import { repo } from '../repo';
import { getAuthUser } from '../utils/authUser';
import { forbidden, notFound } from '../utils/httpError';
import { queryOf } from '../middleware/validate';
import { PropertyFull, SearchParams } from '../types';

/** Public listings must not expose the host's exact pin (privacy). */
export function sanitizeForPublic(p: PropertyFull, viewerId?: string | null): PropertyFull {
  const isOwner = viewerId && p.host_id === viewerId;
  if (isOwner) return p;
  const round = (v: number | null) => (v == null ? null : Math.round(v * 1000) / 1000);
  return { ...p, latitude: round(p.latitude), longitude: round(p.longitude) };
}

/** GET /properties — public search + filters + pagination */
export async function listProperties(req: Request, res: Response) {
  const q = queryOf(req);
  const viewer = getAuthUser(req);
  const params: SearchParams = {
    q: q.q as string | undefined,
    property_type: q.property_type as never,
    min_price: q.min_price as number | undefined,
    max_price: q.max_price as number | undefined,
    bedrooms: q.bedrooms as number | undefined,
    bathrooms: q.bathrooms as number | undefined,
    amenities: q.amenities ? String(q.amenities).split(',').map((s) => s.trim()).filter(Boolean) : undefined,
    furnished: q.furnished === undefined ? undefined : String(q.furnished) === 'true',
    available_now: q.available_now === undefined ? undefined : String(q.available_now) === 'true',
    region: q.region as string | undefined,
    city: q.city as string | undefined,
    near_lat: q.near_lat as number | undefined,
    near_lng: q.near_lng as number | undefined,
    sort: (q.sort as never) || 'recommended',
    page: Number(q.page || 1),
    page_size: Number(q.page_size || 10),
  };
  const { items, total } = await repo().searchProperties(params);
  const favorites = viewer ? new Set(await repo().listFavoriteIds(viewer.id)) : new Set<string>();
  res.json({
    items: items.map((p) => ({ ...sanitizeForPublic(p, viewer?.id), is_favorite: favorites.has(p.id) })),
    total,
    page: params.page,
    page_size: params.page_size,
  });
}

/** GET /properties/:id */
export async function getProperty(req: Request, res: Response) {
  const viewer = getAuthUser(req);
  const p = await repo().getProperty(req.params.id);
  if (!p) throw notFound('Nyumba haipatikani.');
  const isOwner = viewer?.id === p.host_id;
  const isAdmin = viewer?.role === 'ADMIN';
  if (p.status !== 'approved' && !isOwner && !isAdmin) throw notFound('Nyumba haipatikani.');
  const is_favorite = viewer ? await repo().isFavorite(viewer.id, p.id) : false;
  res.json({ property: { ...sanitizeForPublic(p, viewer?.id), is_favorite } });
}

/** POST /properties — hosts only; new listings start as draft/pending */
export async function createProperty(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  if (!auth.is_host) throw forbidden('Jiunge na "Kuwa Mwenye Nyumba" kwanza kupitia Wasifu.');
  const body = req.body as Record<string, unknown>;
  const created = await repo().createProperty({
    host_id: auth.id,
    data: body,
    amenities: (body.amenities as string[]) || [],
    images: (body.images as never[]) || [],
    status: (body.status as 'draft' | 'pending') || 'pending',
  });
  res.status(201).json({ property: created, message: 'Tangazo limetumwa kwa ukaguzi.' });
}

/** PUT /properties/:id — owner host only */
export async function updateProperty(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  const existing = await repo().getPropertyRaw(req.params.id);
  if (!existing) throw notFound('Nyumba haipatikani.');
  if (existing.host_id !== auth.id && auth.role !== 'ADMIN') throw forbidden('Hii si nyumba yako.');
  const body = req.body as Record<string, unknown>;
  const updated = await repo().updateProperty(
    req.params.id,
    body,
    body.amenities as string[] | undefined,
    (body.images as never[]) ?? null
  );
  res.json({ property: updated });
}

/** DELETE /properties/:id — owner host or admin; confirms on client */
export async function deleteProperty(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  const existing = await repo().getPropertyRaw(req.params.id);
  if (!existing) throw notFound('Nyumba haipatikani.');
  if (existing.host_id !== auth.id && auth.role !== 'ADMIN') throw forbidden('Hii si nyumba yako.');
  await repo().deleteProperty(req.params.id);
  res.json({ message: 'Tangazo limefutwa.' });
}

/** POST /properties/:id/publish — draft/rejected → pending (admin review) */
export async function publishProperty(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  const existing = await repo().getPropertyRaw(req.params.id);
  if (!existing) throw notFound('Nyumba haipatikani.');
  if (existing.host_id !== auth.id) throw forbidden('Hii si nyumba yako.');
  const p = await repo().setPropertyStatus(req.params.id, 'pending');
  res.json({ property: p, message: 'Tangazo limetumwa kwa ukaguzi wa msimamizi.' });
}

/** POST /properties/:id/pause — host temporarily hides a listing */
export async function pauseProperty(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  const existing = await repo().getPropertyRaw(req.params.id);
  if (!existing) throw notFound('Nyumba haipatikani.');
  if (existing.host_id !== auth.id) throw forbidden('Hii si nyumba yako.');
  const p = await repo().setPropertyStatus(req.params.id, 'draft');
  res.json({ property: p, message: 'Tangazo limehifadhiwa kama rasimu (limezimwa).'});
}

/** POST /properties/:id/view — increments view counter */
export async function registerView(req: Request, res: Response) {
  await repo().incrementViews(req.params.id);
  res.json({ ok: true });
}
