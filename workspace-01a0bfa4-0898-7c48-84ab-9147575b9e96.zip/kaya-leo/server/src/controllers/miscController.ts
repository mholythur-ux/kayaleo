import { Request, Response } from 'express';
import { repo } from '../repo';

/** GET /amenities */
export async function listAmenities(_req: Request, res: Response) {
  res.json({ items: await repo().listAmenities() });
}
