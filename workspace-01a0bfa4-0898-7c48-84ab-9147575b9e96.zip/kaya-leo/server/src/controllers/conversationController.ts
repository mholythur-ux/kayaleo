import { Request, Response } from 'express';
import { repo } from '../repo';
import { getAuthUser } from '../utils/authUser';
import { forbidden, notFound } from '../utils/httpError';

/** GET /conversations */
export async function listConversations(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  const items = await repo().listConversations(auth.id);
  res.json({ items, total: items.length });
}

/** POST /conversations — body: { property_id } creates or returns existing */
export async function startConversation(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  const { property_id } = req.body as { property_id: string };
  const property = await repo().getProperty(property_id);
  if (!property) throw notFound('Nyumba haipatikani.');
  const id = await repo().upsertConversation(auth.id, property_id);
  const propertyInfo = await repo().getConversationProperty(id);
  res.status(201).json({ conversation_id: id, property: propertyInfo });
}

/** GET /conversations/:id/messages — also marks incoming as read */
export async function getMessages(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  if (!(await repo().isParticipant(req.params.id, auth.id))) throw forbidden('Huwezi kufikia mazungumzo haya.');
  const messages = await repo().listMessages(req.params.id);
  await repo().markConversationRead(req.params.id, auth.id);
  const property = await repo().getConversationProperty(req.params.id);
  res.json({ messages, property });
}

/** POST /conversations/:id/messages */
export async function sendMessage(req: Request, res: Response) {
  const auth = getAuthUser(req)!;
  if (!(await repo().isParticipant(req.params.id, auth.id))) throw forbidden('Huwezi kutuma ujumbe hapa.');
  const { message } = req.body as { message: string };
  const msg = await repo().sendMessage(req.params.id, auth.id, message);
  res.status(201).json({ message: msg });
}
