import {
  AdminStats,
  Amenity,
  ConversationSummary,
  Inquiry,
  InquiryStatus,
  Message,
  Profile,
  Property,
  PropertyFull,
  PropertyStatus,
  Report,
  ReportReason,
  ReportStatus,
  Review,
  Role,
  SearchParams,
} from '../types';
import { DataRepo } from './types';
import { getAnonClient, getServiceClient } from '../config/supabase';

const PROPERTY_COLUMNS = '*';

type ImgInput = {
  image_url: string;
  storage_path?: string | null;
  category?: string;
  is_cover?: boolean;
  sort_order?: number;
};

export class SupabaseRepo implements DataRepo {
  private svc = () => getServiceClient();

  // ---------- profiles ----------
  async getProfileById(id: string): Promise<Profile | null> {
    const { data, error } = await this.svc().from('profiles').select('*').eq('id', id).maybeSingle();
    if (error) throw error;
    return (data as Profile) || null;
  }

  async getProfileByEmail(email: string): Promise<Profile | null> {
    const { data, error } = await this.svc()
      .from('profiles')
      .select('*')
      .ilike('email', email)
      .maybeSingle();
    if (error) throw error;
    return (data as Profile) || null;
  }

  async createUser(input: {
    id?: string;
    email: string;
    password?: string;
    full_name: string;
    phone?: string | null;
  }): Promise<Profile> {
    const { data, error } = await this.svc().auth.admin.createUser({
      email: input.email,
      password: input.password,
      email_confirm: true,
      user_metadata: { full_name: input.full_name, phone: input.phone || null },
    });
    if (error) throw new Error(error.message);
    let profile = await this.getProfileById(data.user.id);
    if (!profile) throw new Error('Profile creation failed');
    if (input.phone) {
      profile = await this.updateProfile(profile.id, { phone: input.phone });
    }
    return profile;
  }

  async updateProfile(id: string, patch: Partial<Profile>): Promise<Profile> {
    const allowed: Partial<Profile> = {};
    for (const k of ['full_name', 'phone', 'email', 'avatar_url', 'bio'] as const) {
      if (patch[k] !== undefined) (allowed as Record<string, unknown>)[k] = patch[k];
    }
    const { data, error } = await this.svc()
      .from('profiles')
      .update(allowed)
      .eq('id', id)
      .select('*')
      .single();
    if (error) throw error;
    return data as Profile;
  }

  async listUsers(page: number, pageSize: number): Promise<{ items: Profile[]; total: number }> {
    const from = (page - 1) * pageSize;
    const { data, error, count } = await this.svc()
      .from('profiles')
      .select('*', { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(from, from + pageSize - 1);
    if (error) throw error;
    return { items: (data as Profile[]) || [], total: count || 0 };
  }

  async setUserRole(id: string, role: Role): Promise<Profile> {
    const patch: Record<string, unknown> = { role };
    if (role === 'HOST') {
      patch.is_host = true;
      patch.host_status = 'approved';
    }
    const { data, error } = await this.svc().from('profiles').update(patch).eq('id', id).select('*').single();
    if (error) throw error;
    return data as Profile;
  }

  async setUserVerified(id: string, isVerified: boolean): Promise<Profile> {
    const { data, error } = await this.svc()
      .from('profiles')
      .update({ is_verified: isVerified })
      .eq('id', id)
      .select('*')
      .single();
    if (error) throw error;
    return data as Profile;
  }

  async verifyDemoCredentials(): Promise<Profile | null> {
    // Not used in supabase mode — auth is handled by Supabase Auth.
    return null;
  }

  // ---------- amenities ----------
  async listAmenities(): Promise<Amenity[]> {
    const { data, error } = await this.svc().from('amenities').select('*').order('name');
    if (error) throw error;
    return (data as Amenity[]) || [];
  }

  async resolveAmenities(names: string[]): Promise<Amenity[]> {
    if (!names.length) return [];
    const { data: existing, error } = await this.svc()
      .from('amenities')
      .select('*')
      .in('name', names);
    if (error) throw error;
    const found = new Map<string, Amenity>((existing || []).map((a: Amenity) => [a.name.toLowerCase(), a]));
    const toCreate = names.filter((n) => !found.has(n.toLowerCase()));
    if (toCreate.length) {
      const { data: created, error: cErr } = await this.svc()
        .from('amenities')
        .upsert(
          toCreate.map((name) => ({ name })),
          { onConflict: 'name' }
        )
        .select('*');
      if (cErr) throw cErr;
      (created || []).forEach((a: Amenity) => found.set(a.name.toLowerCase(), a));
    }
    return names
      .map((n) => found.get(n.toLowerCase()))
      .filter(Boolean) as Amenity[];
  }

  // ---------- property composition ----------
  private async attachImages(propertyIds: string[]): Promise<Map<string, PropertyFull['images']>> {
    const map = new Map<string, PropertyFull['images']>();
    if (!propertyIds.length) return map;
    const { data, error } = await this.svc()
      .from('property_images')
      .select('*')
      .in('property_id', propertyIds)
      .order('sort_order', { ascending: true });
    if (error) throw error;
    for (const img of data || []) {
      const list = map.get(img.property_id) || [];
      list.push(img);
      map.set(img.property_id, list);
    }
    return map;
  }

  private async attachAmenities(propertyIds: string[]): Promise<Map<string, string[]>> {
    const map = new Map<string, string[]>();
    if (!propertyIds.length) return map;
    const { data, error } = await this.svc()
      .from('property_amenities')
      .select('property_id, amenities(name)')
      .in('property_id', propertyIds);
    if (error) throw error;
    for (const row of data || []) {
      const list = map.get(row.property_id) || [];
      const amenityRow = row.amenities as unknown as { name: string } | null;
      if (amenityRow?.name) list.push(amenityRow.name);
      map.set(row.property_id, list);
    }
    return map;
  }

  private async attachRatings(propertyIds: string[]): Promise<Map<string, { avg: number; count: number }>> {
    const map = new Map<string, { avg: number; count: number }>();
    if (!propertyIds.length) return map;
    const { data, error } = await this.svc()
      .from('reviews')
      .select('property_id, rating')
      .in('property_id', propertyIds);
    if (error) throw error;
    for (const r of data || []) {
      const cur = map.get(r.property_id) || { avg: 0, count: 0 };
      cur.count += 1;
      cur.avg += r.rating;
      map.set(r.property_id, cur);
    }
    for (const [k, v] of map) map.set(k, { avg: v.count ? v.avg / v.count : 0, count: v.count });
    return map;
  }

  private async attachHosts(hostIds: string[]): Promise<Map<string, PublicHostLite>> {
    const map = new Map<string, PublicHostLite>();
    if (!hostIds.length) return map;
    const { data, error } = await this.svc()
      .from('profiles')
      .select('id, full_name, avatar_url, is_verified, phone, created_at')
      .in('id', hostIds);
    if (error) throw error;
    for (const h of data || []) map.set(h.id, h);
    return map;
  }

  private enrich(
    p: Property,
    imgs: PropertyFull['images'] | undefined,
    amen: string[] | undefined,
    rating: { avg: number; count: number } | undefined,
    host: PublicHostLite | undefined
  ): PropertyFull {
    const available = !p.availability_date || new Date(p.availability_date).getTime() <= Date.now();
    return {
      ...p,
      price_monthly: Number(p.price_monthly),
      price_weekly: p.price_weekly != null ? Number(p.price_weekly) : null,
      price_daily: p.price_daily != null ? Number(p.price_daily) : null,
      size_m2: p.size_m2 != null ? Number(p.size_m2) : null,
      images: (imgs || []).sort((a, b) => a.sort_order - b.sort_order),
      amenities: amen || [],
      rating_avg: rating ? Math.round(rating.avg * 10) / 10 : 0,
      rating_count: rating?.count || 0,
      host: host || null,
      is_available_now: available,
    };
  }

  // ---------- properties ----------
  async searchProperties(
    params: SearchParams
  ): Promise<{ items: PropertyFull[]; total: number }> {
    const page = params.page || 1;
    const pageSize = params.page_size || 10;
    let query = this.svc()
      .from('properties')
      .select(PROPERTY_COLUMNS, { count: 'exact' })
      .eq('status', 'approved');

    if (params.q) {
      const like = `%${params.q}%`;
      const or = [
        `title.ilike.${like}`,
        `region.ilike.${like}`,
        `city.ilike.${like}`,
        `district.ilike.${like}`,
        `neighborhood.ilike.${like}`,
        `street.ilike.${like}`,
        `landmark.ilike.${like}`,
      ].join(',');
      query = query.or(or);
    }
    if (params.property_type) query = query.eq('property_type', params.property_type);
    if (params.min_price !== undefined) query = query.gte('price_monthly', params.min_price);
    if (params.max_price !== undefined) query = query.lte('price_monthly', params.max_price);
    if (params.bedrooms !== undefined) query = query.gte('bedrooms', params.bedrooms);
    if (params.bathrooms !== undefined) query = query.gte('bathrooms', params.bathrooms);
    if (params.furnished !== undefined) query = query.eq('furnished', params.furnished);
    if (params.region) query = query.ilike('region', `%${params.region}%`);
    if (params.city) query = query.ilike('city', `%${params.city}%`);
    if (params.available_now) query = query.or('availability_date.is.null,availability_date.lte.now()');

    if (params.amenities && params.amenities.length) {
      const { data: rows, error } = await this.svc()
        .from('property_amenities')
        .select('property_id, amenities!inner(name)')
        .in('amenities.name', params.amenities);
      if (error) throw error;
      const counts = new Map<string, number>();
      for (const r of rows || []) {
        counts.set(r.property_id, (counts.get(r.property_id) || 0) + 1);
      }
      const ids = [...counts.entries()].filter(([, c]) => c >= params.amenities!.length).map(([id]) => id);
      if (!ids.length) return { items: [], total: 0 };
      query = query.in('id', ids);
    }

    switch (params.sort) {
      case 'price_asc':
        query = query.order('price_monthly', { ascending: true });
        break;
      case 'price_desc':
        query = query.order('price_monthly', { ascending: false });
        break;
      case 'recommended':
        query = query
          .order('is_featured', { ascending: false })
          .order('views_count', { ascending: false });
        break;
      case 'distance':
        query = query.order('created_at', { ascending: false }); // distance applied client-side below
        break;
      default:
        query = query.order('created_at', { ascending: false });
    }

    const from = (page - 1) * pageSize;
    const { data, error, count } = await query.range(from, from + pageSize - 1);
    if (error) throw error;
    const props = (data as Property[]) || [];

    const [imgs, amen, ratings, hosts] = await Promise.all([
      this.attachImages(props.map((p) => p.id)),
      this.attachAmenities(props.map((p) => p.id)),
      this.attachRatings(props.map((p) => p.id)),
      this.attachHosts([...new Set(props.map((p) => p.host_id))]),
    ]);

    let items = props.map((p) =>
      this.enrich(p, imgs.get(p.id), amen.get(p.id), ratings.get(p.id), hosts.get(p.host_id))
    );

    if (params.sort === 'distance' && params.near_lat && params.near_lng) {
      const d = (p: PropertyFull) =>
        p.latitude == null || p.longitude == null
          ? Number.MAX_VALUE
          : haversine(params.near_lat!, params.near_lng!, p.latitude, p.longitude);
      items = items.sort((a, b) => d(a) - d(b));
    }

    return { items, total: count || 0 };
  }

  async getProperty(id: string): Promise<PropertyFull | null> {
    const { data, error } = await this.svc().from('properties').select(PROPERTY_COLUMNS).eq('id', id).maybeSingle();
    if (error) throw error;
    if (!data) return null;
    const p = data as Property;
    const [imgs, amen, ratings, hosts] = await Promise.all([
      this.attachImages([id]),
      this.attachAmenities([id]),
      this.attachRatings([id]),
      this.attachHosts([p.host_id]),
    ]);
    return this.enrich(p, imgs.get(id), amen.get(id), ratings.get(id), hosts.get(p.host_id));
  }

  async getPropertyRaw(id: string): Promise<Property | null> {
    const { data, error } = await this.svc().from('properties').select('*').eq('id', id).maybeSingle();
    if (error) throw error;
    return (data as Property) || null;
  }

  async createProperty(input: {
    host_id: string;
    data: Record<string, unknown>;
    amenities: string[];
    images: ImgInput[];
    status: PropertyStatus;
    is_featured?: boolean;
  }): Promise<PropertyFull> {
    const d = input.data;
    const insert = {
      host_id: input.host_id,
      title: d.title,
      description: d.description ?? '',
      property_type: d.property_type,
      status: input.status,
      price_monthly: d.price_monthly ?? 0,
      price_weekly: d.price_weekly ?? null,
      price_daily: d.price_daily ?? null,
      bedrooms: d.bedrooms ?? 1,
      bathrooms: d.bathrooms ?? 1,
      size_m2: d.size_m2 ?? null,
      floor_number: d.floor_number ?? null,
      furnished: Boolean(d.furnished),
      max_occupants: d.max_occupants ?? null,
      house_rules: d.house_rules ?? null,
      latitude: d.latitude ?? null,
      longitude: d.longitude ?? null,
      country: d.country ?? 'Tanzania',
      region: d.region ?? null,
      city: d.city ?? null,
      district: d.district ?? null,
      neighborhood: d.neighborhood ?? null,
      street: d.street ?? null,
      landmark: d.landmark ?? null,
      availability_date: d.availability_date ?? null,
      is_featured: Boolean(input.is_featured),
    };
    const { data: created, error } = await this.svc().from('properties').insert(insert).select('*').single();
    if (error) throw error;
    const prop = created as Property;

    await this.syncAmenities(prop.id, input.amenities);
    if (input.images.length) await this.replaceImages(prop.id, input.images);
    const full = await this.getProperty(prop.id);
    if (!full) throw new Error('Property creation failed');
    return full;
  }

  private async syncAmenities(propertyId: string, names: string[]): Promise<void> {
    const { error: delErr } = await this.svc()
      .from('property_amenities')
      .delete()
      .eq('property_id', propertyId);
    if (delErr) throw delErr;
    if (!names.length) return;
    const resolved = await this.resolveAmenities(names);
    const { error } = await this.svc()
      .from('property_amenities')
      .insert(resolved.map((a) => ({ property_id: propertyId, amenity_id: a.id })));
    if (error) throw error;
  }

  private async replaceImages(propertyId: string, images: ImgInput[]): Promise<void> {
    const { error: delErr } = await this.svc()
      .from('property_images')
      .delete()
      .eq('property_id', propertyId);
    if (delErr) throw delErr;
    if (!images.length) return;
    const rows = images.map((img, idx) => ({
      property_id: propertyId,
      image_url: img.image_url,
      storage_path: img.storage_path ?? null,
      category: img.category || 'OTHER',
      sort_order: img.sort_order ?? idx,
      is_cover: Boolean(img.is_cover) || idx === 0,
    }));
    const { error } = await this.svc().from('property_images').insert(rows);
    if (error) throw error;
  }

  async updateProperty(
    id: string,
    patch: Record<string, unknown>,
    amenities?: string[],
    images?: ImgInput[] | null
  ): Promise<PropertyFull> {
    const allowed: Record<string, unknown> = {};
    for (const k of [
      'title', 'description', 'property_type', 'price_monthly', 'price_weekly', 'price_daily',
      'bedrooms', 'bathrooms', 'size_m2', 'floor_number', 'furnished', 'max_occupants',
      'house_rules', 'latitude', 'longitude', 'country', 'region', 'city', 'district',
      'neighborhood', 'street', 'landmark', 'availability_date',
    ]) {
      if (patch[k] !== undefined) allowed[k] = patch[k];
    }
    if (Object.keys(allowed).length) {
      const { error } = await this.svc().from('properties').update(allowed).eq('id', id);
      if (error) throw error;
    }
    if (amenities) await this.syncAmenities(id, amenities);
    if (images) await this.replaceImages(id, images);
    const full = await this.getProperty(id);
    if (!full) throw new Error('Property not found');
    return full;
  }

  async deleteProperty(id: string): Promise<void> {
    const { error } = await this.svc().from('properties').delete().eq('id', id);
    if (error) throw error;
  }

  async listHostProperties(hostId: string, status?: PropertyStatus): Promise<PropertyFull[]> {
    let q = this.svc().from('properties').select(PROPERTY_COLUMNS).eq('host_id', hostId);
    if (status) q = q.eq('status', status);
    const { data, error } = await q.order('updated_at', { ascending: false });
    if (error) throw error;
    const props = (data as Property[]) || [];
    const [imgs, amen, ratings, hosts] = await Promise.all([
      this.attachImages(props.map((p) => p.id)),
      this.attachAmenities(props.map((p) => p.id)),
      this.attachRatings(props.map((p) => p.id)),
      this.attachHosts([hostId]),
    ]);
    return props.map((p) =>
      this.enrich(p, imgs.get(p.id), amen.get(p.id), ratings.get(p.id), hosts.get(p.host_id))
    );
  }

  async incrementViews(id: string): Promise<void> {
    const { error } = await this.svc().rpc('increment_property_views', { p_id: id });
    if (error) {
      // fallback if rpc missing
      const { data } = await this.svc().from('properties').select('views_count').eq('id', id).maybeSingle();
      if (data) {
        await this.svc().from('properties').update({ views_count: Number(data.views_count) + 1 }).eq('id', id);
      }
    }
  }

  async setPropertyStatus(id: string, status: PropertyStatus, reason?: string | null): Promise<Property> {
    const { data, error } = await this.svc()
      .from('properties')
      .update({
        status,
        rejection_reason: status === 'rejected' ? reason || 'Haitoshi vigezo' : null,
        reviewed_at: new Date().toISOString(),
      })
      .eq('id', id)
      .select('*')
      .single();
    if (error) throw error;
    return data as Property;
  }

  // ---------- favorites ----------
  async addFavorite(userId: string, propertyId: string): Promise<void> {
    const { error } = await this.svc().from('favorites').upsert(
      { user_id: userId, property_id: propertyId },
      { onConflict: 'user_id,property_id' }
    );
    if (error) throw error;
  }

  async removeFavorite(userId: string, propertyId: string): Promise<void> {
    const { error } = await this.svc()
      .from('favorites')
      .delete()
      .eq('user_id', userId)
      .eq('property_id', propertyId);
    if (error) throw error;
  }

  async listFavorites(userId: string): Promise<PropertyFull[]> {
    const { data, error } = await this.svc()
      .from('favorites')
      .select('properties!inner(*)')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    if (error) throw error;
    const props = ((data || []) as unknown as Array<{ properties: Property }>).map((r) => r.properties);
    const [imgs, amen, ratings, hosts] = await Promise.all([
      this.attachImages(props.map((p) => p.id)),
      this.attachAmenities(props.map((p) => p.id)),
      this.attachRatings(props.map((p) => p.id)),
      this.attachHosts([...new Set(props.map((p) => p.host_id))]),
    ]);
    return props.map((p) =>
      this.enrich(p, imgs.get(p.id), amen.get(p.id), ratings.get(p.id), hosts.get(p.host_id))
    );
  }

  async isFavorite(userId: string, propertyId: string): Promise<boolean> {
    const { count, error } = await this.svc()
      .from('favorites')
      .select('id', { count: 'exact', head: true })
      .eq('user_id', userId)
      .eq('property_id', propertyId);
    if (error) throw error;
    return (count || 0) > 0;
  }

  async listFavoriteIds(userId: string): Promise<string[]> {
    const { data, error } = await this.svc()
      .from('favorites')
      .select('property_id')
      .eq('user_id', userId);
    if (error) throw error;
    return (data || []).map((r: { property_id: string }) => r.property_id);
  }

  // ---------- conversations ----------
  async upsertConversation(userId: string, propertyId: string): Promise<string> {
    const prop = await this.getPropertyRaw(propertyId);
    if (!prop) throw new Error('Property not found');
    // find existing conversation for this property with both participants
    const { data: mine, error } = await this.svc()
      .from('conversation_participants')
      .select('conversation_id')
      .eq('user_id', userId);
    if (error) throw error;
    const myConvIds = (mine || []).map((r) => r.conversation_id);
    if (myConvIds.length) {
      const { data: convs } = await this.svc()
        .from('conversations')
        .select('id')
        .eq('property_id', propertyId)
        .in('id', myConvIds);
      if (convs && convs.length) return convs[0].id;
    }
    const { data: conv, error: cErr } = await this.svc()
      .from('conversations')
      .insert({ property_id: propertyId })
      .select('id')
      .single();
    if (cErr) throw cErr;
    const participants = [...new Set([userId, prop.host_id])];
    const { error: pErr } = await this.svc()
      .from('conversation_participants')
      .insert(participants.map((user_id) => ({ conversation_id: conv.id, user_id })));
    if (pErr) throw pErr;
    return conv.id;
  }

  async listConversations(userId: string): Promise<ConversationSummary[]> {
    const { data: parts, error } = await this.svc()
      .from('conversation_participants')
      .select('conversation_id')
      .eq('user_id', userId);
    if (error) throw error;
    const ids = (parts || []).map((p) => p.conversation_id);
    if (!ids.length) return [];
    const { data: convs, error: cErr } = await this.svc()
      .from('conversations')
      .select('*')
      .in('id', ids)
      .order('updated_at', { ascending: false });
    if (cErr) throw cErr;

    const summaries: ConversationSummary[] = [];
    for (const c of convs || []) {
      const { data: allParts } = await this.svc()
        .from('conversation_participants')
        .select('user_id')
        .eq('conversation_id', c.id);
      const participantIds = (allParts || []).map((p) => p.user_id);
      const otherId = participantIds.find((id) => id !== userId);
      const other = otherId ? await this.getProfileById(otherId) : null;
      const prop = await this.getPropertyRaw(c.property_id);
      const { data: cover } = await this.svc()
        .from('property_images')
        .select('image_url')
        .eq('property_id', c.property_id)
        .eq('is_cover', true)
        .maybeSingle();
      const { data: last } = await this.svc()
        .from('messages')
        .select('message')
        .eq('conversation_id', c.id)
        .order('created_at', { ascending: false })
        .limit(1);
      const { count: unread } = await this.svc()
        .from('messages')
        .select('id', { count: 'exact', head: true })
        .eq('conversation_id', c.id)
        .neq('sender_id', userId)
        .is('read_at', null);
      summaries.push({
        id: c.id,
        property_id: c.property_id,
        created_at: c.created_at,
        updated_at: c.updated_at,
        property: prop
          ? { id: prop.id, title: prop.title, image_url: cover?.image_url || null, price_monthly: Number(prop.price_monthly) }
          : null,
        other_participant: other
          ? { id: other.id, full_name: other.full_name, avatar_url: other.avatar_url }
          : null,
        last_message: last && last.length ? last[0].message : null,
        unread_count: unread || 0,
      });
    }
    return summaries;
  }

  async isParticipant(conversationId: string, userId: string): Promise<boolean> {
    const { count, error } = await this.svc()
      .from('conversation_participants')
      .select('user_id', { count: 'exact', head: true })
      .eq('conversation_id', conversationId)
      .eq('user_id', userId);
    if (error) throw error;
    return (count || 0) > 0;
  }

  async getConversationProperty(conversationId: string): Promise<ConversationSummary['property']> {
    const { data: conv } = await this.svc()
      .from('conversations')
      .select('property_id')
      .eq('id', conversationId)
      .maybeSingle();
    if (!conv) return null;
    const prop = await this.getPropertyRaw(conv.property_id);
    if (!prop) return null;
    const { data: cover } = await this.svc()
      .from('property_images')
      .select('image_url')
      .eq('property_id', prop.id)
      .eq('is_cover', true)
      .maybeSingle();
    return {
      id: prop.id,
      title: prop.title,
      image_url: cover?.image_url || null,
      price_monthly: Number(prop.price_monthly),
    };
  }

  async listMessages(conversationId: string): Promise<Message[]> {
    const { data, error } = await this.svc()
      .from('messages')
      .select('*')
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: true });
    if (error) throw error;
    return (data as Message[]) || [];
  }

  async sendMessage(conversationId: string, senderId: string, message: string): Promise<Message> {
    const { data, error } = await this.svc()
      .from('messages')
      .insert({ conversation_id: conversationId, sender_id: senderId, message })
      .select('*')
      .single();
    if (error) throw error;
    return data as Message;
  }

  async markConversationRead(conversationId: string, userId: string): Promise<void> {
    const { error } = await this.svc()
      .from('messages')
      .update({ read_at: new Date().toISOString() })
      .eq('conversation_id', conversationId)
      .neq('sender_id', userId)
      .is('read_at', null);
    if (error) throw error;
  }

  // ---------- reviews ----------
  async listReviews(propertyId: string): Promise<Review[]> {
    const { data, error } = await this.svc()
      .from('reviews')
      .select('*, reviewer:profiles!reviews_reviewer_id_fkey(id, full_name, avatar_url)')
      .eq('property_id', propertyId)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return (data as unknown as Review[]) || [];
  }

  async createReview(reviewerId: string, propertyId: string, rating: number, comment: string): Promise<Review> {
    const prop = await this.getPropertyRaw(propertyId);
    if (!prop) throw new Error('Property not found');
    if (prop.host_id === reviewerId) throw new Error('Huwezi kupima nyumba yako mwenyewe.');
    const { data: existing } = await this.svc()
      .from('reviews')
      .select('id')
      .eq('property_id', propertyId)
      .eq('reviewer_id', reviewerId)
      .maybeSingle();
    if (existing) throw new Error('Umeshatoa maoni kwa nyumba hii.');
    const { data, error } = await this.svc()
      .from('reviews')
      .insert({ property_id: propertyId, reviewer_id: reviewerId, host_id: prop.host_id, rating, comment })
      .select('*')
      .single();
    if (error) throw error;
    return data as Review;
  }

  async listMyReviews(userId: string): Promise<Review[]> {
    const { data, error } = await this.svc()
      .from('reviews')
      .select('*')
      .eq('reviewer_id', userId)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return (data as Review[]) || [];
  }

  // ---------- inquiries ----------
  private inquiryWithRelations = `*, property:properties(id, title, price_monthly), "user":profiles!inquiries_user_id_fkey(id, full_name, avatar_url, phone)`;

  async createInquiry(userId: string, propertyId: string, message: string): Promise<Inquiry> {
    const { data, error } = await this.svc()
      .from('inquiries')
      .insert({ property_id: propertyId, user_id: userId, message })
      .select('*')
      .single();
    if (error) throw error;
    return data as Inquiry;
  }

  async listMyInquiries(userId: string): Promise<Inquiry[]> {
    const { data, error } = await this.svc()
      .from('inquiries')
      .select(this.inquiryWithRelations)
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return (data as unknown as Inquiry[]) || [];
  }

  async listHostInquiries(hostId: string): Promise<Inquiry[]> {
    const { data: props } = await this.svc().from('properties').select('id').eq('host_id', hostId);
    const ids = (props || []).map((p) => p.id);
    if (!ids.length) return [];
    const { data, error } = await this.svc()
      .from('inquiries')
      .select(this.inquiryWithRelations)
      .in('property_id', ids)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return (data as unknown as Inquiry[]) || [];
  }

  async setInquiryStatus(hostId: string, inquiryId: string, status: InquiryStatus): Promise<Inquiry> {
    const inq = await this.svc().from('inquiries').select('property_id').eq('id', inquiryId).maybeSingle();
    if (!inq.data) throw new Error('Inquiry not found');
    const prop = await this.getPropertyRaw(inq.data.property_id);
    if (!prop || prop.host_id !== hostId) throw new Error('Not allowed');
    const { data, error } = await this.svc()
      .from('inquiries')
      .update({ status })
      .eq('id', inquiryId)
      .select('*')
      .single();
    if (error) throw error;
    return data as Inquiry;
  }

  // ---------- reports ----------
  async createReport(reporterId: string, propertyId: string, reason: ReportReason, details: string): Promise<Report> {
    const { data, error } = await this.svc()
      .from('reports')
      .insert({ property_id: propertyId, reporter_id: reporterId, reason, details })
      .select('*')
      .single();
    if (error) throw error;
    return data as Report;
  }

  async listReports(status?: ReportStatus): Promise<Report[]> {
    let q = this.svc()
      .from('reports')
      .select('*, property:properties(title)')
      .order('created_at', { ascending: false });
    if (status) q = q.eq('status', status);
    const { data, error } = await q;
    if (error) throw error;
    return ((data || []) as unknown as Array<Report & { property?: { title: string } | null }>).map((r) => ({
      ...r,
      property_title: r.property?.title || null,
    }));
  }

  async setReportStatus(id: string, status: ReportStatus): Promise<Report> {
    const { data, error } = await this.svc().from('reports').update({ status }).eq('id', id).select('*').single();
    if (error) throw error;
    return data as Report;
  }

  // ---------- host / admin ----------
  async applyHost(profile: Profile, input: { full_name: string; phone: string; email: string }): Promise<Profile> {
    const { data, error } = await this.svc()
      .from('profiles')
      .update({
        full_name: input.full_name || profile.full_name,
        phone: input.phone || profile.phone,
        email: input.email || profile.email,
        is_host: true,
        host_status: 'approved',
        role: 'HOST',
      })
      .eq('id', profile.id)
      .select('*')
      .single();
    if (error) throw error;
    return data as Profile;
  }

  async adminStats(): Promise<AdminStats> {
    const svc = this.svc();
    const count = async (table: string, eq?: Record<string, string>) => {
      let q = svc.from(table).select('id', { count: 'exact', head: true });
      if (eq) for (const [k, v] of Object.entries(eq)) q = q.eq(k, v);
      const { count, error } = await q;
      if (error) throw error;
      return count || 0;
    };
    const [
      total_users,
      total_hosts,
      total_properties,
      pending_listings,
      approved_listings,
      rejected_listings,
      suspended_listings,
      open_reports,
    ] = await Promise.all([
      count('profiles'),
      count('profiles', { is_host: 'true' }),
      count('properties'),
      count('properties', { status: 'pending' }),
      count('properties', { status: 'approved' }),
      count('properties', { status: 'rejected' }),
      count('properties', { status: 'suspended' }),
      count('reports', { status: 'open' }),
    ]);
    return {
      total_users,
      total_hosts,
      total_properties,
      pending_listings,
      approved_listings,
      rejected_listings,
      suspended_listings,
      open_reports,
    };
  }
  async adminListProperties(
    status?: PropertyStatus,
    page = 1,
    pageSize = 50
  ): Promise<{ items: PropertyFull[]; total: number }> {
    let q = this.svc()
      .from('properties')
      .select(PROPERTY_COLUMNS, { count: 'exact' })
      .order('created_at', { ascending: false });
    if (status) q = q.eq('status', status);
    const from = (page - 1) * pageSize;
    const { data, error, count } = await q.range(from, from + pageSize - 1);
    if (error) throw error;
    const props = (data as Property[]) || [];
    const [imgs, amen, ratings, hosts] = await Promise.all([
      this.attachImages(props.map((p) => p.id)),
      this.attachAmenities(props.map((p) => p.id)),
      this.attachRatings(props.map((p) => p.id)),
      this.attachHosts([...new Set(props.map((p) => p.host_id))]),
    ]);
    return {
      items: props.map((p) =>
        this.enrich(p, imgs.get(p.id), amen.get(p.id), ratings.get(p.id), hosts.get(p.host_id))
      ),
      total: count || 0,
    };
  }
}

type PublicHostLite = {
  id: string;
  full_name: string;
  avatar_url: string | null;
  is_verified: boolean;
  phone: string | null;
  created_at: string;
};

function haversine(aLat: number, aLng: number, bLat: number, bLng: number): number {
  const R = 6371;
  const dLat = ((bLat - aLat) * Math.PI) / 180;
  const dLng = ((bLng - aLng) * Math.PI) / 180;
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((aLat * Math.PI) / 180) * Math.cos((bLat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}
