import {
  AdminStats,
  Amenity,
  ConversationSummary,
  Inquiry,
  InquiryStatus,
  Message,
  Profile,
  Property,
  PropertyFull,
  PropertyStatus,
  PublicHost,
  Report,
  ReportReason,
  ReportStatus,
  Review,
  Role,
  SearchParams,
} from '../types';
import { DataRepo } from './types';
import {
  demoAmenities,
  demoConversations,
  demoImages,
  demoInquiries,
  demoMessages,
  demoProfiles,
  demoProperties,
  demoPropertyAmenities,
  demoReports,
  demoReviews,
} from './demoData';

function nowISO(): string {
  return new Date().toISOString();
}

function haversineKm(aLat: number, aLng: number, bLat: number, bLng: number): number {
  const R = 6371;
  const dLat = ((bLat - aLat) * Math.PI) / 180;
  const dLng = ((bLng - aLng) * Math.PI) / 180;
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((aLat * Math.PI) / 180) * Math.cos((bLat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}

/** In-memory implementation of DataRepo (DATA_MODE=demo). */
export class MemoryRepo implements DataRepo {
  private profiles: (Profile & { password: string })[] = demoProfiles.map((p) => ({ ...p }));
  private properties: Property[] = demoProperties.map((p) => ({ ...p }));
  private images = demoImages.map((i) => ({ ...i }));
  private amenities: Amenity[] = demoAmenities.map((a) => ({ ...a }));
  private propertyAmenities = demoPropertyAmenities.map((a) => ({ ...a }));
  private favorites: Array<{ user_id: string; property_id: string; created_at: string }> = [];
  private conversations = demoConversations.map((c) => ({ ...c }));
  private messages = demoMessages.map((m) => ({ ...m }));
  private reviews = demoReviews.map((r) => ({ ...r }));
  private inquiries = demoInquiries.map((i) => ({ ...i }));
  private reports = demoReports.map((r) => ({ ...r }));

  // ---------- profiles ----------
  async getProfileById(id: string): Promise<Profile | null> {
    const p = this.profiles.find((x) => x.id === id);
    if (!p) return null;
    const { password: _pw, ...rest } = p;
    return { ...rest };
  }

  async getProfileByEmail(email: string): Promise<Profile | null> {
    const p = this.profiles.find((x) => x.email?.toLowerCase() === email.toLowerCase());
    if (!p) return null;
    const { password: _pw, ...rest } = p;
    return { ...rest };
  }

  async createUser(input: {
    id?: string;
    email: string;
    password?: string;
    full_name: string;
    phone?: string | null;
  }): Promise<Profile> {
    if (await this.getProfileByEmail(input.email)) {
      throw new Error('Email tayari inatumika. Tumia nyingine au ingia.');
    }
    const profile = {
      id: input.id || crypto.randomUUID(),
      full_name: input.full_name,
      phone: input.phone || null,
      email: input.email,
      avatar_url: null,
      bio: '',
      role: 'USER' as Role,
      is_host: false,
      host_status: 'none' as const,
      is_verified: false,
      password: input.password || '',
      created_at: nowISO(),
      updated_at: nowISO(),
    };
    this.profiles.push(profile);
    const { password: _pw, ...rest } = profile;
    return { ...rest };
  }

  async updateProfile(id: string, patch: Partial<Profile>): Promise<Profile> {
    const p = this.profiles.find((x) => x.id === id);
    if (!p) throw new Error('Profile not found');
    const allowed: Partial<Profile> = {};
    if (patch.full_name !== undefined) allowed.full_name = patch.full_name;
    if (patch.phone !== undefined) allowed.phone = patch.phone;
    if (patch.email !== undefined) allowed.email = patch.email;
    if (patch.avatar_url !== undefined) allowed.avatar_url = patch.avatar_url;
    if (patch.bio !== undefined) allowed.bio = patch.bio;
    Object.assign(p, allowed, { updated_at: nowISO() });
    const { password: _pw, ...rest } = p;
    return { ...rest };
  }

  async listUsers(page: number, pageSize: number): Promise<{ items: Profile[]; total: number }> {
    const items = this.profiles
      .slice()
      .sort((a, b) => b.created_at.localeCompare(a.created_at))
      .slice((page - 1) * pageSize, page * pageSize)
      .map(({ password: _pw, ...rest }) => rest as Profile);
    return { items, total: this.profiles.length };
  }

  async setUserRole(id: string, role: Role): Promise<Profile> {
    const p = this.profiles.find((x) => x.id === id);
    if (!p) throw new Error('Profile not found');
    p.role = role;
    if (role === 'HOST') {
      p.is_host = true;
      p.host_status = 'approved';
    }
    p.updated_at = nowISO();
    const { password: _pw, ...rest } = p;
    return { ...rest };
  }

  async setUserVerified(id: string, isVerified: boolean): Promise<Profile> {
    const p = this.profiles.find((x) => x.id === id);
    if (!p) throw new Error('Profile not found');
    p.is_verified = isVerified;
    if (isVerified && !p.is_host) {
      p.is_host = true;
      p.host_status = 'approved';
      p.role = 'HOST';
    }
    p.updated_at = nowISO();
    const { password: _pw, ...rest } = p;
    return { ...rest };
  }

  async verifyDemoCredentials(email: string, password: string): Promise<Profile | null> {
    const p = this.profiles.find(
      (x) => x.email?.toLowerCase() === email.toLowerCase() && x.password === password
    );
    if (!p) return null;
    const { password: _pw, ...rest } = p;
    return { ...rest };
  }

  // ---------- amenities ----------
  async listAmenities(): Promise<Amenity[]> {
    return this.amenities.map((a) => ({ ...a }));
  }

  async resolveAmenities(names: string[]): Promise<Amenity[]> {
    const out: Amenity[] = [];
    for (const name of names) {
      let a = this.amenities.find((x) => x.name.toLowerCase() === name.toLowerCase());
      if (!a) {
        a = { id: crypto.randomUUID(), name };
        this.amenities.push(a);
      }
      out.push(a);
    }
    return out;
  }

  // ---------- property composition ----------
  private publicHost(hostId: string): PublicHost | null {
    const p = this.profiles.find((x) => x.id === hostId);
    if (!p) return null;
    return {
      id: p.id,
      full_name: p.full_name,
      avatar_url: p.avatar_url,
      is_verified: p.is_verified,
      phone: p.phone,
      created_at: p.created_at,
    };
  }

  private enrich(p: Property): PropertyFull {
    const imgs = this.images
      .filter((i) => i.property_id === p.id)
      .sort((a, b) => a.sort_order - b.sort_order || (b.is_cover ? 1 : 0) - (a.is_cover ? 1 : 0));
    const names = this.propertyAmenities
      .filter((pa) => pa.property_id === p.id)
      .map((pa) => pa.amenity);
    const revs = this.reviews.filter((r) => r.property_id === p.id);
    const ratingAvg = revs.length ? revs.reduce((s, r) => s + r.rating, 0) / revs.length : 0;
    const available =
      !p.availability_date || new Date(p.availability_date).getTime() <= Date.now();
    return {
      ...p,
      images: imgs.map((i) => ({ ...i })),
      amenities: names,
      host: this.publicHost(p.host_id),
      rating_avg: Math.round(ratingAvg * 10) / 10,
      rating_count: revs.length,
      is_available_now: available,
    };
  }

  // ---------- properties ----------
  async searchProperties(
    params: SearchParams
  ): Promise<{ items: PropertyFull[]; total: number }> {
    const page = params.page || 1;
    const pageSize = params.page_size || 10;
    let list = this.properties.filter((p) => p.status === 'approved');

    if (params.q) {
      const q = params.q.toLowerCase();
      list = list.filter((p) =>
        [p.title, p.region, p.city, p.district, p.neighborhood, p.street, p.landmark, p.property_type]
          .filter(Boolean)
          .some((f) => String(f).toLowerCase().includes(q))
      );
    }
    if (params.property_type) list = list.filter((p) => p.property_type === params.property_type);
    if (params.min_price !== undefined) list = list.filter((p) => p.price_monthly >= params.min_price!);
    if (params.max_price !== undefined) list = list.filter((p) => p.price_monthly <= params.max_price!);
    if (params.bedrooms !== undefined) list = list.filter((p) => p.bedrooms >= params.bedrooms!);
    if (params.bathrooms !== undefined) list = list.filter((p) => p.bathrooms >= params.bathrooms!);
    if (params.furnished !== undefined) list = list.filter((p) => p.furnished === params.furnished);
    if (params.region) {
      const r = params.region.toLowerCase();
      list = list.filter((p) => p.region?.toLowerCase().includes(r));
    }
    if (params.city) {
      const c = params.city.toLowerCase();
      list = list.filter((p) => p.city?.toLowerCase().includes(c));
    }
    if (params.available_now) {
      list = list.filter(
        (p) => !p.availability_date || new Date(p.availability_date).getTime() <= Date.now()
      );
    }
    if (params.amenities && params.amenities.length) {
      list = list.filter((p) => {
        const names = this.propertyAmenities
          .filter((pa) => pa.property_id === p.id)
          .map((pa) => pa.amenity.toLowerCase());
        return params.amenities!.every((a) => names.includes(a.toLowerCase()));
      });
    }

    let full = list.map((p) => this.enrich(p));
    switch (params.sort) {
      case 'price_asc':
        full.sort((a, b) => a.price_monthly - b.price_monthly);
        break;
      case 'price_desc':
        full.sort((a, b) => b.price_monthly - a.price_monthly);
        break;
      case 'distance':
        full.sort((a, b) => {
          const da = this.dist(a, params.near_lat, params.near_lng);
          const db = this.dist(b, params.near_lat, params.near_lng);
          return da - db;
        });
        break;
      case 'recommended':
        full.sort(
          (a, b) =>
            Number(b.is_featured) - Number(a.is_featured) ||
            b.rating_avg - a.rating_avg ||
            b.views_count - a.views_count
        );
        break;
      default:
        full.sort((a, b) => b.created_at.localeCompare(a.created_at));
    }

    const total = full.length;
    return { items: full.slice((page - 1) * pageSize, page * pageSize), total };
  }

  private dist(p: PropertyFull, lat?: number, lng?: number): number {
    if (!lat || !lng || p.latitude == null || p.longitude == null) return Number.MAX_VALUE;
    return haversineKm(lat, lng, p.latitude, p.longitude);
  }

  async getProperty(id: string): Promise<PropertyFull | null> {
    const p = this.properties.find((x) => x.id === id);
    return p ? this.enrich(p) : null;
  }

  async getPropertyRaw(id: string): Promise<Property | null> {
    const p = this.properties.find((x) => x.id === id);
    return p ? { ...p } : null;
  }

  async createProperty(input: {
    host_id: string;
    data: Record<string, unknown>;
    amenities: string[];
    images: Array<{ image_url: string; storage_path?: string | null; category?: string; is_cover?: boolean; sort_order?: number }>;
    status: PropertyStatus;
    is_featured?: boolean;
  }): Promise<PropertyFull> {
    const d = input.data;
    const prop: Property = {
      id: crypto.randomUUID(),
      host_id: input.host_id,
      title: String(d.title || 'Nyumba bila jina'),
      description: String(d.description || ''),
      property_type: d.property_type as Property['property_type'],
      status: input.status,
      price_monthly: Number(d.price_monthly || 0),
      price_weekly: d.price_weekly != null ? Number(d.price_weekly) : null,
      price_daily: d.price_daily != null ? Number(d.price_daily) : null,
      bedrooms: Number(d.bedrooms || 1),
      bathrooms: Number(d.bathrooms || 1),
      size_m2: d.size_m2 != null ? Number(d.size_m2) : null,
      floor_number: d.floor_number != null ? Number(d.floor_number) : null,
      furnished: Boolean(d.furnished),
      max_occupants: d.max_occupants != null ? Number(d.max_occupants) : null,
      house_rules: (d.house_rules as string) || null,
      latitude: d.latitude != null ? Number(d.latitude) : null,
      longitude: d.longitude != null ? Number(d.longitude) : null,
      country: String(d.country || 'Tanzania'),
      region: (d.region as string) || null,
      city: (d.city as string) || null,
      district: (d.district as string) || null,
      neighborhood: (d.neighborhood as string) || null,
      street: (d.street as string) || null,
      landmark: (d.landmark as string) || null,
      availability_date: (d.availability_date as string) || null,
      is_featured: Boolean(input.is_featured),
      views_count: 0,
      favorites_count: 0,
      rejection_reason: null,
      reviewed_at: null,
      created_at: nowISO(),
      updated_at: nowISO(),
    };
    this.properties.push(prop);

    for (const name of input.amenities) {
      const a = await this.resolveAmenities([name]);
      this.propertyAmenities.push({ property_id: prop.id, amenity: a[0].name });
    }
    input.images.forEach((img, idx) => {
      this.images.push({
        id: crypto.randomUUID(),
        property_id: prop.id,
        image_url: img.image_url,
        storage_path: img.storage_path || null,
        category: (img.category as PropertyFull['images'][number]['category']) || 'OTHER',
        sort_order: img.sort_order ?? idx,
        is_cover: Boolean(img.is_cover) || idx === 0,
        created_at: nowISO(),
      });
    });
    return this.enrich(prop);
  }

  async updateProperty(
    id: string,
    patch: Record<string, unknown>,
    amenities?: string[],
    images?: Array<{ id?: string; image_url: string; storage_path?: string | null; category?: string; is_cover?: boolean; sort_order?: number }> | null
  ): Promise<PropertyFull> {
    const p = this.properties.find((x) => x.id === id);
    if (!p) throw new Error('Property not found');
    const numericFields = [
      'price_monthly', 'price_weekly', 'price_daily', 'bedrooms', 'bathrooms',
      'size_m2', 'floor_number', 'max_occupants', 'latitude', 'longitude',
    ];
    const stringFields = [
      'title', 'description', 'property_type', 'country', 'region', 'city', 'district',
      'neighborhood', 'street', 'landmark', 'availability_date', 'house_rules',
    ];
    for (const k of stringFields) {
      if (patch[k] !== undefined) (p as unknown as Record<string, unknown>)[k] = patch[k];
    }
    for (const k of numericFields) {
      if (patch[k] !== undefined && patch[k] !== null && patch[k] !== '') {
        (p as unknown as Record<string, unknown>)[k] = Number(patch[k]);
      }
    }
    if (patch.furnished !== undefined) p.furnished = Boolean(patch.furnished);
    p.updated_at = nowISO();

    if (amenities) {
      this.propertyAmenities = this.propertyAmenities.filter((pa) => pa.property_id !== id);
      for (const name of amenities) {
        const a = await this.resolveAmenities([name]);
        this.propertyAmenities.push({ property_id: id, amenity: a[0].name });
      }
    }
    if (images) {
      this.images = this.images.filter((i) => i.property_id !== id);
      images.forEach((img, idx) => {
        this.images.push({
          id: img.id || crypto.randomUUID(),
          property_id: id,
          image_url: img.image_url,
          storage_path: img.storage_path || null,
          category: (img.category as PropertyFull['images'][number]['category']) || 'OTHER',
          sort_order: img.sort_order ?? idx,
          is_cover: Boolean(img.is_cover) || idx === 0,
          created_at: nowISO(),
        });
      });
    }
    return this.enrich(p);
  }

  async deleteProperty(id: string): Promise<void> {
    this.properties = this.properties.filter((p) => p.id !== id);
    this.images = this.images.filter((i) => i.property_id !== id);
    this.propertyAmenities = this.propertyAmenities.filter((pa) => pa.property_id !== id);
    this.favorites = this.favorites.filter((f) => f.property_id !== id);
  }

  async listHostProperties(hostId: string, status?: PropertyStatus): Promise<PropertyFull[]> {
    let list = this.properties.filter((p) => p.host_id === hostId);
    if (status) list = list.filter((p) => p.status === status);
    return list
      .sort((a, b) => b.updated_at.localeCompare(a.updated_at))
      .map((p) => this.enrich(p));
  }

  async incrementViews(id: string): Promise<void> {
    const p = this.properties.find((x) => x.id === id);
    if (p) p.views_count += 1;
  }

  async setPropertyStatus(id: string, status: PropertyStatus, reason?: string | null): Promise<Property> {
    const p = this.properties.find((x) => x.id === id);
    if (!p) throw new Error('Property not found');
    p.status = status;
    p.rejection_reason = status === 'rejected' ? reason || 'Haitoshi vigezo' : null;
    p.reviewed_at = nowISO();
    p.updated_at = nowISO();
    return { ...p };
  }

  // ---------- favorites ----------
  async addFavorite(userId: string, propertyId: string): Promise<void> {
    if (!this.favorites.some((f) => f.user_id === userId && f.property_id === propertyId)) {
      this.favorites.push({ user_id: userId, property_id: propertyId, created_at: nowISO() });
    }
  }

  async removeFavorite(userId: string, propertyId: string): Promise<void> {
    this.favorites = this.favorites.filter(
      (f) => !(f.user_id === userId && f.property_id === propertyId)
    );
  }

  async listFavorites(userId: string): Promise<PropertyFull[]> {
    const ids = this.favorites.filter((f) => f.user_id === userId).map((f) => f.property_id);
    return this.properties
      .filter((p) => ids.includes(p.id))
      .sort((a, b) => b.created_at.localeCompare(a.created_at))
      .map((p) => this.enrich(p));
  }

  async isFavorite(userId: string, propertyId: string): Promise<boolean> {
    return this.favorites.some((f) => f.user_id === userId && f.property_id === propertyId);
  }

  async listFavoriteIds(userId: string): Promise<string[]> {
    return this.favorites.filter((f) => f.user_id === userId).map((f) => f.property_id);
  }

  // ---------- conversations ----------
  async upsertConversation(userId: string, propertyId: string): Promise<string> {
    const prop = this.properties.find((p) => p.id === propertyId);
    if (!prop) throw new Error('Property not found');
    const existing = this.conversations.find(
      (c) => c.property_id === propertyId && c.participant_ids.includes(userId)
    );
    if (existing) return existing.id;
    const conv = {
      id: crypto.randomUUID(),
      property_id: propertyId,
      participant_ids: [...new Set([userId, prop.host_id])],
      created_at: nowISO(),
      updated_at: nowISO(),
    };
    this.conversations.push(conv);
    return conv.id;
  }

  private convSummary(c: (typeof this.conversations)[number], viewerId: string): ConversationSummary {
    const prop = this.properties.find((p) => p.id === c.property_id);
    const otherId = c.participant_ids.find((id) => id !== viewerId);
    const other = otherId ? this.publicHost(otherId) || null : null;
    const msgs = this.messages
      .filter((m) => m.conversation_id === c.id)
      .sort((a, b) => a.created_at.localeCompare(b.created_at));
    const unread = msgs.filter((m) => m.sender_id !== viewerId && !m.read_at).length;
    return {
      id: c.id,
      property_id: c.property_id,
      created_at: c.created_at,
      updated_at: c.updated_at,
      property: prop
        ? {
            id: prop.id,
            title: prop.title,
            image_url: this.images.find((i) => i.property_id === prop.id && i.is_cover)?.image_url || null,
            price_monthly: prop.price_monthly,
          }
        : null,
      other_participant: other
        ? { id: other.id, full_name: other.full_name, avatar_url: other.avatar_url }
        : null,
      last_message: msgs.length ? msgs[msgs.length - 1].message : null,
      unread_count: unread,
    };
  }

  async listConversations(userId: string): Promise<ConversationSummary[]> {
    return this.conversations
      .filter((c) => c.participant_ids.includes(userId))
      .sort((a, b) => b.updated_at.localeCompare(a.updated_at))
      .map((c) => this.convSummary(c, userId));
  }

  async isParticipant(conversationId: string, userId: string): Promise<boolean> {
    const c = this.conversations.find((x) => x.id === conversationId);
    return Boolean(c && c.participant_ids.includes(userId));
  }

  async getConversationProperty(conversationId: string): Promise<ConversationSummary['property']> {
    const c = this.conversations.find((x) => x.id === conversationId);
    if (!c) return null;
    const prop = this.properties.find((p) => p.id === c.property_id);
    if (!prop) return null;
    return {
      id: prop.id,
      title: prop.title,
      image_url: this.images.find((i) => i.property_id === prop.id && i.is_cover)?.image_url || null,
      price_monthly: prop.price_monthly,
    };
  }

  async listMessages(conversationId: string): Promise<Message[]> {
    return this.messages
      .filter((m) => m.conversation_id === conversationId)
      .sort((a, b) => a.created_at.localeCompare(b.created_at))
      .map((m) => ({ ...m }));
  }

  async sendMessage(conversationId: string, senderId: string, message: string): Promise<Message> {
    const msg: Message = {
      id: crypto.randomUUID(),
      conversation_id: conversationId,
      sender_id: senderId,
      message,
      read_at: null,
      created_at: nowISO(),
    };
    this.messages.push(msg);
    const c = this.conversations.find((x) => x.id === conversationId);
    if (c) c.updated_at = msg.created_at;
    return { ...msg };
  }

  async markConversationRead(conversationId: string, userId: string): Promise<void> {
    for (const m of this.messages) {
      if (m.conversation_id === conversationId && m.sender_id !== userId && !m.read_at) {
        m.read_at = nowISO();
      }
    }
  }

  // ---------- reviews ----------
  async listReviews(propertyId: string): Promise<Review[]> {
    return this.reviews
      .filter((r) => r.property_id === propertyId)
      .sort((a, b) => b.created_at.localeCompare(a.created_at))
      .map((r) => {
        const u = this.profiles.find((p) => p.id === r.reviewer_id);
        return {
          ...r,
          reviewer: u ? { id: u.id, full_name: u.full_name, avatar_url: u.avatar_url } : null,
        };
      });
  }

  async createReview(reviewerId: string, propertyId: string, rating: number, comment: string): Promise<Review> {
    const prop = this.properties.find((p) => p.id === propertyId);
    if (!prop) throw new Error('Property not found');
    if (prop.host_id === reviewerId) throw new Error('Huwezi kupima nyumba yako mwenyewe.');
    if (this.reviews.some((r) => r.property_id === propertyId && r.reviewer_id === reviewerId)) {
      throw new Error('Umeshatoa maoni kwa nyumba hii.');
    }
    const review: Review = {
      id: crypto.randomUUID(),
      property_id: propertyId,
      reviewer_id: reviewerId,
      host_id: prop.host_id,
      rating,
      comment,
      created_at: nowISO(),
    };
    this.reviews.push(review);
    return { ...review };
  }

  async listMyReviews(userId: string): Promise<Review[]> {
    return this.reviews
      .filter((r) => r.reviewer_id === userId)
      .sort((a, b) => b.created_at.localeCompare(a.created_at))
      .map((r) => {
        const prop = this.properties.find((p) => p.id === r.property_id);
        return { ...r, reviewer: null, comment: prop ? `[${prop.title}] ${r.comment}` : r.comment };
      });
  }

  // ---------- inquiries ----------
  async createInquiry(userId: string, propertyId: string, message: string): Promise<Inquiry> {
    const prop = this.properties.find((p) => p.id === propertyId);
    if (!prop) throw new Error('Property not found');
    const inq: Inquiry = {
      id: crypto.randomUUID(),
      property_id: propertyId,
      user_id: userId,
      message,
      status: 'new',
      created_at: nowISO(),
    };
    this.inquiries.push(inq);
    return {
      ...inq,
      property: {
        id: prop.id,
        title: prop.title,
        image_url: this.images.find((i) => i.property_id === prop.id && i.is_cover)?.image_url || null,
        price_monthly: prop.price_monthly,
      },
    };
  }

  async listMyInquiries(userId: string): Promise<Inquiry[]> {
    return this.inquiries
      .filter((i) => i.user_id === userId)
      .sort((a, b) => b.created_at.localeCompare(a.created_at))
      .map((i) => {
        const prop = this.properties.find((p) => p.id === i.property_id);
        return {
          ...i,
          property: prop
            ? {
                id: prop.id,
                title: prop.title,
                image_url: this.images.find((im) => im.property_id === prop.id && im.is_cover)?.image_url || null,
                price_monthly: prop.price_monthly,
              }
            : null,
        };
      });
  }

  async listHostInquiries(hostId: string): Promise<Inquiry[]> {
    const myProps = new Set(this.properties.filter((p) => p.host_id === hostId).map((p) => p.id));
    return this.inquiries
      .filter((i) => myProps.has(i.property_id))
      .sort((a, b) => b.created_at.localeCompare(a.created_at))
      .map((i) => {
        const prop = this.properties.find((p) => p.id === i.property_id);
        const user = this.profiles.find((p) => p.id === i.user_id);
        return {
          ...i,
          property: prop
            ? { id: prop.id, title: prop.title, image_url: null, price_monthly: prop.price_monthly }
            : null,
          user: user ? { id: user.id, full_name: user.full_name, avatar_url: user.avatar_url, phone: user.phone } : null,
        };
      });
  }

  async setInquiryStatus(hostId: string, inquiryId: string, status: InquiryStatus): Promise<Inquiry> {
    const i = this.inquiries.find((x) => x.id === inquiryId);
    if (!i) throw new Error('Inquiry not found');
    const prop = this.properties.find((p) => p.id === i.property_id);
    if (!prop || prop.host_id !== hostId) throw new Error('Not allowed');
    i.status = status;
    return { ...i };
  }

  // ---------- reports ----------
  async createReport(reporterId: string, propertyId: string, reason: ReportReason, details: string): Promise<Report> {
    const report: Report = {
      id: crypto.randomUUID(),
      property_id: propertyId,
      reporter_id: reporterId,
      reason,
      details,
      status: 'open',
      created_at: nowISO(),
    };
    this.reports.push(report);
    return { ...report };
  }

  async listReports(status?: ReportStatus): Promise<Report[]> {
    let list = this.reports.slice().sort((a, b) => b.created_at.localeCompare(a.created_at));
    if (status) list = list.filter((r) => r.status === status);
    return list.map((r) => {
      const prop = this.properties.find((p) => p.id === r.property_id);
      return { ...r, property_title: prop?.title || null };
    });
  }

  async setReportStatus(id: string, status: ReportStatus): Promise<Report> {
    const r = this.reports.find((x) => x.id === id);
    if (!r) throw new Error('Report not found');
    r.status = status;
    return { ...r };
  }

  // ---------- host / admin ----------
  async applyHost(profile: Profile, input: { full_name: string; phone: string; email: string }): Promise<Profile> {
    const p = this.profiles.find((x) => x.id === profile.id);
    if (!p) throw new Error('Profile not found');
    p.full_name = input.full_name || p.full_name;
    p.phone = input.phone || p.phone;
    p.email = input.email || p.email;
    p.is_host = true;
    p.host_status = 'approved';
    p.role = 'HOST';
    p.updated_at = nowISO();
    const { password: _pw, ...rest } = p;
    return { ...rest };
  }

  async adminStats(): Promise<AdminStats> {
    const byStatus = (s: PropertyStatus) => this.properties.filter((p) => p.status === s).length;
    return {
      total_users: this.profiles.length,
      total_hosts: this.profiles.filter((p) => p.is_host).length,
      total_properties: this.properties.length,
      pending_listings: byStatus('pending'),
      approved_listings: byStatus('approved'),
      rejected_listings: byStatus('rejected'),
      suspended_listings: byStatus('suspended'),
      open_reports: this.reports.filter((r) => r.status === 'open').length,
    };
  }

  async adminListProperties(
    status?: PropertyStatus,
    page = 1,
    pageSize = 50
  ): Promise<{ items: PropertyFull[]; total: number }> {
    let list = this.properties.slice().sort((a, b) => b.created_at.localeCompare(a.created_at));
    if (status) list = list.filter((p) => p.status === status);
    return {
      items: list.slice((page - 1) * pageSize, page * pageSize).map((p) => this.enrich(p)),
      total: list.length,
    };
  }
}
