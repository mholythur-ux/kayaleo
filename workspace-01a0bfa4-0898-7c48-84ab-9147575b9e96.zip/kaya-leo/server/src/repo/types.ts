import {
  AdminStats,
  Amenity,
  ConversationSummary,
  Inquiry,
  InquiryStatus,
  Message,
  Profile,
  Property,
  PropertyFull,
  PropertyStatus,
  Report,
  ReportReason,
  ReportStatus,
  Review,
  Role,
  SearchParams,
} from '../types';

/**
 * Single data-access contract. Two implementations:
 *   - repo/memory.ts    (DATA_MODE=demo — zero-dependency, seeded)
 *   - repo/supabase.ts  (DATA_MODE=supabase — production PostgreSQL)
 * Adding AWS S3 later only touches storageService, not this layer.
 */
export interface DataRepo {
  // ----- profiles / users -----
  getProfileById(id: string): Promise<Profile | null>;
  getProfileByEmail(email: string): Promise<Profile | null>;
  createUser(input: {
    id?: string;
    email: string;
    password?: string;
    full_name: string;
    phone?: string | null;
  }): Promise<Profile>;
  updateProfile(id: string, patch: Partial<Profile>): Promise<Profile>;
  listUsers(page: number, pageSize: number): Promise<{ items: Profile[]; total: number }>;
  setUserRole(id: string, role: Role): Promise<Profile>;
  setUserVerified(id: string, isVerified: boolean): Promise<Profile>;

  // ----- auth (demo mode only; supabase impl uses Supabase Auth) -----
  verifyDemoCredentials(email: string, password: string): Promise<Profile | null>;

  // ----- amenities -----
  listAmenities(): Promise<Amenity[]>;
  resolveAmenities(names: string[]): Promise<Amenity[]>;

  // ----- properties -----
  searchProperties(params: SearchParams): Promise<{ items: PropertyFull[]; total: number }>;
  getProperty(id: string): Promise<PropertyFull | null>;
  getPropertyRaw(id: string): Promise<Property | null>;
  createProperty(input: {
    host_id: string;
    data: Record<string, unknown>;
    amenities: string[];
    images: Array<{ image_url: string; storage_path?: string | null; category?: string; is_cover?: boolean; sort_order?: number }>;
    status: PropertyStatus;
    is_featured?: boolean;
  }): Promise<PropertyFull>;
  updateProperty(
    id: string,
    patch: Record<string, unknown>,
    amenities?: string[],
    images?: Array<{ id?: string; image_url: string; storage_path?: string | null; category?: string; is_cover?: boolean; sort_order?: number }> | null
  ): Promise<PropertyFull>;
  deleteProperty(id: string): Promise<void>;
  listHostProperties(hostId: string, status?: PropertyStatus): Promise<PropertyFull[]>;
  incrementViews(id: string): Promise<void>;
  setPropertyStatus(id: string, status: PropertyStatus, reason?: string | null): Promise<Property>;

  // ----- favorites -----
  addFavorite(userId: string, propertyId: string): Promise<void>;
  removeFavorite(userId: string, propertyId: string): Promise<void>;
  listFavorites(userId: string): Promise<PropertyFull[]>;
  isFavorite(userId: string, propertyId: string): Promise<boolean>;
  listFavoriteIds(userId: string): Promise<string[]>;

  // ----- conversations / messages -----
  upsertConversation(userId: string, propertyId: string): Promise<string>;
  listConversations(userId: string): Promise<ConversationSummary[]>;
  isParticipant(conversationId: string, userId: string): Promise<boolean>;
  getConversationProperty(conversationId: string): Promise<ConversationSummary['property']>;
  listMessages(conversationId: string): Promise<Message[]>;
  sendMessage(conversationId: string, senderId: string, message: string): Promise<Message>;
  markConversationRead(conversationId: string, userId: string): Promise<void>;

  // ----- reviews -----
  listReviews(propertyId: string): Promise<Review[]>;
  createReview(reviewerId: string, propertyId: string, rating: number, comment: string): Promise<Review>;
  listMyReviews(userId: string): Promise<Review[]>;

  // ----- inquiries -----
  createInquiry(userId: string, propertyId: string, message: string): Promise<Inquiry>;
  listMyInquiries(userId: string): Promise<Inquiry[]>;
  listHostInquiries(hostId: string): Promise<Inquiry[]>;
  setInquiryStatus(hostId: string, inquiryId: string, status: InquiryStatus): Promise<Inquiry>;

  // ----- reports -----
  createReport(reporterId: string, propertyId: string, reason: ReportReason, details: string): Promise<Report>;
  listReports(status?: ReportStatus): Promise<Report[]>;
  setReportStatus(id: string, status: ReportStatus): Promise<Report>;

  // ----- host / admin -----
  applyHost(profile: Profile, input: { full_name: string; phone: string; email: string }): Promise<Profile>;
  adminStats(): Promise<AdminStats>;
  adminListProperties(status?: PropertyStatus, page?: number, pageSize?: number): Promise<{ items: PropertyFull[]; total: number }>;
}
