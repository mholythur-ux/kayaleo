import { env, requireSupabaseEnv } from '../config/env';
import { DataRepo } from './types';
import { MemoryRepo } from './memory';
import { SupabaseRepo } from './supabase';

let repoInstance: DataRepo | null = null;

export function repo(): DataRepo {
  if (!repoInstance) {
    if (env.dataMode === 'supabase') {
      requireSupabaseEnv();
      repoInstance = new SupabaseRepo();
    } else {
      repoInstance = new MemoryRepo();
    }
  }
  return repoInstance;
}

/** True when running without Supabase (demo data, demo tokens). */
export function isDemoMode(): boolean {
  return env.dataMode === 'demo';
}
