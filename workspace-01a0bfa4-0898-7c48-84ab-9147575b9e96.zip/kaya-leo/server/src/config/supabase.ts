import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { env } from './env';

/**
 * Service-role client — SERVER SIDE ONLY.
 * The server re-validates ownership on every write (see controllers),
 * and the database additionally enforces RLS (database/migrations/002_rls.sql).
 * The service key must never be bundled into the mobile app.
 */
let serviceClient: SupabaseClient | null = null;

export function getServiceClient(): SupabaseClient {
  if (!serviceClient) {
    serviceClient = createClient(env.supabaseUrl, env.supabaseServiceRoleKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
  }
  return serviceClient;
}

/** Anon client — used only for password grants on /auth/login. */
let anonClient: SupabaseClient | null = null;

export function getAnonClient(): SupabaseClient {
  if (!anonClient) {
    anonClient = createClient(
      env.supabaseUrl,
      env.supabaseAnonKey || env.supabaseServiceRoleKey,
      { auth: { persistSession: false, autoRefreshToken: false } }
    );
  }
  return anonClient;
}
