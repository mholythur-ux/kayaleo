import dotenv from 'dotenv';
dotenv.config();

export type DataMode = 'demo' | 'supabase';

export const env = {
  port: Number(process.env.PORT || 4000),
  dataMode: (process.env.DATA_MODE === 'supabase' ? 'supabase' : 'demo') as DataMode,
  supabaseUrl: process.env.SUPABASE_URL || '',
  supabaseServiceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY || '',
  supabaseAnonKey: process.env.SUPABASE_ANON_KEY || '',
  nominatimBaseUrl: process.env.NOMINATIM_BASE_URL || 'https://nominatim.openstreetmap.org',
  isProd: process.env.NODE_ENV === 'production',
};

export function requireSupabaseEnv(): void {
  if (!env.supabaseUrl || !env.supabaseServiceRoleKey) {
    throw new Error(
      'DATA_MODE=supabase requires SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY. ' +
        'See server/.env.example, or set DATA_MODE=demo.'
    );
  }
}
