import { z } from 'zod';

export const registerSchema = z.object({
  full_name: z.string().min(2, 'Jina kamili linahitajika'),
  phone: z.string().min(7, 'Namba ya simu si sahihi').max(20).optional().or(z.literal('')),
  email: z.string().email('Barua pepe si sahihi'),
  password: z.string().min(8, 'Nenosiri linahitaji herufi 8 au zaidi'),
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

export const profileUpdateSchema = z
  .object({
    full_name: z.string().min(2).optional(),
    phone: z.string().min(7).max(20).nullable().optional(),
    email: z.string().email().optional(),
    avatar_url: z.string().url().nullable().optional(),
    bio: z.string().max(500).nullable().optional(),
  })
  .strict();

export const hostApplySchema = z.object({
  full_name: z.string().min(2),
  phone: z.string().min(7),
  email: z.string().email(),
});

const locationSchema = z
  .object({
    latitude: z.number().min(-90).max(90).nullable().optional(),
    longitude: z.number().min(-180).max(180).nullable().optional(),
    country: z.string().default('Tanzania'),
    region: z.string().max(100).nullable().optional(),
    city: z.string().max(100).nullable().optional(),
    district: z.string().max(100).nullable().optional(),
    neighborhood: z.string().max(100).nullable().optional(),
    street: z.string().max(200).nullable().optional(),
    landmark: z.string().max(200).nullable().optional(),
  })
  .partial({ region: true, city: true });

export const propertyCreateSchema = z.object({
  title: z.string().min(4, 'Kichwa cha tangazo kinahitajika').max(120),
  description: z.string().max(4000).default(''),
  property_type: z.enum(['APARTMENT', 'HOUSE', 'ROOM']),
  price_monthly: z.number().min(0),
  price_weekly: z.number().min(0).nullable().optional(),
  price_daily: z.number().min(0).nullable().optional(),
  bedrooms: z.number().int().min(0).max(50).default(1),
  bathrooms: z.number().int().min(0).max(50).default(1),
  size_m2: z.number().min(0).nullable().optional(),
  floor_number: z.number().int().nullable().optional(),
  furnished: z.boolean().default(false),
  max_occupants: z.number().int().min(1).nullable().optional(),
  house_rules: z.string().max(1000).nullable().optional(),
  availability_date: z.string().date().nullable().optional(),
  status: z.enum(['draft', 'pending']).default('pending'),
  amenities: z.array(z.string().min(1).max(60)).max(40).default([]),
  images: z
    .array(
      z.object({
        image_url: z.string().url(),
        storage_path: z.string().max(500).nullable().optional(),
        category: z.enum(['EXTERIOR', 'LIVING_ROOM', 'BEDROOM', 'BATHROOM', 'KITCHEN', 'OTHER']).default('OTHER'),
        is_cover: z.boolean().default(false),
        sort_order: z.number().int().default(0),
      })
    )
    .max(30)
    .default([]),
}).merge(locationSchema);

export const propertyUpdateSchema = propertyCreateSchema
  .partial()
  .extend({ amenities: z.array(z.string().min(1).max(60)).max(40).optional() })
  .omit({ status: true });

export const imagesReplaceSchema = z.object({
  images: z
    .array(
      z.object({
        image_url: z.string().url(),
        storage_path: z.string().max(500).nullable().optional(),
        category: z.enum(['EXTERIOR', 'LIVING_ROOM', 'BEDROOM', 'BATHROOM', 'KITCHEN', 'OTHER']).default('OTHER'),
        is_cover: z.boolean().default(false),
        sort_order: z.number().int().default(0),
      })
    )
    .min(1)
    .max(30),
});

export const searchQuerySchema = z.object({
  q: z.string().max(120).optional(),
  property_type: z.enum(['APARTMENT', 'HOUSE', 'ROOM']).optional(),
  min_price: z.coerce.number().min(0).optional(),
  max_price: z.coerce.number().min(0).optional(),
  bedrooms: z.coerce.number().int().min(0).optional(),
  bathrooms: z.coerce.number().int().min(0).optional(),
  amenities: z.string().optional(), // comma separated names
  furnished: z.enum(['true', 'false']).optional(),
  available_now: z.enum(['true', 'false']).optional(),
  region: z.string().max(100).optional(),
  city: z.string().max(100).optional(),
  near_lat: z.coerce.number().optional(),
  near_lng: z.coerce.number().optional(),
  sort: z.enum(['newest', 'price_asc', 'price_desc', 'distance', 'recommended']).default('recommended'),
  page: z.coerce.number().int().min(1).default(1),
  page_size: z.coerce.number().int().min(1).max(50).default(10),
});

export const messageSchema = z.object({
  message: z.string().trim().min(1, 'Ujumbe haupaswi kuwa mtupu').max(2000),
});

export const reviewSchema = z.object({
  rating: z.number().int().min(1).max(5),
  comment: z.string().max(1000).default(''),
});

export const inquirySchema = z.object({
  message: z.string().trim().min(5, 'Andika ujumbe kwa mwenye nyumba').max(1000),
});

export const inquiryStatusSchema = z.object({
  status: z.enum(['new', 'contacted', 'closed']),
});

export const reportSchema = z.object({
  reason: z.enum([
    'FAKE_PROPERTY',
    'WRONG_INFORMATION',
    'SCAM_SUSPICIOUS',
    'INCORRECT_PRICE',
    'ALREADY_UNAVAILABLE',
    'INAPPROPRIATE_CONTENT',
    'OTHER',
  ]),
  details: z.string().max(1000).default(''),
});

export const moderationSchema = z.object({
  action: z.enum(['approve', 'reject', 'suspend', 'request_changes']),
  reason: z.string().max(500).optional(),
});

export const roleSchema = z.object({
  role: z.enum(['USER', 'HOST', 'ADMIN']),
});

export const verifiedSchema = z.object({
  is_verified: z.boolean(),
});

export const reportStatusSchema = z.object({
  status: z.enum(['open', 'resolved', 'dismissed']),
});
