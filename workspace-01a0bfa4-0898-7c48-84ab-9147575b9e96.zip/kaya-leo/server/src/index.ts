import { createApp } from './app';
import { env } from './config/env';

const app = createApp();

app.listen(env.port, '0.0.0.0', () => {
  // eslint-disable-next-line no-console
  console.log(`\n🏠 Kaya Leo API running on http://localhost:${env.port}`);
  // eslint-disable-next-line no-console
  console.log(`   DATA_MODE = ${env.dataMode.toUpperCase()}${env.dataMode === 'demo' ? '  (seeded in-memory — set DATA_MODE=supabase for production)' : ''}\n`);
});
