export type Role = 'USER' | 'HOST' | 'ADMIN';
export type HostStatus = 'none' | 'pending' | 'approved' | 'rejected';
export type PropertyType = 'APARTMENT' | 'HOUSE' | 'ROOM';
export type PropertyStatus = 'draft' | 'pending' | 'approved' | 'rejected' | 'suspended';
export type InquiryStatus = 'new' | 'contacted' | 'closed';
export type ReportReason =
  | 'FAKE_PROPERTY'
  | 'WRONG_INFORMATION'
  | 'SCAM_SUSPICIOUS'
  | 'INCORRECT_PRICE'
  | 'ALREADY_UNAVAILABLE'
  | 'INAPPROPRIATE_CONTENT'
  | 'OTHER';
export type ReportStatus = 'open' | 'resolved' | 'dismissed';
export type ImageCategory = 'EXTERIOR' | 'LIVING_ROOM' | 'BEDROOM' | 'BATHROOM' | 'KITCHEN' | 'OTHER';

export interface Profile {
  id: string;
  full_name: string;
  phone: string | null;
  email: string | null;
  avatar_url: string | null;
  bio: string | null;
  role: Role;
  is_host: boolean;
  host_status: HostStatus;
  is_verified: boolean;
  created_at: string;
  updated_at: string;
}

export interface PropertyImage {
  id: string;
  property_id: string;
  image_url: string;
  storage_path: string | null;
  category: ImageCategory;
  sort_order: number;
  is_cover: boolean;
  created_at: string;
}

export interface Property {
  id: string;
  host_id: string;
  title: string;
  description: string;
  property_type: PropertyType;
  status: PropertyStatus;
  price_monthly: number;
  price_weekly: number | null;
  price_daily: number | null;
  bedrooms: number;
  bathrooms: number;
  size_m2: number | null;
  floor_number: number | null;
  furnished: boolean;
  max_occupants: number | null;
  house_rules: string | null;
  latitude: number | null;
  longitude: number | null;
  country: string;
  region: string | null;
  city: string | null;
  district: string | null;
  neighborhood: string | null;
  street: string | null;
  landmark: string | null;
  availability_date: string | null;
  is_featured: boolean;
  views_count: number;
  favorites_count: number;
  rejection_reason: string | null;
  reviewed_at: string | null;
  created_at: string;
  updated_at: string;
}

/** Property enriched with images/amenities/host/rating for the API response. */
export interface PropertyFull extends Property {
  images: PropertyImage[];
  amenities: string[];
  host: PublicHost | null;
  rating_avg: number;
  rating_count: number;
  is_available_now: boolean;
}

export interface PublicHost {
  id: string;
  full_name: string;
  avatar_url: string | null;
  is_verified: boolean;
  phone: string | null;
  created_at: string;
}

export interface Amenity {
  id: string;
  name: string;
}

export interface Review {
  id: string;
  property_id: string;
  reviewer_id: string;
  host_id: string;
  rating: number;
  comment: string;
  created_at: string;
  reviewer?: { id: string; full_name: string; avatar_url: string | null } | null;
}

export interface Inquiry {
  id: string;
  property_id: string;
  user_id: string;
  message: string;
  status: InquiryStatus;
  created_at: string;
  property?: { id: string; title: string; image_url: string | null; price_monthly: number } | null;
  user?: { id: string; full_name: string; avatar_url: string | null; phone: string | null } | null;
}

export interface Report {
  id: string;
  property_id: string;
  reporter_id: string;
  reason: ReportReason;
  details: string;
  status: ReportStatus;
  created_at: string;
  property_title?: string | null;
}

export interface ConversationSummary {
  id: string;
  property_id: string;
  created_at: string;
  updated_at: string;
  property: { id: string; title: string; image_url: string | null; price_monthly: number } | null;
  other_participant: { id: string; full_name: string; avatar_url: string | null } | null;
  last_message: string | null;
  unread_count: number;
}

export interface Message {
  id: string;
  conversation_id: string;
  sender_id: string;
  message: string;
  read_at: string | null;
  created_at: string;
}

export interface Pagination<T> {
  items: T[];
  total: number;
  page: number;
  page_size: number;
  has_more: boolean;
}

export interface SearchParams {
  q?: string;
  property_type?: PropertyType;
  min_price?: number;
  max_price?: number;
  bedrooms?: number;
  bathrooms?: number;
  amenities?: string[];
  furnished?: boolean;
  available_now?: boolean;
  region?: string;
  city?: string;
  near_lat?: number;
  near_lng?: number;
  sort?: 'newest' | 'price_asc' | 'price_desc' | 'distance' | 'recommended';
  page?: number;
  page_size?: number;
}

export interface AdminStats {
  total_users: number;
  total_hosts: number;
  total_properties: number;
  pending_listings: number;
  approved_listings: number;
  rejected_listings: number;
  suspended_listings: number;
  open_reports: number;
}
