import { NextFunction, Request, Response } from 'express';
import { repo, isDemoMode } from '../repo';
import { getAnonClient, getServiceClient } from '../config/supabase';
import { AuthUser } from '../utils/authUser';
import { forbidden, unauthorized } from '../utils/httpError';

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      authUser?: AuthUser;
    }
  }
}

function bearerToken(req: Request): string | null {
  const h = req.headers.authorization || '';
  return h.startsWith('Bearer ') ? h.slice(7) : null;
}

/** Attaches req.authUser when a valid token is present; never rejects by itself. */
export async function optionalAuth(req: Request, _res: Response, next: NextFunction): Promise<void> {
  try {
    const token = bearerToken(req);
    if (!token) return next();

    if (isDemoMode()) {
      // Demo tokens look like "demo-<userId>"
      if (token.startsWith('demo-')) {
        const profile = await repo().getProfileById(token.slice(5));
        if (profile) {
          req.authUser = {
            id: profile.id,
            email: profile.email,
            role: profile.role,
            is_host: profile.is_host,
          };
        }
      }
      return next();
    }

    const {
      data: { user },
      error,
    } = await getServiceClient().auth.getUser(token);
    if (error || !user) return next();
    const profile = await repo().getProfileById(user.id);
    req.authUser = {
      id: user.id,
      email: user.email || profile?.email || null,
      role: profile?.role || 'USER',
      is_host: profile?.is_host || false,
    };
    return next();
  } catch (err) {
    next(err);
  }
}

/** Requires a valid token; optionalAuth must run first (mounted globally). */
export function requireAuth(req: Request, _res: Response, next: NextFunction): void {
  if (!req.authUser) throw unauthorized();
  next();
}

export function requireAdmin(req: Request, _res: Response, next: NextFunction): void {
  if (!req.authUser) throw unauthorized();
  if (req.authUser.role !== 'ADMIN') throw forbidden('Inahitaji uwe msimamizi (admin).');
  next();
}

export function requireHost(req: Request, _res: Response, next: NextFunction): void {
  if (!req.authUser) throw unauthorized();
  if (!req.authUser.is_host) throw forbidden('Jiunge na programu ya Kuwa Mwenye Nyumba kwanza.');
  next();
}

/** Verify email+password with Supabase Auth (supabase mode). */
export async function supabaseSignIn(email: string, password: string): Promise<{ userId: string; token: string }> {
  const { data, error } = await getAnonClient().auth.signInWithPassword({ email, password });
  if (error || !data.session) {
    throw unauthorized('Email au nenosiri si sahihi.');
  }
  return { userId: data.user.id, token: data.session.access_token };
}
