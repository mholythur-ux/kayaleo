import { NextFunction, Request, Response } from 'express';
import { HttpError } from '../utils/httpError';

export function notFoundHandler(_req: Request, res: Response): void {
  res.status(404).json({ error: 'Ruta haipatikani.' });
}

export function errorHandler(err: unknown, _req: Request, res: Response, _next: NextFunction): void {
  if (err instanceof HttpError) {
    res.status(err.status).json({ error: err.message });
    return;
  }
  const message = err instanceof Error ? err.message : 'Hitilafu ya seva. Jaribu tena.';
  // eslint-disable-next-line no-console
  console.error('[kaya-leo-api]', err);
  res.status(500).json({ error: message });
}
