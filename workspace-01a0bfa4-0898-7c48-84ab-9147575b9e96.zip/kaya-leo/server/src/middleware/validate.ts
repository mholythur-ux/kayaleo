import { NextFunction, Request, RequestHandler, Response } from 'express';
import { AnyZodObject, ZodError } from 'zod';
import { badRequest } from '../utils/httpError';

/**
 * Validate req.body / params / query against a zod schema.
 * Parsed (stripped) values are stored on res.locals and consumed
 * via the `queryOf()` helper — safe with Express 4 read-only query objects.
 */
export function validate(schema: AnyZodObject, source: 'body' | 'query' | 'params' = 'body'): RequestHandler {
  return (req: Request, res: Response, next: NextFunction): void => {
    try {
      const parsed = schema.parse(req[source]);
      if (source === 'body') req.body = parsed;
      else if (source === 'params') req.params = parsed as typeof req.params;
      res.locals.validated = { ...(res.locals.validated || {}), [source]: parsed };
      next();
    } catch (err) {
      if (err instanceof ZodError) {
        const first = err.errors[0];
        const path = first.path.join('.');
        next(badRequest(path ? `${path}: ${first.message}` : first.message));
      } else {
        next(err);
      }
    }
  };
}

export function queryOf(req: Request): Record<string, unknown> {
  return (req as Request & { res?: Response }).res?.locals?.validated?.query || req.query || {};
}
