import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { colors, radius, spacing, styles as s } from '../theme';

type Props = {
  title: string;
  subtitle: string;
  icon: 'home' | 'business' | 'bed';
  onPress: () => void;
  highlight?: boolean;
};

/** "Unatafuta nini?" category cards — Ghorofa / Nyumba / Chumba. */
export function CategoryCard({ title, subtitle, icon, onPress, highlight }: Props) {
  return (
    <Pressable
      onPress={onPress}
      style={[s.card, cat.card, highlight && { backgroundColor: '#F3F0FF', borderColor: '#E4D9FF' }]}
      android_ripple={{ color: colors.blue50 }}
    >
      <View style={cat.iconWrap}>
        <LinearGradient
          colors={highlight ? ['#8B5CF6', '#6D28D9'] : ['#3B82F6', '#1D4ED8']}
          style={cat.iconBg}
        >
          <Ionicons name={icon} size={26} color={colors.white} />
        </LinearGradient>
      </View>
      <View style={{ flex: 1 }}>
        <Text style={[cat.title, highlight && { color: '#6D28D9' }]}>{title}</Text>
        <Text style={cat.subtitle}>({subtitle})</Text>
      </View>
      <View style={cat.chevron}>
        <Ionicons name="chevron-forward" size={16} color={highlight ? '#8B5CF6' : colors.blue} />
      </View>
    </Pressable>
  );
}

const cat = StyleSheet.create({
  card: { flex: 1, padding: spacing.md, marginRight: spacing.md, minHeight: 108, justifyContent: 'space-between' },
  iconWrap: { marginBottom: spacing.sm },
  iconBg: { width: 46, height: 46, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  title: { fontSize: 15, fontWeight: '800', color: colors.text },
  subtitle: { fontSize: 12, color: colors.subtext, marginTop: 1 },
  chevron: {
    position: 'absolute',
    right: 10,
    bottom: 10,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: colors.blue50,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
