import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Modal,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import MapView, { Marker, PROVIDER_DEFAULT } from 'react-native-maps';
import * as Location from 'expo-location';
import { colors, radius, spacing, styles as s, typography } from '../theme';
import { metaApi } from '../api';
import type { LocationHit } from '../types/models';
import { Button } from './ui';

export interface PickedLocation {
  latitude: number;
  longitude: number;
  region: string;
  city: string;
  district: string;
  neighborhood: string;
  street: string;
  landmark: string;
}

/**
 * Full location selector: search by name (Nominatim via API proxy),
 * pick from map (draggable marker), or use device GPS (expo-location).
 * Used by hosts when creating a listing (wizard step 3) and by search.
 */
export function LocationPicker({
  visible,
  onClose,
  onConfirm,
  initial,
}: {
  visible: boolean;
  onClose: () => void;
  onConfirm: (loc: PickedLocation) => void;
  initial?: { latitude: number; longitude: number } | null;
}) {
  const [query, setQuery] = useState('');
  const [hits, setHits] = useState<LocationHit[]>([]);
  const [searching, setSearching] = useState(false);
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(
    initial ? { lat: initial.latitude, lng: initial.longitude } : null
  );
  const [meta, setMeta] = useState<Partial<LocationHit>>({});
  const [gpsLoading, setGpsLoading] = useState(false);
  const mapRef = useRef<MapView>(null);

  useEffect(() => {
    if (!query.trim() || query.trim().length < 3) {
      setHits([]);
      return;
    }
    const handle = setTimeout(async () => {
      setSearching(true);
      try {
        const res = await metaApi.locationSearch(query.trim());
        setHits(res.items || []);
      } catch {
        setHits([]);
      } finally {
        setSearching(false);
      }
    }, 450);
    return () => clearTimeout(handle);
  }, [query]);

  const applyHit = (hit: LocationHit) => {
    setHits([]);
    setQuery(hit.neighborhood || hit.city || hit.label.split(',')[0] || '');
    setCoords({ lat: hit.latitude, lng: hit.longitude });
    setMeta(hit);
    mapRef.current?.animateToRegion(
      { latitude: hit.latitude, longitude: hit.longitude, latitudeDelta: 0.01, longitudeDelta: 0.01 },
      400
    );
  };

  const useGps = async () => {
    setGpsLoading(true);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      setCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude });
      mapRef.current?.animateToRegion(
        { latitude: pos.coords.latitude, longitude: pos.coords.longitude, latitudeDelta: 0.01, longitudeDelta: 0.01 },
        400
      );
      try {
        const rev = await metaApi.locationReverse(pos.coords.latitude, pos.coords.longitude);
        if (rev.item) setMeta(rev.item);
      } catch {
        /* offline — coords still usable */
      }
    } finally {
      setGpsLoading(false);
    }
  };

  const confirm = () => {
    if (!coords) return;
    onConfirm({
      latitude: coords.lat,
      longitude: coords.lng,
      region: meta.region || '',
      city: meta.city || meta.region || '',
      district: meta.district || '',
      neighborhood: meta.neighborhood || '',
      street: meta.street || '',
      landmark: meta.landmark || '',
    });
    onClose();
  };

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: colors.bg }}>
        <View style={pick.header}>
          <Pressable onPress={onClose} hitSlop={8}>
            <Ionicons name="close" size={24} color={colors.text} />
          </Pressable>
          <Text style={[typography.h2, { flex: 1, textAlign: 'center' }]}>Chagua mahali</Text>
          <View style={{ width: 24 }} />
        </View>

        <View style={{ paddingHorizontal: spacing.xl }}>
          <View style={[s.row, pick.searchWrap]}>
            <Ionicons name="search" size={18} color={colors.muted} />
            <TextInput
              value={query}
              onChangeText={setQuery}
              placeholder="Tafuta eneo, mtaa au landmark..."
              placeholderTextColor={colors.muted}
              style={{ flex: 1, marginLeft: 8, fontSize: 15, color: colors.text }}
            />
            {searching ? <ActivityIndicator size="small" color={colors.blue} /> : null}
          </View>
          <View style={[s.row, { gap: spacing.sm, marginTop: spacing.sm }]}>
            <Button title="Tumia GPS yangu" icon="navigate" variant="secondary" small onPress={useGps} loading={gpsLoading} style={{ flex: 1 }} />
          </View>
        </View>

        {hits.length > 0 ? (
          <FlatList
            data={hits}
            keyExtractor={(item, i) => `${i}`}
            style={{ marginHorizontal: spacing.xl, marginTop: spacing.sm, backgroundColor: colors.white, borderRadius: radius.md, maxHeight: 180 }}
            renderItem={({ item }) => (
              <Pressable onPress={() => applyHit(item)} style={pick.hit}>
                <Ionicons name="location-outline" size={16} color={colors.blue} />
                <Text style={{ flex: 1, marginLeft: 8, fontSize: 13, color: colors.text }} numberOfLines={2}>
                  {item.label}
                </Text>
              </Pressable>
            )}
          />
        ) : null}

        <View style={{ flex: 1, margin: spacing.xl, borderRadius: radius.lg, overflow: 'hidden', marginTop: spacing.md }}>
          <MapView
            ref={mapRef}
            style={{ flex: 1 }}
            provider={PROVIDER_DEFAULT}
            initialRegion={{
              latitude: coords?.lat ?? -6.7924,
              longitude: coords?.lng ?? 39.2083,
              latitudeDelta: coords ? 0.01 : 0.35,
              longitudeDelta: coords ? 0.01 : 0.35,
            }}
            onPress={(e) => setCoords({ lat: e.nativeEvent.coordinate.latitude, lng: e.nativeEvent.coordinate.longitude })}
          >
            {coords ? (
              <Marker
                coordinate={{ latitude: coords.lat, longitude: coords.lng }}
                draggable
                onDragEnd={(e) => setCoords({ lat: e.nativeEvent.coordinate.latitude, lng: e.nativeEvent.coordinate.longitude })}
              />
            ) : null}
          </MapView>
          {coords ? (
            <View style={pick.coordChip}>
              <Text style={{ color: colors.white, fontSize: 11 }}>
                {coords.lat.toFixed(5)}, {coords.lng.toFixed(5)}
              </Text>
            </View>
          ) : (
            <View style={pick.hintOverlay}>
              <Text style={{ color: colors.subtext, textAlign: 'center', fontSize: 12 }}>
                Bofya ramani, vuta pin, tafuta au tumia GPS kuweka mahali pa nyumba.
              </Text>
            </View>
          )}
        </View>

        <View style={{ padding: spacing.xl, paddingTop: 0 }}>
          <Button title="Thibitisha mahali" icon="checkmark" onPress={confirm} disabled={!coords} />
        </View>
      </View>
    </Modal>
  );
}

const pick = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.xl,
    paddingTop: 54,
    paddingBottom: spacing.md,
    backgroundColor: colors.white,
  },
  searchWrap: {
    backgroundColor: colors.white,
    borderRadius: radius.pill,
    borderWidth: 1.5,
    borderColor: colors.border,
    paddingHorizontal: 14,
    height: 48,
  },
  hit: { flexDirection: 'row', alignItems: 'center', padding: 12, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  coordChip: { position: 'absolute', bottom: 10, alignSelf: 'center', backgroundColor: 'rgba(10,42,94,0.8)', borderRadius: 999, paddingHorizontal: 12, paddingVertical: 5 },
  hintOverlay: { position: 'absolute', bottom: 10, alignSelf: 'center', backgroundColor: 'rgba(255,255,255,0.92)', borderRadius: radius.md, paddingHorizontal: 12, paddingVertical: 8, maxWidth: 280 },
});
