import React, { useState } from 'react';
import { Dimensions, Pressable, StyleSheet, Text, View } from 'react-native';
import { Image } from 'expo-image';
import { colors } from '../theme';

const { width: SCREEN_W } = Dimensions.get('window');

/** Paged photo gallery with dots + counter, used at the top of PropertyDetails. */
export function ImageGallery({
  uris,
  height = 260,
  onPressImage,
}: {
  uris: string[];
  height?: number;
  onPressImage?: (index: number) => void;
}) {
  const [index, setIndex] = useState(0);
  const list = uris.length ? uris : [null];

  return (
    <View>
      <Pressable onPress={() => onPressImage?.(index)} disabled={!uris.length}>
        <View style={{ width: SCREEN_W, height, backgroundColor: colors.skyLight }}>
          {list.map((uri, i) =>
            uri ? (
              <Image
                key={`${uri}-${i}`}
                source={{ uri }}
                style={[StyleSheet.absoluteFill, { opacity: i === index ? 1 : 0 }]}
                contentFit="cover"
                transition={180}
                recyclingKey={`gal-${i}-${uri}`}
              />
            ) : null
          )}
          {!uris.length ? (
            <View style={[StyleSheet.absoluteFill, { alignItems: 'center', justifyContent: 'center' }]}>
              <Text style={{ color: colors.muted }}>Hakuna picha</Text>
            </View>
          ) : null}
        </View>
      </Pressable>

      {list.length > 1 ? (
        <>
          <View style={gal.dots}>
            {list.map((_, i) => (
              <View key={i} style={[gal.dot, i === index && gal.dotActive]} />
            ))}
          </View>
          <View style={gal.counter}>
            <Text style={{ color: colors.white, fontSize: 11, fontWeight: '700' }}>
              {index + 1}/{list.length}
            </Text>
          </View>
        </>
      ) : null}
    </View>
  );
}

const gal = StyleSheet.create({
  dots: {
    position: 'absolute',
    bottom: 12,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 5,
  },
  dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.55)' },
  dotActive: { backgroundColor: colors.white, width: 16 },
  counter: {
    position: 'absolute',
    top: 12,
    right: 14,
    backgroundColor: 'rgba(10,42,94,0.7)',
    borderRadius: 999,
    paddingHorizontal: 9,
    paddingVertical: 3,
  },
});
