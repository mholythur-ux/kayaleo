import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Avatar, RatingStars } from './ui';
import { colors, spacing, styles as s, typography } from '../theme';
import type { HostInfo } from '../types/models';

/** Host block on PropertyDetails: photo, name, verification, rating. */
export function HostCard({ host, rating, ratingCount }: { host: HostInfo | null; rating: number; ratingCount: number }) {
  if (!host) return null;
  const since = host.created_at ? new Date(host.created_at).getFullYear() : null;
  return (
    <View style={[s.card, hostCard.wrap]}>
      <Avatar uri={host.avatar_url} name={host.full_name} size={54} />
      <View style={{ flex: 1, marginLeft: spacing.md }}>
        <View style={s.row}>
          <Text style={[typography.h2, { fontSize: 15 }]} numberOfLines={1}>
            {host.full_name}
          </Text>
          {host.is_verified ? (
            <View style={[s.row, { marginLeft: 6, backgroundColor: '#DFF5EC', borderRadius: 999, paddingHorizontal: 7, paddingVertical: 2 }]}>
              <Ionicons name="checkmark" size={11} color={colors.success} />
              <Text style={{ color: colors.success, fontSize: 10, fontWeight: '800' }}>Thibitishwa</Text>
            </View>
          ) : null}
        </View>
        <View style={[s.row, { marginTop: 3, gap: 6 }]}>
          <RatingStars rating={rating} />
          <Text style={typography.tiny}>
            {rating > 0 ? `${rating} (${ratingCount})` : 'Mwenye nyumba mpya'}
          </Text>
        </View>
        {since ? <Text style={[typography.tiny, { marginTop: 2 }]}>Mwanachama tangu {since}</Text> : null}
      </View>
    </View>
  );
}

const hostCard = StyleSheet.create({
  wrap: { flexDirection: 'row', alignItems: 'center', padding: spacing.md, marginTop: spacing.md },
});
