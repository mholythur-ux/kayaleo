import React from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  TextInputProps,
  View,
  ViewStyle,
  StyleProp,
  TextStyle,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Image as ExpoImageLib } from 'expo-image';
import { colors, radius, spacing, styles as s, typography } from '../theme';

// ---------- Button ----------
export function Button({
  title,
  onPress,
  variant = 'primary',
  loading,
  disabled,
  icon,
  style,
  small,
}: {
  title: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'white';
  loading?: boolean;
  disabled?: boolean;
  icon?: keyof typeof Ionicons.glyphMap;
  style?: StyleProp<ViewStyle>;
  small?: boolean;
}) {
  const bg =
    variant === 'primary' ? colors.royal
    : variant === 'danger' ? colors.danger
    : variant === 'white' ? colors.white
    : variant === 'secondary' ? colors.blue50
    : 'transparent';
  const fg = variant === 'white' ? colors.royal : variant === 'ghost' ? colors.royal : variant === 'secondary' ? colors.royal : colors.white;
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed }) => [
        {
          backgroundColor: bg,
          opacity: disabled ? 0.5 : pressed ? 0.85 : 1,
          borderRadius: radius.pill,
          height: small ? 38 : 52,
          paddingHorizontal: small ? 14 : 20,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 8,
          borderWidth: variant === 'ghost' ? 1.5 : 0,
          borderColor: colors.skyLight,
        },
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={fg} size="small" />
      ) : (
        <>
          {icon ? <Ionicons name={icon} size={small ? 16 : 19} color={fg} /> : null}
          <Text style={{ color: fg, fontWeight: '700', fontSize: small ? 13 : 15 }}>{title}</Text>
        </>
      )}
    </Pressable>
  );
}

// ---------- Input ----------
export function Input({
  label,
  error,
  style,
  ...rest
}: TextInputProps & { label?: string; error?: string }) {
  return (
    <View style={{ marginBottom: spacing.md }}>
      {label ? <Text style={styles.label}>{label}</Text> : null}
      <TextInput
        placeholderTextColor={colors.muted}
        style={[
          {
            backgroundColor: colors.white,
            borderWidth: 1.5,
            borderColor: error ? colors.danger : colors.border,
            borderRadius: radius.md,
            paddingHorizontal: 14,
            height: 50,
            fontSize: 15,
            color: colors.text,
          },
          style,
        ]}
        {...rest}
      />
      {error ? <Text style={{ color: colors.danger, fontSize: 12, marginTop: 4 }}>{error}</Text> : null}
    </View>
  );
}

// ---------- Chip ----------
export function Chip({
  label,
  active,
  onPress,
  icon,
}: {
  label: string;
  active?: boolean;
  onPress?: () => void;
  icon?: keyof typeof Ionicons.glyphMap;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={[
        {
          flexDirection: 'row',
          alignItems: 'center',
          gap: 6,
          paddingHorizontal: 14,
          height: 36,
          borderRadius: radius.pill,
          borderWidth: 1.5,
          borderColor: active ? colors.blue : colors.border,
          backgroundColor: active ? colors.skyLight : colors.white,
          marginRight: spacing.sm,
          marginBottom: spacing.sm,
        },
      ]}
    >
      {icon ? <Ionicons name={icon} size={14} color={active ? colors.royal : colors.subtext} /> : null}
      <Text style={{ color: active ? colors.royal : colors.subtext, fontWeight: '600', fontSize: 13 }}>{label}</Text>
    </Pressable>
  );
}

// ---------- Badge ----------
export function Badge({ text, tone = 'blue' }: { text: string; tone?: 'blue' | 'dark' | 'warning' | 'success' | 'danger' }) {
  const map = {
    blue: { bg: colors.royal, fg: colors.white },
    dark: { bg: 'rgba(10,42,94,0.85)', fg: colors.white },
    warning: { bg: '#FDF0DC', fg: colors.warning },
    success: { bg: '#DFF5EC', fg: colors.success },
    danger: { bg: '#FDE8E8', fg: colors.danger },
  } as const;
  const c = map[tone];
  return (
    <View style={{ backgroundColor: c.bg, borderRadius: radius.pill, paddingHorizontal: 10, paddingVertical: 4 }}>
      <Text style={{ color: c.fg, fontSize: 11, fontWeight: '700' }}>{text}</Text>
    </View>
  );
}

// ---------- SectionHeader ----------
export function SectionHeader({ title, actionTitle, onAction, icon }: { title: string; actionTitle?: string; onAction?: () => void; icon?: keyof typeof Ionicons.glyphMap }) {
  return (
    <View style={[s.row, { justifyContent: 'space-between', paddingHorizontal: spacing.xl, marginBottom: spacing.md }]}>
      <View style={s.row}>
        {icon ? (
          <View style={{ marginRight: 8 }}>
            <Ionicons name={icon} size={20} color={colors.royal} />
          </View>
        ) : null}
        <Text style={typography.title}>{title}</Text>
      </View>
      {actionTitle && onAction ? (
        <Pressable onPress={onAction} hitSlop={8} style={s.row}>
          <Text style={{ color: colors.royal, fontWeight: '700', fontSize: 13 }}>{actionTitle}</Text>
          <Ionicons name="chevron-forward" size={16} color={colors.royal} />
        </Pressable>
      ) : null}
    </View>
  );
}

// ---------- Skeleton ----------
export function Skeleton({ width, height, style, circle }: { width: number | `${number}%`; height: number; style?: StyleProp<ViewStyle>; circle?: boolean }) {
  return (
    <View
      style={[
        {
          width,
          height,
          borderRadius: circle ? height / 2 : radius.md,
          backgroundColor: '#E4ECF9',
          opacity: 0.7,
        },
        style,
      ]}
    />
  );
}

export function PropertyCardSkeleton() {
  return (
    <View style={[s.card, { width: 260, marginRight: spacing.lg, padding: 0, overflow: 'hidden' }]}>
      <Skeleton width={'100%' as const} height={140} style={{ borderRadius: 0 }} />
      <View style={{ padding: spacing.md, gap: 8 }}>
        <Skeleton width={150} height={14} />
        <Skeleton width={120} height={12} />
        <Skeleton width={170} height={16} />
      </View>
    </View>
  );
}

// ---------- Empty / Error ----------
export function EmptyState({ icon, title, subtitle }: { icon: keyof typeof Ionicons.glyphMap; title: string; subtitle?: string }) {
  return (
    <View style={{ alignItems: 'center', paddingVertical: 48, paddingHorizontal: spacing.xxl }}>
      <View style={{ width: 76, height: 76, borderRadius: 38, backgroundColor: colors.blue50, alignItems: 'center', justifyContent: 'center', marginBottom: spacing.lg }}>
        <Ionicons name={icon} size={34} color={colors.blue} />
      </View>
      <Text style={[typography.h2, { textAlign: 'center' }]}>{title}</Text>
      {subtitle ? <Text style={[typography.small, { textAlign: 'center', marginTop: 6 }]}>{subtitle}</Text> : null}
    </View>
  );
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <View style={{ alignItems: 'center', paddingVertical: 40, paddingHorizontal: spacing.xl }}>
      <Ionicons name="cloud-offline-outline" size={40} color={colors.muted} />
      <Text style={[typography.body, { textAlign: 'center', marginTop: spacing.md }]}>{message}</Text>
      {onRetry ? (
        <View style={{ marginTop: spacing.lg }}>
          <Button title="Jaribu tena" onPress={onRetry} variant="secondary" icon="refresh" small />
        </View>
      ) : null}
    </View>
  );
}

// ---------- Avatar ----------
export function Avatar({ uri, name, size = 44 }: { uri?: string | null; name?: string | null; size?: number }) {
  const initial = (name || 'K').trim().charAt(0).toUpperCase();
  if (uri) {
    return (
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      <ExpoImage uri={uri} size={size} circle />
    );
  }
  return (
    <View
      style={{
        width: size,
        height: size,
        borderRadius: size / 2,
        backgroundColor: colors.skyLight,
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Text style={{ color: colors.royal, fontWeight: '800', fontSize: size * 0.4 }}>{initial}</Text>
    </View>
  );
}

function ExpoImage({ uri, size, circle }: { uri: string; size: number; circle?: boolean }) {
  const { Image } = require('expo-image') as typeof import('expo-image');
  return (
    <Image
      source={{ uri }}
      style={{ width: size, height: size, borderRadius: circle ? size / 2 : radius.md, backgroundColor: colors.skyLight }}
      contentFit="cover"
    />
  );
}

// ---------- RatingStars ----------
export function RatingStars({ rating, size = 14 }: { rating: number; size?: number }) {
  return (
    <View style={s.row}>
      {[1, 2, 3, 4, 5].map((i) => (
        <Ionicons
          key={i}
          name={i <= Math.round(rating) ? 'star' : 'star-outline'}
          size={size}
          color={colors.star}
          style={{ marginRight: 1 }}
        />
      ))}
    </View>
  );
}

// ---------- ProgressBar ----------
export function ProgressBar({ progress }: { progress: number }) {
  return (
    <View style={{ height: 6, backgroundColor: colors.skyLight, borderRadius: 3, overflow: 'hidden' }}>
      <View style={{ height: 6, width: `${Math.min(100, Math.max(4, progress * 100))}%` as `${number}%`, backgroundColor: colors.royal, borderRadius: 3 }} />
    </View>
  );
}

// ---------- StatCard ----------
export function StatCard({ icon, value, label, tone }: { icon: keyof typeof Ionicons.glyphMap; value: number | string; label: string; tone?: string }) {
  return (
    <View style={[s.card, { flex: 1, padding: spacing.md, alignItems: 'center' }]}>
      <Ionicons name={icon} size={20} color={tone || colors.blue} />
      <Text style={{ fontSize: 18, fontWeight: '800', color: colors.text, marginTop: 6 }}>{value}</Text>
      <Text style={typography.tiny}>{label}</Text>
    </View>
  );
}

// ---------- IconButton ----------
export function IconButton({
  name,
  onPress,
  active,
  size = 36,
}: {
  name: 'heart' | 'star';
  onPress: () => void;
  active?: boolean;
  size?: number;
}) {
  const outlined = active ? name : (`${name}-outline` as const);
  return (
    <Pressable
      onPress={onPress}
      hitSlop={8}
      style={{
        width: size,
        height: size,
        borderRadius: size / 2,
        backgroundColor: colors.white,
        alignItems: 'center',
        justifyContent: 'center',
        borderWidth: StyleSheet.hairlineWidth,
        borderColor: colors.border,
      }}
    >
      <Ionicons name={outlined} size={size * 0.5} color={active ? colors.heart : colors.text} />
    </Pressable>
  );
}

export const labelStyle: StyleProp<TextStyle> = {
  fontSize: 13,
  fontWeight: '700',
  color: colors.text,
  marginBottom: 6,
};

const styles = StyleSheet.create({
  label: labelStyle,
});
