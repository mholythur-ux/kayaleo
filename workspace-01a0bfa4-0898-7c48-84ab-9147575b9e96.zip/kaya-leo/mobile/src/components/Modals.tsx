import React, { useState } from 'react';
import { Alert, Modal, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Button, Chip } from './ui';
import { colors, radius, spacing, styles as s, typography } from '../theme';
import { useT } from '../i18n';
import type { ReportReasonOption } from '../types/models';

const REPORT_REASONS: ReportReasonOption[] = [
  { id: 'FAKE_PROPERTY', label: 'Nyumba ya uongo' },
  { id: 'WRONG_INFORMATION', label: 'Taarifa si sahihi' },
  { id: 'SCAM_SUSPICIOUS', label: 'Utapeli / nia ya kushuku' },
  { id: 'INCORRECT_PRICE', label: 'Bei si sahihi' },
  { id: 'ALREADY_UNAVAILABLE', label: 'Imeshapangwa / haipatikani' },
  { id: 'INAPPROPRIATE_CONTENT', label: 'Maudhui yasiyofaa' },
  { id: 'OTHER', label: 'Nyingine' },
];

/** "Ripoti tangazo" bottom sheet — saves a report in the database. */
export function ReportModal({ visible, onClose, onSubmit, loading }: {
  visible: boolean;
  onClose: () => void;
  onSubmit: (reason: string, details: string) => Promise<void>;
  loading: boolean;
}) {
  const [reason, setReason] = useState<string>('FAKE_PROPERTY');
  const [details, setDetails] = useState('');
  const t = useT().t;

  const submit = async () => {
    await onSubmit(reason, details);
    setDetails('');
    setReason('FAKE_PROPERTY');
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={mod.backdrop}>
        <Pressable style={{ flex: 1 }} onPress={onClose} />
        <View style={mod.sheet}>
          <View style={mod.handle} />
          <Text style={[typography.h2, { marginBottom: spacing.md }]}>⚠️ {t('report_listing')}</Text>
          <View style={mod.reasons}>
            {REPORT_REASONS.map((r) => (
              <Chip key={r.id} label={r.label} active={reason === r.id} onPress={() => setReason(r.id)} />
            ))}
          </View>
          <TextInput
            value={details}
            onChangeText={setDetails}
            placeholder="Maelezo zaidi (hiari)..."
            placeholderTextColor={colors.muted}
            style={mod.input}
            multiline
            numberOfLines={3}
          />
          <View style={[s.row, { gap: spacing.sm, marginTop: spacing.md }]}>
            <Button title={t('cancel')} variant="secondary" onPress={onClose} style={{ flex: 1 }} />
            <Button title={t('send')} icon="flag" onPress={submit} loading={loading} style={{ flex: 1 }} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

/** "Omba kukodisha" bottom sheet — creates an inquiry for the host. */
export function InquiryModal({ visible, onClose, onSubmit, loading, propertyName }: {
  visible: boolean;
  onClose: () => void;
  onSubmit: (message: string) => Promise<void>;
  loading: boolean;
  propertyName: string;
}) {
  const [message, setMessage] = useState('');
  const t = useT().t;
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={mod.backdrop}>
        <Pressable style={{ flex: 1 }} onPress={onClose} />
        <View style={mod.sheet}>
          <View style={mod.handle} />
          <Text style={typography.h2}>{t('request_rent')}</Text>
          <Text style={[typography.small, { marginTop: 2, marginBottom: spacing.md }]} numberOfLines={1}>
            {t('message_reference')}: {propertyName}
          </Text>
          <TextInput
            value={message}
            onChangeText={setMessage}
            placeholder={t('inquiry_hint')}
            placeholderTextColor={colors.muted}
            style={[mod.input, { height: 90 }]}
            multiline
          />
          <View style={[s.row, { gap: spacing.sm, marginTop: spacing.md }]}>
            <Button title={t('cancel')} variant="secondary" onPress={onClose} style={{ flex: 1 }} />
            <Button
              title={t('send')}
              icon="paper-plane"
              loading={loading}
              style={{ flex: 1 }}
              onPress={async () => {
                if (message.trim().length < 5) {
                  Alert.alert('Kaya Leo', 'Andika ujumbe mfupi kwa mwenye nyumba.');
                  return;
                }
                await onSubmit(message.trim());
                setMessage('');
              }}
            />
          </View>
        </View>
      </View>
    </Modal>
  );
}

/** Reusable bottom sheet wrapper. */
export function BottomSheet({ visible, onClose, children }: { visible: boolean; onClose: () => void; children: React.ReactNode }) {
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={mod.backdrop}>
        <Pressable style={{ flex: 1 }} onPress={onClose} />
        <View style={mod.sheet}>
          <View style={mod.handle} />
          {children}
        </View>
      </View>
    </Modal>
  );
}

const mod = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: 'rgba(10,42,94,0.45)', justifyContent: 'flex-end' },
  sheet: {
    backgroundColor: colors.white,
    borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl,
    padding: spacing.xl,
    paddingBottom: 34,
  },
  handle: { alignSelf: 'center', width: 44, height: 5, borderRadius: 3, backgroundColor: colors.border, marginBottom: spacing.md },
  reasons: { flexDirection: 'row', flexWrap: 'wrap' },
  input: {
    backgroundColor: colors.blue50,
    borderRadius: radius.md,
    borderWidth: 1.5,
    borderColor: colors.border,
    padding: 12,
    minHeight: 70,
    textAlignVertical: 'top',
    fontSize: 14,
    color: colors.text,
  },
});
