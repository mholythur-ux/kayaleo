import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { colors, radius, spacing, styles as s, typography } from '../theme';
import type { PropertyFull } from '../types/models';
import { formatTZS, locationLine } from '../utils/format';
import { IconButton } from './ui';

type Props = {
  property: PropertyFull;
  onPress: () => void;
  onToggleFavorite: () => void;
  width?: number;
};

const placeholder = require('../../assets/placeholder.jpg');

/** Large horizontal-carousel card used in "Featured Houses". */
export function PropertyCard({ property: p, onPress, onToggleFavorite, width = 268 }: Props) {
  const cover = p.images?.find((i) => i.is_cover) || p.images?.[0];
  return (
    <Pressable
      onPress={onPress}
      style={[s.card, { width, marginRight: spacing.lg, overflow: 'hidden' }]}
      android_ripple={{ color: colors.blue50 }}
    >
      <View>
        <Image
          source={cover ? { uri: cover.image_url } : placeholder}
          style={{ width: '100%', height: 148 }}
          contentFit="cover"
          transition={220}
          recyclingKey={p.id}
        />
        <View style={st.badgeRow}>
          {p.is_featured ? (
            <View style={st.badge}>
              <Text style={st.badgeText}>Popular</Text>
            </View>
          ) : null}
          <IconButton name="heart" onPress={onToggleFavorite} active={p.is_favorite} />
        </View>
      </View>
      <View style={{ padding: spacing.md }}>
        <Text style={[typography.h2, { fontSize: 15 }]} numberOfLines={1}>
          {p.title}
        </Text>
        <View style={[s.row, { marginTop: 4, gap: 4 }]}>
          <Ionicons name="location-sharp" size={13} color={colors.blue} />
          <Text style={typography.small} numberOfLines={1}>
            {locationLine(p)}
          </Text>
        </View>
        <View style={[s.row, { marginTop: 8, gap: 12 }]}>
          <View style={s.row}>
            <Ionicons name="bed-outline" size={14} color={colors.subtext} />
            <Text style={typography.small}> {p.bedrooms}</Text>
          </View>
          <View style={s.row}>
            <Ionicons name="water-outline" size={14} color={colors.subtext} />
            <Text style={typography.small}> {p.bathrooms}</Text>
          </View>
          {p.size_m2 ? (
            <View style={s.row}>
              <Ionicons name="resize-outline" size={13} color={colors.subtext} />
              <Text style={typography.small}> {p.size_m2} m²</Text>
            </View>
          ) : null}
        </View>
        <Text style={{ color: colors.royal, fontWeight: '800', fontSize: 15, marginTop: 8 }}>
          {formatTZS(p.price_monthly)}
          <Text style={{ color: colors.subtext, fontWeight: '600', fontSize: 12 }}> / mwezi</Text>
        </Text>
      </View>
    </Pressable>
  );
}

/** Compact card used in "Mapendekezo kwako" — image on top, details below. */
export function RecommendationCard({ property: p, onPress, onToggleFavorite, width = 210 }: Props) {
  const cover = p.images?.find((i) => i.is_cover) || p.images?.[0];
  return (
    <Pressable
      onPress={onPress}
      style={[s.card, { width, marginRight: spacing.lg, overflow: 'hidden' }]}
      android_ripple={{ color: colors.blue50 }}
    >
      <View>
        <Image
          source={cover ? { uri: cover.image_url } : placeholder}
          style={{ width: '100%', height: 110 }}
          contentFit="cover"
          transition={220}
          recyclingKey={`rec-${p.id}`}
        />
        <View style={st.badgeRow}>
          <View style={st.badge}>
            <Text style={st.badgeText}>
              {p.property_type === 'APARTMENT' ? 'Ghorofa' : p.property_type === 'HOUSE' ? 'Nyumba' : 'Chumba'}
            </Text>
          </View>
          <IconButton name="heart" onPress={onToggleFavorite} active={p.is_favorite} />
        </View>
      </View>
      <View style={{ padding: spacing.md }}>
        <Text style={[typography.h2, { fontSize: 14 }]} numberOfLines={1}>
          {p.title}
        </Text>
        <View style={[s.row, { marginTop: 3, gap: 4 }]}>
          <Ionicons name="location-sharp" size={12} color={colors.blue} />
          <Text style={[typography.small, { fontSize: 12 }]} numberOfLines={1}>
            {locationLine(p)}
          </Text>
        </View>
        <Text style={{ color: colors.royal, fontWeight: '800', fontSize: 14, marginTop: 6 }}>
          {formatTZS(p.price_monthly)}
          <Text style={{ color: colors.subtext, fontWeight: '600', fontSize: 11 }}> / mwezi</Text>
        </Text>
      </View>
    </Pressable>
  );
}

/** Full-width list card used in search results / favorites. */
export function PropertyRowCard({
  property: p,
  onPress,
  onToggleFavorite,
  statusLabel,
}: Props & { statusLabel?: string }) {
  const cover = p.images?.find((i) => i.is_cover) || p.images?.[0];
  return (
    <Pressable onPress={onPress} style={[s.card, { marginBottom: spacing.md, overflow: 'hidden' }]} android_ripple={{ color: colors.blue50 }}>
      <View style={s.row}>
        <Image
          source={cover ? { uri: cover.image_url } : placeholder}
          style={{ width: 108, height: 96 }}
          contentFit="cover"
          transition={200}
          recyclingKey={`row-${p.id}`}
        />
        <View style={{ flex: 1, padding: spacing.md, justifyContent: 'center' }}>
          <View style={[s.row, { justifyContent: 'space-between' }]}>
            <Text style={[typography.h2, { fontSize: 15, flexShrink: 1 }]} numberOfLines={1}>
              {p.title}
            </Text>
            <IconButton name="heart" onPress={onToggleFavorite} active={p.is_favorite} size={30} />
          </View>
          <View style={[s.row, { gap: 4, marginTop: 3 }]}>
            <Ionicons name="location-sharp" size={12} color={colors.blue} />
            <Text style={[typography.small, { fontSize: 12 }]} numberOfLines={1}>
              {locationLine(p)}
            </Text>
          </View>
          {statusLabel ? (
            <Text style={{ color: colors.warning, fontSize: 11, fontWeight: '700', marginTop: 3 }}>{statusLabel}</Text>
          ) : null}
          <Text style={{ color: colors.royal, fontWeight: '800', marginTop: 5 }}>
            {formatTZS(p.price_monthly)}
            <Text style={{ color: colors.subtext, fontWeight: '600', fontSize: 11 }}> / mwezi</Text>
          </Text>
        </View>
      </View>
    </Pressable>
  );
}

const st = StyleSheet.create({
  badgeRow: {
    position: 'absolute',
    top: 10,
    left: 10,
    right: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  badge: {
    backgroundColor: colors.royal,
    borderRadius: radius.pill,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  badgeText: { color: colors.white, fontSize: 11, fontWeight: '700' },
});
