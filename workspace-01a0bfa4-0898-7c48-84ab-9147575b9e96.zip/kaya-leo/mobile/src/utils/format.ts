export function formatTZS(amount: number): string {
  return `TZS ${Math.round(amount).toLocaleString('en-US')}`;
}

export function locationLine(p: {
  neighborhood?: string | null;
  city?: string | null;
  district?: string | null;
  region?: string | null;
}): string {
  return [p.neighborhood, p.city || p.district, p.region].filter(Boolean).join(', ') || 'Tanzania';
}

export function propertyTypeLabel(type: string, lang: 'sw' | 'en'): string {
  const labels: Record<string, { sw: string; en: string }> = {
    APARTMENT: { sw: 'Ghorofa', en: 'Apartment' },
    HOUSE: { sw: 'Nyumba', en: 'House' },
    ROOM: { sw: 'Chumba', en: 'Room' },
  };
  return labels[type]?.[lang] || type;
}

export function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const min = Math.floor(diff / 60000);
  if (min < 1) return 'sasa hivi';
  if (min < 60) return `dakika ${min}`;
  const hrs = Math.floor(min / 60);
  if (hrs < 24) return `saa ${hrs}`;
  const days = Math.floor(hrs / 24);
  if (days < 30) return `siku ${days}`;
  return new Date(iso).toLocaleDateString('sw-TZ');
}

export function messageTime(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleTimeString('sw-TZ', { hour: '2-digit', minute: '2-digit' });
}
