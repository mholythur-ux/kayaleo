import React, { useState } from 'react';
import {
  FlatList,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { Image } from 'expo-image';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { CategoryCard } from '../../components/CategoryCard';
import { PropertyCard, RecommendationCard } from '../../components/PropertyCard';
import { EmptyState, ErrorState, PropertyCardSkeleton, SectionHeader } from '../../components/ui';
import { colors, radius, spacing, styles as s, typography } from '../../theme';
import { useT } from '../../i18n';
import { useAuth } from '../../state/AuthContext';
import { useFeatured, useRecommendations, useToggleFavorite } from '../../hooks/queries';
import type { RootStackParamList } from '../../types/navigation';

const heroImg = require('../../../assets/hero-fallback.jpg');

export default function HomeScreen() {
  const nav = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { t } = useT();
  const { profile } = useAuth();
  const featured = useFeatured();
  const recommended = useRecommendations();
  const toggleFavorite = useToggleFavorite();
  const [query, setQuery] = useState('');

  const openProperty = (id: string) => nav.navigate('PropertyDetails', { propertyId: id });
  const fav = (p: { id: string; is_favorite?: boolean }) =>
    toggleFavorite.mutate({ propertyId: p.id, favorited: Boolean(p.is_favorite) });

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      {/* ---------- Blue gradient header + hero ---------- */}
      <LinearGradient colors={['#0A2A5E', '#153E86', '#1D4ED8']} style={home.header}>
        <SafeAreaView edges={['top']}>
          <View style={{ paddingHorizontal: spacing.xl, paddingTop: 6 }}>
            <View style={[s.row, { gap: 10 }]}>
              <View style={home.logoBadge}>
                <Ionicons name="home" size={20} color={colors.white} />
              </View>
              <View>
                <Text style={home.logo}>
                  Kaya <Text style={{ color: colors.sky }}>Leo</Text>
                </Text>
                <Text style={home.tagline}>{t('app_tagline')}</Text>
              </View>
            </View>
          </View>
        </SafeAreaView>
      </LinearGradient>

      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={featured.isRefetching || recommended.isRefetching}
            onRefresh={() => {
              featured.refetch();
              recommended.refetch();
            }}
            tintColor={colors.white}
          />
        }
      >
        {/* ---------- Hero image with message ---------- */}
        <View>
          <Image source={heroImg} style={home.heroImg} contentFit="cover" transition={300} />
          <LinearGradient
            colors={['rgba(10,42,94,0.86)', 'rgba(10,42,94,0.45)', 'rgba(10,42,94,0.12)']}
            style={StyleSheet.absoluteFill}
          />
          <View style={home.heroContent}>
            <Text style={home.karibu}>{t('home_welcome')}</Text>
            <Text style={typography.hero}>{t('home_hero_title')}</Text>
            <Text style={home.heroSub}>{t('home_hero_sub')}</Text>
          </View>
        </View>

        {/* ---------- Search section (own clearly separated section) ---------- */}
        <View style={[home.searchSection, { marginTop: -34 }]}>
          <Pressable
            style={home.searchBar}
            onPress={() => nav.navigate('Search', { initialQuery: '' })}
            android_ripple={{ color: colors.blue50 }}
          >
            <View style={home.searchIconWrap}>
              <Ionicons name="search" size={19} color={colors.white} />
            </View>
            <Text style={home.searchPlaceholder} numberOfLines={1}>
              {t('search_placeholder')}
            </Text>
            <View style={home.searchGo}>
              <Ionicons name="arrow-forward" size={17} color={colors.white} />
            </View>
          </Pressable>
        </View>

        {/* ---------- Unatafuta nini? ---------- */}
        <SectionHeader title={t('home_what')} icon="grid" />
        <View style={{ flexDirection: 'row', paddingHorizontal: spacing.xl, marginBottom: spacing.xl }}>
          <CategoryCard
            title={t('category_apartment')}
            subtitle={t('category_apartment_sub')}
            icon="business"
            onPress={() =>
              nav.navigate('CategoryListings', { mode: 'type', propertyType: 'APARTMENT', title: t('category_apartment') })
            }
          />
          <CategoryCard
            title={t('category_house')}
            subtitle={t('category_house_sub')}
            icon="home"
            onPress={() =>
              nav.navigate('CategoryListings', { mode: 'type', propertyType: 'HOUSE', title: t('category_house') })
            }
          />
          <CategoryCard
            title={t('category_room')}
            subtitle={t('category_room_sub')}
            icon="bed"
            highlight
            onPress={() =>
              nav.navigate('CategoryListings', { mode: 'type', propertyType: 'ROOM', title: t('category_room') })
            }
          />
        </View>

        {/* ---------- Featured Houses ---------- */}
        <View style={home.sectionHeaderRow}>
          <SectionHeader
            title={t('featured_houses')}
            icon="star"
            actionTitle={t('see_all')}
            onAction={() => nav.navigate('CategoryListings', { mode: 'featured', title: t('featured_houses') })}
          />
        </View>
        {featured.isLoading ? (
          <View style={{ flexDirection: 'row', paddingHorizontal: spacing.xl }}>
            <PropertyCardSkeleton />
            <PropertyCardSkeleton />
          </View>
        ) : featured.isError ? (
          <ErrorState message={t('load_failed')} onRetry={() => featured.refetch()} />
        ) : !featured.data?.items.length ? (
          <EmptyState icon="home-outline" title={t('empty_generic')} />
        ) : (
          <FlatList
            horizontal
            showsHorizontalScrollIndicator={false}
            data={featured.data.items}
            keyExtractor={(item) => item.id}
            contentContainerStyle={{ paddingHorizontal: spacing.xl, paddingBottom: spacing.xl }}
            renderItem={({ item }) => (
              <PropertyCard property={item} onPress={() => openProperty(item.id)} onToggleFavorite={() => fav(item)} />
            )}
          />
        )}

        {/* ---------- Mapendekezo kwako ---------- */}
        <SectionHeader
          title={t('recommendations')}
          icon="sparkles"
          actionTitle={t('see_all')}
          onAction={() => nav.navigate('CategoryListings', { mode: 'recommended', title: t('recommendations') })}
        />
        {recommended.isLoading ? (
          <View style={{ flexDirection: 'row', paddingHorizontal: spacing.xl }}>
            <PropertyCardSkeleton />
            <PropertyCardSkeleton />
          </View>
        ) : recommended.isError ? (
          <ErrorState message={t('load_failed')} onRetry={() => recommended.refetch()} />
        ) : !recommended.data?.items.length ? (
          <EmptyState icon="sparkles-outline" title={t('empty_generic')} />
        ) : (
          <FlatList
            horizontal
            showsHorizontalScrollIndicator={false}
            data={recommended.data.items}
            keyExtractor={(item) => item.id}
            contentContainerStyle={{ paddingHorizontal: spacing.xl, paddingBottom: spacing.xxxl }}
            renderItem={({ item }) => (
              <RecommendationCard property={item} onPress={() => openProperty(item.id)} onToggleFavorite={() => fav(item)} />
            )}
          />
        )}
      </ScrollView>
    </View>
  );
}

const home = StyleSheet.create({
  header: { paddingBottom: 46 },
  logoBadge: {
    width: 38,
    height: 38,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.16)',
    borderWidth: 1.2,
    borderColor: 'rgba(255,255,255,0.35)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  logo: { color: colors.white, fontSize: 21, fontWeight: '900' },
  tagline: { color: colors.sky, fontSize: 11.5, fontWeight: '600', marginTop: 0 },
  heroWrap: { paddingHorizontal: 0, backgroundColor: colors.navy },
  heroImg: { width: '100%', height: 236 },
  heroContent: { position: 'absolute', top: 0, left: 0, right: 0, padding: spacing.xl, paddingTop: spacing.xl },
  karibu: { color: colors.sky, fontSize: 15, fontWeight: '700', marginBottom: 2 },
  heroSub: { color: '#D7E5FB', fontSize: 12.5, lineHeight: 19, marginTop: 8, fontWeight: '500' },
  searchSection: { paddingHorizontal: spacing.xl, marginBottom: spacing.xl },
  searchBar: {
    backgroundColor: colors.white,
    borderRadius: radius.pill,
    height: 60,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    borderWidth: 1,
    borderColor: colors.border,
    shadowColor: colors.navy,
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.12,
    shadowRadius: 18,
    elevation: 6,
  },
  searchIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.royal,
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchPlaceholder: { flex: 1, marginLeft: 12, color: colors.muted, fontSize: 14.5, fontWeight: '500' },
  searchGo: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: colors.blue,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 4,
  },
  sectionHeaderRow: { marginBottom: spacing.sm },
});
