import React from 'react';
import { Alert, FlatList, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { PropertyRowCard } from '../../components/PropertyCard';
import { EmptyState, ErrorState, Skeleton } from '../../components/ui';
import { colors, spacing, styles as s } from '../../theme';
import { useT } from '../../i18n';
import { useFavorites, useToggleFavorite } from '../../hooks/queries';
import { useAuth } from '../../state/AuthContext';
import type { RootStackParamList } from '../../types/navigation';

export default function FavoritesScreen() {
  const nav = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { t } = useT();
  const { session } = useAuth();
  const query = useFavorites(Boolean(session));
  const toggleFavorite = useToggleFavorite();

  if (!session) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }} edges={['top']}>
        <Text style={fav.title}>{t('tab_favorites')}</Text>
        <EmptyState icon="heart-outline" title={t('empty_favorites')} subtitle="Ingia kuhifadhi nyumba unazozipenda." />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }} edges={['top']}>
      <Text style={fav.title}>{t('tab_favorites')}</Text>
      {query.isLoading ? (
        <View style={{ padding: spacing.xl, gap: spacing.md }}>
          {[1, 2, 3].map((i) => (
            <View key={i} style={[s.card, { padding: spacing.md, flexDirection: 'row', gap: spacing.md }]}>
              <Skeleton width={100} height={90} />
              <View style={{ flex: 1, gap: 8, paddingTop: 4 }}>
                <Skeleton width={'70%'} height={14} />
                <Skeleton width={'50%'} height={11} />
              </View>
            </View>
          ))}
        </View>
      ) : query.isError ? (
        <ErrorState message={t('load_failed')} onRetry={() => query.refetch()} />
      ) : !query.data?.items.length ? (
        <EmptyState icon="heart-outline" title={t('empty_favorites')} subtitle={t('empty_favorites_hint')} />
      ) : (
        <FlatList
          data={query.data.items}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ paddingHorizontal: spacing.xl, paddingBottom: spacing.xxl }}
          renderItem={({ item }) => (
            <PropertyRowCard
              property={{ ...item, is_favorite: true }}
              onPress={() => nav.navigate('PropertyDetails', { propertyId: item.id })}
              onToggleFavorite={() =>
                Alert.alert(
                  t('delete'),
                  'Ondoa nyumba hii kwenye uliyopendwa?',
                  [
                    { text: t('cancel'), style: 'cancel' },
                    { text: t('confirm'), style: 'destructive', onPress: () => toggleFavorite.mutate({ propertyId: item.id, favorited: true }) },
                  ]
                )
              }
            />
          )}
        />
      )}
    </SafeAreaView>
  );
}

const fav = StyleSheet.create({
  title: { fontSize: 24, fontWeight: '900', color: colors.text, paddingHorizontal: spacing.xl, paddingTop: spacing.lg, paddingBottom: spacing.lg },
});
