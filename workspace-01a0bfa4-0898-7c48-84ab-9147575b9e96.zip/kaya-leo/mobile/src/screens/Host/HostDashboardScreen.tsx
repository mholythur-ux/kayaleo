import React, { useState } from 'react';
import { Alert, FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useQueryClient } from '@tanstack/react-query';
import { Badge, Button, EmptyState, ErrorState, Skeleton, StatCard } from '../../components/ui';
import { PropertyRowCard } from '../../components/PropertyCard';
import { colors, radius, spacing, styles as s, typography } from '../../theme';
import { useT } from '../../i18n';
import { useAuth } from '../../state/AuthContext';
import { useHostDashboard, useHostProperties, keys as qk } from '../../hooks/queries';
import { hostApi } from '../../api';
import type { PropertyStatus, PropertyFull } from '../../types/models';
import type { RootStackParamList } from '../../types/navigation';

const STATUS_TABS: Array<{ id: PropertyStatus | 'all'; label: string }> = [
  { id: 'all', label: 'Zote' },
  { id: 'approved', label: 'Zinazoendesha' },
  { id: 'pending', label: 'Ukaguzini' },
  { id: 'draft', label: 'Rasimu' },
  { id: 'rejected', label: 'Zilizokataliwa' },
];

const statusLabel = (st: PropertyStatus): { text: string; tone: 'blue' | 'success' | 'warning' | 'danger' } => {
  switch (st) {
    case 'approved':
      return { text: 'Limeidhinishwa', tone: 'success' };
    case 'pending':
      return { text: 'Ukaguzini', tone: 'warning' };
    case 'draft':
      return { text: 'Rasimu', tone: 'blue' };
    case 'rejected':
      return { text: 'Limekataliwa', tone: 'danger' };
    case 'suspended':
      return { text: 'Limesimamishwa', tone: 'danger' };
  }
};

export default function HostDashboardScreen() {
  const nav = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { t } = useT();
  const { profile } = useAuth();
  const qc = useQueryClient();
  const dashboard = useHostDashboard(Boolean(profile?.is_host));
  const [tab, setTab] = useState<PropertyStatus | 'all'>('all');
  const listings = useHostProperties(tab === 'all' ? undefined : tab);

  const act = (p: PropertyFull, action: 'publish' | 'pause' | 'delete') => {
    const run = async () => {
      try {
        if (action === 'publish') await hostApi.publish(p.id);
        if (action === 'pause') await hostApi.pause(p.id);
        if (action === 'delete') await hostApi.remove(p.id);
        qc.invalidateQueries({ queryKey: qk.hostProperties() });
        qc.invalidateQueries({ queryKey: qk.hostDashboard });
      } catch (e) {
        Alert.alert('Kaya Leo', (e as Error).message);
      }
    };
    if (action === 'delete') {
      Alert.alert(t('confirm_delete_title'), `Futa "${p.title}" kabisa? Hii haiwezi kutenduliwa.`, [
        { text: t('cancel'), style: 'cancel' },
        { text: t('delete'), style: 'destructive', onPress: run },
      ]);
    } else {
      run();
    }
  };

  const stats = dashboard.data?.stats;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }} edges={['top']}>
      <View style={dash.header}>
        <Pressable onPress={() => nav.goBack()} hitSlop={8}>
          <Ionicons name="arrow-back" size={23} color={colors.text} />
        </Pressable>
        <Text style={typography.title}>{t('host_dashboard')}</Text>
        <View style={{ width: 23 }} />
      </View>

      <FlatList
        data={listings.data?.items || []}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingBottom: spacing.xxxl }}
        ListHeaderComponent={
          <View>
            {/* stats */}
            {dashboard.isLoading ? (
              <View style={{ flexDirection: 'row', gap: 8, paddingHorizontal: spacing.xl, marginTop: spacing.lg }}>
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} width={'30%'} height={72} />
                ))}
              </View>
            ) : stats ? (
              <View style={{ paddingHorizontal: spacing.xl, marginTop: spacing.lg }}>
                <View style={{ flexDirection: 'row', gap: 8, marginBottom: 8 }}>
                  <StatCard icon="checkmark-circle" value={stats.active_listings} label="Zinazoendesha" />
                  <StatCard icon="time" value={stats.pending_listings} label="Ukaguzini" tone={colors.warning} />
                  <StatCard icon="eye" value={stats.views} label={t('host_stats_views')} />
                </View>
                <View style={{ flexDirection: 'row', gap: 8 }}>
                  <StatCard icon="heart" value={stats.favorites} label={t('host_stats_favorites')} tone={colors.heart} />
                  <StatCard icon="chatbubble" value={stats.messages} label={t('host_stats_messages')} />
                  <StatCard icon="document-text" value={stats.inquiries} label={t('host_stats_inquiries')} />
                </View>
              </View>
            ) : null}

            {/* add property */}
            <View style={{ paddingHorizontal: spacing.xl, marginTop: spacing.lg }}>
              <Button
                title={t('add_new_property')}
                icon="add"
                onPress={() => nav.navigate('HostOnboarding', { property: undefined })}
              />
            </View>

            {/* status tabs */}
            <FlatList
              horizontal
              showsHorizontalScrollIndicator={false}
              data={STATUS_TABS}
              keyExtractor={(item) => item.id}
              style={{ marginTop: spacing.lg }}
              contentContainerStyle={{ paddingHorizontal: spacing.xl }}
              renderItem={({ item }) => (
                <Pressable style={[dash.tab, tab === item.id && dash.tabActive]} onPress={() => setTab(item.id)}>
                  <Text style={[dash.tabText, tab === item.id && dash.tabTextActive]}>{item.label}</Text>
                </Pressable>
              )}
            />

            {/* inquiries preview */}
            {dashboard.data?.inquiries.length ? (
              <View style={{ paddingHorizontal: spacing.xl, marginTop: spacing.lg }}>
                <Text style={[typography.h2, { marginBottom: spacing.sm }]}>Maombi mapya</Text>
                {dashboard.data.inquiries.slice(0, 3).map((inq) => (
                  <View key={inq.id} style={[s.card, { padding: spacing.md, marginBottom: 8 }]}>
                    <View style={[s.row, { justifyContent: 'space-between' }]}>
                      <Text style={{ fontWeight: '800', fontSize: 13, flexShrink: 1 }} numberOfLines={1}>
                        {inq.user?.full_name || 'Mtarajiwa'} · {inq.property?.title}
                      </Text>
                      {inq.status === 'new' ? <Badge text="Mpya" tone="blue" /> : <Badge text={inq.status} />}
                    </View>
                    <Text style={[typography.small, { marginTop: 4 }]} numberOfLines={2}>
                      {inq.message}
                    </Text>
                    <View style={[s.row, { gap: 8, marginTop: 8 }]}>
                      <Button
                        title="Imejibiwa"
                        small
                        variant="secondary"
                        onPress={async () => {
                          try {
                            const { inquiriesApi } = await import('../../api');
                            await inquiriesApi.setStatus(inq.id, 'contacted');
                            qc.invalidateQueries({ queryKey: qk.hostDashboard });
                          } catch (e) {
                            Alert.alert('Kaya Leo', (e as Error).message);
                          }
                        }}
                      />
                      {inq.user?.phone ? (
                        <Button
                          title={t('call_host')}
                          small
                          icon="call"
                          onPress={() => import('react-native').then(({ Linking }) => Linking.openURL(`tel:${inq.user!.phone!.replace(/\s/g, '')}`))}
                        />
                      ) : null}
                    </View>
                  </View>
                ))}
              </View>
            ) : null}

            <Text style={[typography.h2, { paddingHorizontal: spacing.xl, marginTop: spacing.lg, marginBottom: spacing.md }]}>
              Tangazo zako ({listings.data?.total ?? 0})
            </Text>
          </View>
        }
        renderItem={({ item }) => {
          const sl = statusLabel(item.status);
          return (
            <View style={{ paddingHorizontal: spacing.xl }}>
              <PropertyRowCard
                property={item}
                statusLabel={`${sl.text}${item.status === 'rejected' && item.rejection_reason ? `: ${item.rejection_reason}` : ''}`}
                onPress={() => nav.navigate('PropertyDetails', { propertyId: item.id })}
                onToggleFavorite={() => {}}
              />
              <View style={[s.row, { gap: 8, marginTop: -8, marginBottom: spacing.lg, flexWrap: 'wrap' }]}>
                <Button title={t('edit')} small variant="secondary" icon="create" onPress={() => nav.navigate('HostOnboarding', { property: item })} />
                {item.status === 'approved' ? (
                  <Button title={t('pause')} small variant="secondary" icon="pause" onPress={() => act(item, 'pause')} />
                ) : item.status === 'draft' || item.status === 'rejected' ? (
                  <Button title={t('republish')} small icon="send" onPress={() => act(item, 'publish')} />
                ) : null}
                <Button title={t('delete')} small variant="danger" icon="trash" onPress={() => act(item, 'delete')} />
              </View>
            </View>
          );
        }}
        ListEmptyComponent={
          listings.isError ? (
            <ErrorState message={t('load_failed')} onRetry={() => listings.refetch()} />
          ) : listings.isLoading ? (
            <View style={{ padding: spacing.xl, gap: spacing.md }}>
              {[1, 2].map((i) => (
                <Skeleton key={i} width={'100%'} height={90} />
              ))}
            </View>
          ) : (
            <EmptyState icon="business-outline" title="Hakuna tangazo hapa" subtitle={t('add_new_property')} />
          )
        }
      />
    </SafeAreaView>
  );
}

const dash = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    backgroundColor: colors.white,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  tab: {
    paddingHorizontal: 14,
    height: 34,
    borderRadius: radius.pill,
    borderWidth: 1.4,
    borderColor: colors.border,
    backgroundColor: colors.white,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
  },
  tabActive: { backgroundColor: colors.royal, borderColor: colors.royal },
  tabText: { fontSize: 12.5, fontWeight: '700', color: colors.subtext },
  tabTextActive: { color: colors.white },
});
