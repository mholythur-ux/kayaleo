import React, { useMemo, useState } from 'react';
import {
  ActionSheetIOS,
  Alert,
  Image,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useRoute } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RouteProp } from '@react-navigation/native';
import * as ImagePicker from 'expo-image-picker';
import { Image as ExpoImage } from 'expo-image';
import { Button, Chip, Input, ProgressBar } from '../../components/ui';
import { LocationPicker, type PickedLocation } from '../../components/LocationPicker';
import { colors, radius, spacing, styles as s, typography } from '../../theme';
import { useT } from '../../i18n';
import { useAuth } from '../../state/AuthContext';
import { hostApi, metaApi } from '../../api';
import { uploadToBucket } from '../../services/supabase';
import { useAmenities } from '../../hooks/queries';
import { emptyDraft, IMAGE_CATEGORIES, type ImageCategory, type ListingDraft, type PropertyFull } from '../../types/models';
import type { RootStackParamList } from '../../types/navigation';
import { formatTZS } from '../../utils/format';

const TOTAL_STEPS = 9;

type Photo = { uri: string; category: ImageCategory; isCover: boolean; remoteId?: string };

export default function HostOnboardingScreen() {
  return <HostWizard />;
}

/** Wizard shared by "Become a Host" (create) and HostDashboard (edit). */
export function HostWizard() {
  const nav = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const route = useRoute<RouteProp<RootStackParamList, 'HostOnboarding'>>();
  const { t } = useT();
  const { profile, refreshProfile } = useAuth();
  const amenitiesQuery = useAmenities();
  const editing = route.params?.property as PropertyFull | undefined;

  const [step, setStep] = useState(1);
  const [draft, setDraft] = useState<ListingDraft>(() => (editing ? draftFromProperty(editing) : emptyDraft()));
  const [photos, setPhotos] = useState<Photo[]>(() =>
    editing ? editing.images.map((i) => ({ uri: i.image_url, category: i.category, isCover: i.is_cover, remoteId: i.id })) : []
  );
  const [hostInfo, setHostInfo] = useState({
    full_name: profile?.full_name || '',
    phone: profile?.phone || '',
    email: profile?.email || '',
  });
  const [customAmenity, setCustomAmenity] = useState('');
  const [locationModal, setLocationModal] = useState(false);
  const [busy, setBusy] = useState<'' | 'draft' | 'publish'>('');

  const set = (patch: Partial<ListingDraft>) => setDraft((d) => ({ ...d, ...patch }));

  const canNext = useMemo(() => {
    switch (step) {
      case 1:
        return hostInfo.full_name.trim().length >= 2 && hostInfo.phone.trim().length >= 7;
      case 2:
        return Boolean(draft.property_type);
      case 3:
        return Boolean(draft.location.latitude && draft.location.city);
      case 4:
        return draft.title.trim().length >= 4 && Number(draft.bedrooms) >= 0;
      case 7:
        return Number(draft.price_monthly) > 0;
      case 8:
        return draft.availability === 'now' || /^\d{4}-\d{2}-\d{2}$/.test(draft.availability_date);
      default:
        return true;
    }
  }, [step, draft, hostInfo]);

  // ---------- actions ----------
  const applyHost = async () => {
    if (profile?.is_host) return;
    const res = await hostApi.apply({
      full_name: hostInfo.full_name.trim(),
      phone: hostInfo.phone.trim(),
      email: hostInfo.email.trim(),
    });
    await refreshProfile();
    void res;
  };

  const uploadPhotos = async (): Promise<Array<{ image_url: string; storage_path?: string; category: string; is_cover: boolean; sort_order: number }>> => {
    const out: Array<{ image_url: string; storage_path?: string; category: string; is_cover: boolean; sort_order: number }> = [];
    const ordered = [...photos].sort((a, b) => Number(b.isCover) - Number(a.isCover));
    for (let i = 0; i < ordered.length; i++) {
      const ph = ordered[i];
      let url = ph.uri;
      if (ph.uri.startsWith('file:') || ph.uri.startsWith('content:')) {
        const up = await uploadToBucket('property-images', ph.uri, `photo-${Date.now()}.jpg`);
        url = up.url;
      }
      out.push({
        image_url: url,
        category: ph.category,
        is_cover: i === 0,
        sort_order: i,
      });
    }
    return out;
  };

  const buildBody = () => ({
    title: draft.title.trim(),
    description: draft.description.trim(),
    property_type: draft.property_type,
    price_monthly: Number(draft.price_monthly),
    price_weekly: draft.price_weekly ? Number(draft.price_weekly) : null,
    price_daily: draft.price_daily ? Number(draft.price_daily) : null,
    bedrooms: Number(draft.bedrooms) || 0,
    bathrooms: Number(draft.bathrooms) || 0,
    size_m2: draft.size_m2 ? Number(draft.size_m2) : null,
    floor_number: draft.floor_number ? Number(draft.floor_number) : null,
    furnished: draft.furnished,
    max_occupants: draft.max_occupants ? Number(draft.max_occupants) : null,
    house_rules: draft.house_rules.trim() || null,
    latitude: draft.location.latitude,
    longitude: draft.location.longitude,
    region: draft.location.region || null,
    city: draft.location.city || null,
    district: draft.location.district || null,
    neighborhood: draft.location.neighborhood || null,
    street: draft.location.street || null,
    landmark: draft.location.landmark || null,
    availability_date: draft.availability === 'date' ? draft.availability_date : null,
    amenities: draft.amenities,
  });

  const saveDraft = async () => {
    setBusy('draft');
    try {
      const body = buildBody();
      if (editing) {
        await hostApi.update(editing.id, body);
      } else {
        await applyHost();
        await hostApi.create({ ...body, status: 'draft', images: [] });
      }
      Alert.alert('Kaya Leo', t('draft_saved'), [{ text: 'Sawa', onPress: () => nav.navigate('HostDashboard') }]);
    } catch (e) {
      Alert.alert('Kaya Leo', (e as Error).message);
    } finally {
      setBusy('');
    }
  };

  const publish = async () => {
    if (photos.length < 2) {
      Alert.alert('Kaya Leo', t('photos_required'));
      setStep(6);
      return;
    }
    setBusy('publish');
    try {
      const images = await uploadPhotos();
      const body = buildBody();
      if (editing) {
        await hostApi.update(editing.id, body);
        await hostApi.replaceImages(editing.id, images);
        await hostApi.publish(editing.id);
      } else {
        await applyHost();
        await hostApi.create({ ...body, status: 'pending', images });
      }
      Alert.alert('Kaya Leo', t('listing_published'), [
        { text: 'Sawa', onPress: () => nav.navigate('HostDashboard') },
      ]);
    } catch (e) {
      Alert.alert('Kaya Leo', (e as Error).message);
    } finally {
      setBusy('');
    }
  };

  const next = async () => {
    if (step === 1) {
      try {
        await applyHost();
      } catch (e) {
        Alert.alert('Kaya Leo', (e as Error).message);
        return;
      }
    }
    setStep((st) => Math.min(TOTAL_STEPS, st + 1));
  };

  // ---------- photos ----------
  const addPhotos = async (fromCamera: boolean) => {
    if (fromCamera) {
      const perm = await ImagePicker.requestCameraPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Kaya Leo', 'Ruhusa ya kamera inahitajika.');
        return;
      }
      const res = await ImagePicker.launchCameraAsync({ quality: 0.7 });
      if (!res.canceled && res.assets[0]) pushPhoto(res.assets[0].uri);
    } else {
      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Kaya Leo', 'Ruhusa ya gallery inahitajika.');
        return;
      }
      const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.7, selectionLimit: 8 });
      if (!res.canceled) res.assets.forEach((a) => pushPhoto(a.uri));
    }
  };

  const pushPhoto = (uri: string) =>
    setPhotos((prev) => [...prev, { uri, category: 'OTHER', isCover: prev.length === 0 }]);

  const movePhoto = (index: number, dir: -1 | 1) =>
    setPhotos((prev) => {
      const next = [...prev];
      const target = index + dir;
      if (target < 0 || target >= next.length) return prev;
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });

  const removePhoto = (index: number) =>
    setPhotos((prev) => prev.filter((_, i) => i !== index).map((p, i) => ({ ...p, isCover: i === 0 ? true : p.isCover })));

  const makeCover = (index: number) =>
    setPhotos((prev) => prev.map((p, i) => ({ ...p, isCover: i === index })));

  // ---------- amenity helpers ----------
  const toggleAmenity = (name: string) =>
    set({ amenities: draft.amenities.includes(name) ? draft.amenities.filter((a) => a !== name) : [...draft.amenities, name] });

  const addCustomAmenity = () => {
    const name = customAmenity.trim();
    if (name.length < 2) return;
    if (!draft.amenities.includes(name)) set({ amenities: [...draft.amenities, name] });
    setCustomAmenity('');
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }} edges={['top']}>
      {/* header */}
      <View style={wiz.header}>
        <Pressable onPress={() => (step > 1 ? setStep(step - 1) : nav.goBack())} hitSlop={8}>
          <Ionicons name={step > 1 ? 'arrow-back' : 'close'} size={23} color={colors.text} />
        </Pressable>
        <View style={{ flex: 1, alignItems: 'center' }}>
          <Text style={{ fontWeight: '800', color: colors.navy }}>{t('host_wizard_title')}</Text>
          <Text style={typography.tiny}>
            {t('step')} {step} {t('of')} {TOTAL_STEPS}
          </Text>
        </View>
        <View style={{ width: 23 }} />
      </View>
      <View style={{ paddingHorizontal: spacing.xl, paddingTop: 4, backgroundColor: colors.white }}>
        <ProgressBar progress={step / TOTAL_STEPS} />
      </View>

      <ScrollView contentContainerStyle={{ padding: spacing.xl, paddingBottom: 40 }} keyboardShouldPersistTaps="handled">
        {step === 1 ? (
          <StepCard title={t('step1_title')}>
            <Input label={t('full_name')} value={hostInfo.full_name} onChangeText={(v) => setHostInfo((h) => ({ ...h, full_name: v }))} />
            <Input label={t('phone')} value={hostInfo.phone} onChangeText={(v) => setHostInfo((h) => ({ ...h, phone: v }))} keyboardType="phone-pad" />
            <Input label={t('email')} value={hostInfo.email} onChangeText={(v) => setHostInfo((h) => ({ ...h, email: v }))} keyboardType="email-address" autoCapitalize="none" />
            <Text style={typography.tiny}>Picha ya wasifu inaweza kubadilishwa kwenye Wasifu.</Text>
          </StepCard>
        ) : null}

        {step === 2 ? (
          <StepCard title={t('step2_title')}>
            <View style={{ gap: spacing.md }}>
              {(['APARTMENT', 'HOUSE', 'ROOM'] as const).map((tp, i) => (
                <Pressable
                  key={tp}
                  onPress={() => set({ property_type: tp })}
                  style={[wiz.typeCard, draft.property_type === tp && wiz.typeCardActive, i === 2 && { backgroundColor: '#F8F5FF', borderColor: '#D8C4FF' }]}
                >
                  <Ionicons name={tp === 'APARTMENT' ? 'business' : tp === 'HOUSE' ? 'home' : 'bed'} size={26} color={draft.property_type === tp ? colors.royal : i === 2 ? '#7C3AED' : colors.subtext} />
                  <View style={{ marginLeft: 12, flex: 1 }}>
                    <Text style={{ fontWeight: '800', fontSize: 15 }}>{tp === 'APARTMENT' ? 'Ghorofa' : tp === 'HOUSE' ? 'Nyumba' : 'Chumba'}</Text>
                    <Text style={typography.tiny}>{tp === 'APARTMENT' ? 'Apartment' : tp === 'HOUSE' ? 'House' : 'Room'}</Text>
                  </View>
                  {draft.property_type === tp ? <Ionicons name="checkmark-circle" size={22} color={colors.royal} /> : null}
                </Pressable>
              ))}
            </View>
          </StepCard>
        ) : null}

        {step === 3 ? (
          <StepCard title={t('step3_title')}>
            <Button title="Chagua kwenye ramani / GPS" icon="map" onPress={() => setLocationModal(true)} />
            {draft.location.latitude ? (
              <View style={[s.card, { padding: spacing.md, marginTop: spacing.md }]}>
                <View style={[s.row, { gap: 6 }]}>
                  <Ionicons name="checkmark-circle" size={16} color={colors.success} />
                  <Text style={{ fontWeight: '700', fontSize: 13 }}>
                    {draft.location.city || ''} {draft.location.neighborhood ? `· ${draft.location.neighborhood}` : ''}
                  </Text>
                </View>
                <Text style={typography.tiny} numberOfLines={2}>
                  {draft.location.latitude.toFixed(5)}, {draft.location.longitude?.toFixed(5)}
                </Text>
              </View>
            ) : null}
            <View style={{ marginTop: spacing.md }}>
              <Input label="Mtaa / Street" value={draft.location.street} onChangeText={(v) => set({ location: { ...draft.location, street: v } })} placeholder="Mfano: Haile Selassie Rd" />
              <Input label="Landmark" value={draft.location.landmark} onChangeText={(v) => set({ location: { ...draft.location, landmark: v } })} placeholder="Mfano: Karibu na Slipway" />
            </View>
            <LocationPicker
              visible={locationModal}
              onClose={() => setLocationModal(false)}
              initial={draft.location.latitude ? { latitude: draft.location.latitude, longitude: draft.location.longitude! } : null}
              onConfirm={(loc: PickedLocation) => set({ location: { ...draft.location, ...loc } })}
            />
          </StepCard>
        ) : null}

        {step === 4 ? (
          <StepCard title={t('step4_title')}>
            <Input label={t('property_title_label')} value={draft.title} onChangeText={(v) => set({ title: v })} placeholder={t('property_title_hint')} />
            <Input label={t('description_label')} value={draft.description} onChangeText={(v) => set({ description: v })} multiline style={{ height: 96, textAlignVertical: 'top', paddingTop: 12 }} />
            <View style={[wiz.twoCol]}>
              <Input label={t('bedrooms')} value={String(draft.bedrooms)} onChangeText={(v) => set({ bedrooms: Number(v.replace(/[^0-9]/g, '')) || 0 })} keyboardType="number-pad" />
              <Input label={t('bathrooms')} value={String(draft.bathrooms)} onChangeText={(v) => set({ bathrooms: Number(v.replace(/[^0-9]/g, '')) || 0 })} keyboardType="number-pad" />
            </View>
            <View style={wiz.twoCol}>
              <Input label={`${t('size')} (m²)`} value={draft.size_m2} onChangeText={(v) => set({ size_m2: v.replace(/[^0-9.]/g, '') })} keyboardType="number-pad" />
              <Input label={`${t('floor')} (hiari)`} value={draft.floor_number} onChangeText={(v) => set({ floor_number: v.replace(/[^0-9-]/g, '') })} keyboardType="number-pad" />
            </View>
            <Input label={`${t('occupants')} (hiari)`} value={draft.max_occupants} onChangeText={(v) => set({ max_occupants: v.replace(/[^0-9]/g, '') })} keyboardType="number-pad" />
            <View style={[s.row, { justifyContent: 'space-between', marginTop: 4 }]}>
              <Text style={{ fontWeight: '700', fontSize: 14 }}>{t('furnished')}?</Text>
              <Pressable
                onPress={() => set({ furnished: !draft.furnished })}
                style={[wiz.switchTrack, draft.furnished && { backgroundColor: colors.royal }]}
              >
                <View style={[wiz.switchKnob, draft.furnished && { alignSelf: 'flex-end' }]} />
              </Pressable>
            </View>
          </StepCard>
        ) : null}

        {step === 5 ? (
          <StepCard title={t('step5_title')}>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
              {(amenitiesQuery.data?.items || []).map((a) => (
                <Chip key={a.id} label={a.name} active={draft.amenities.includes(a.name)} onPress={() => toggleAmenity(a.name)} />
              ))}
              {draft.amenities
                .filter((n) => !(amenitiesQuery.data?.items || []).some((a) => a.name === n))
                .map((n) => (
                  <Chip key={n} label={n} active onPress={() => toggleAmenity(n)} />
                ))}
            </View>
            <View style={[s.row, { gap: spacing.sm, marginTop: spacing.sm }]}>
              <TextInput
                value={customAmenity}
                onChangeText={setCustomAmenity}
                placeholder={t('add_amenity_custom')}
                placeholderTextColor={colors.muted}
                style={wiz.customInput}
              />
              <Button title={t('save')} small variant="secondary" onPress={addCustomAmenity} />
            </View>
          </StepCard>
        ) : null}

        {step === 6 ? (
          <StepCard title={t('step6_title')}>
            <View style={[s.row, { gap: spacing.sm }]}>
              <Button title={t('take_photo')} icon="camera" small onPress={() => addPhotos(true)} style={{ flex: 1 }} />
              <Button title={t('choose_gallery')} icon="images" small variant="secondary" onPress={() => addPhotos(false)} style={{ flex: 1 }} />
            </View>
            <Text style={[typography.tiny, { marginTop: 6 }]}>
              {photos.length}/30 · Chagua kategoria ya kila picha. Picha ya kwanza ndiyo jalada (cover).
            </Text>
            {photos.map((ph, i) => (
              <View key={`${ph.uri}-${i}`} style={[s.card, { padding: spacing.md, marginTop: spacing.md }]}>
                <View style={[s.row, { gap: 10 }]}>
                  <ExpoImage source={{ uri: ph.uri }} style={{ width: 64, height: 64, borderRadius: radius.md }} contentFit="cover" />
                  <View style={{ flex: 1 }}>
                    <View style={[s.row, { justifyContent: 'space-between' }]}>
                      <Text style={{ fontWeight: '800', fontSize: 12.5 }}>
                        {ph.isCover ? `⭐ ${t('cover')}` : `Picha ${i + 1}`}
                      </Text>
                      <View style={{ flexDirection: 'row', gap: 6 }}>
                        <Pressable onPress={() => movePhoto(i, -1)} hitSlop={6}>
                          <Ionicons name="arrow-up-circle" size={20} color={colors.blue} />
                        </Pressable>
                        <Pressable onPress={() => movePhoto(i, 1)} hitSlop={6}>
                          <Ionicons name="arrow-down-circle" size={20} color={colors.blue} />
                        </Pressable>
                        <Pressable onPress={() => makeCover(i)} hitSlop={6}>
                          <Ionicons name="star-outline" size={19} color={colors.star} />
                        </Pressable>
                        <Pressable onPress={() => removePhoto(i)} hitSlop={6}>
                          <Ionicons name="trash" size={19} color={colors.danger} />
                        </Pressable>
                      </View>
                    </View>
                    <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 8 }}>
                      {IMAGE_CATEGORIES.map((cat) => (
                        <Chip
                          key={cat}
                          label={categoryLabel(cat)}
                          active={ph.category === cat}
                          onPress={() => setPhotos((prev) => prev.map((p, pi) => (pi === i ? { ...p, category: cat } : p)))}
                        />
                      ))}
                    </View>
                  </View>
                </View>
              </View>
            ))}
          </StepCard>
        ) : null}

        {step === 7 ? (
          <StepCard title={t('step7_title')}>
            <Input label={`${t('monthly_price')} *`} value={draft.price_monthly} onChangeText={(v) => set({ price_monthly: v.replace(/[^0-9]/g, '') })} keyboardType="number-pad" placeholder="Mfano: 850000" />
            {draft.price_monthly ? (
              <Text style={[typography.small, { marginBottom: spacing.md }]}>= {formatTZS(Number(draft.price_monthly || 0))} / mwezi</Text>
            ) : null}
            <Input label={t('weekly_price')} value={draft.price_weekly} onChangeText={(v) => set({ price_weekly: v.replace(/[^0-9]/g, '') })} keyboardType="number-pad" />
            <Input label={t('daily_price')} value={draft.price_daily} onChangeText={(v) => set({ price_daily: v.replace(/[^0-9]/g, '') })} keyboardType="number-pad" />
            <Text style={typography.tiny}>Sarafu: TZS (Shilingi ya Tanzania)</Text>
          </StepCard>
        ) : null}

        {step === 8 ? (
          <StepCard title={t('step8_title')}>
            <View style={{ gap: spacing.md }}>
              <Pressable style={[wiz.typeCard, draft.availability === 'now' && wiz.typeCardActive]} onPress={() => set({ availability: 'now' })}>
                <Ionicons name="checkmark-done" size={24} color={draft.availability === 'now' ? colors.royal : colors.subtext} />
                <Text style={[{ marginLeft: 12, fontWeight: '800' }, draft.availability !== 'now' && { color: colors.subtext }]}>
                  {t('available_now')}
                </Text>
              </Pressable>
              <Pressable style={[wiz.typeCard, draft.availability === 'date' && wiz.typeCardActive]} onPress={() => set({ availability: 'date' })}>
                <Ionicons name="calendar" size={24} color={draft.availability === 'date' ? colors.royal : colors.subtext} />
                <Text style={[{ marginLeft: 12, fontWeight: '800' }, draft.availability !== 'date' && { color: colors.subtext }]}>
                  {t('available_from_date')}
                </Text>
              </Pressable>
              {draft.availability === 'date' ? (
                <Input
                  label={t('availability') + ' (' + t('date_hint') + ')'}
                  value={draft.availability_date}
                  onChangeText={(v) => set({ availability_date: v })}
                  placeholder="2026-12-01"
                  autoCapitalize="none"
                />
              ) : null}
            </View>
          </StepCard>
        ) : null}

        {step === 9 ? (
          <StepCard title={t('step9_title')}>
            <View style={[s.card, { overflow: 'hidden', marginBottom: spacing.md }]}>
              {photos[0] ? <ExpoImage source={{ uri: photos[0].uri }} style={{ width: '100%', height: 150 }} contentFit="cover" /> : null}
              <View style={{ padding: spacing.md }}>
                <Text style={{ fontWeight: '900', fontSize: 16 }}>
                  {draft.title || 'Nyumba bila jina'}
                </Text>
                <Text style={typography.small}>
                  {[draft.location.neighborhood, draft.location.city].filter(Boolean).join(', ')}
                </Text>
                <Text style={{ color: colors.royal, fontWeight: '900', marginTop: 6 }}>
                  {formatTZS(Number(draft.price_monthly || 0))} / mwezi
                </Text>
              </View>
            </View>
            <SummaryRow label="Aina" value={draft.property_type === 'APARTMENT' ? 'Ghorofa' : draft.property_type === 'HOUSE' ? 'Nyumba' : 'Chumba'} />
            <SummaryRow label={t('bedrooms')} value={String(draft.bedrooms)} />
            <SummaryRow label={t('bathrooms')} value={String(draft.bathrooms)} />
            <SummaryRow label={t('size')} value={draft.size_m2 ? `${draft.size_m2} m²` : '—'} />
            <SummaryRow label={t('filter_furnished')} value={draft.furnished ? 'Ndiyo' : 'Hapana'} />
            <SummaryRow label={t('amenities')} value={draft.amenities.join(', ') || '—'} />
            <SummaryRow label="Picha" value={String(photos.length)} />
            <SummaryRow label={t('availability')} value={draft.availability === 'now' ? t('available_now') : draft.availability_date} />
            <Text style={[typography.tiny, { marginTop: spacing.md }]}>
              Tangazo litakaguliwa na msimamizi kabla ya kuchapishwa. Ukihifadhi rasimu, utaipa kwa ukaguzi baadaye
              kutoka Dashibodi.
            </Text>
          </StepCard>
        ) : null}
      </ScrollView>

      {/* footer nav */}
      <View style={wiz.footer}>
        {step > 1 ? (
          <Button title={t('back')} variant="secondary" style={{ flex: 1 }} onPress={() => setStep(step - 1)} />
        ) : null}
        {step < TOTAL_STEPS ? (
          <Button title={t('next')} icon="arrow-forward" style={{ flex: 2 }} onPress={next} disabled={!canNext} />
        ) : (
          <>
            <Button title={t('save_draft')} variant="secondary" style={{ flex: 1 }} onPress={saveDraft} loading={busy === 'draft'} />
            <Button title={t('publish')} icon="rocket" style={{ flex: 1.6 }} onPress={publish} loading={busy === 'publish'} />
          </>
        )}
      </View>
    </SafeAreaView>
  );
}

function categoryLabel(cat: ImageCategory): string {
  const map: Record<ImageCategory, string> = {
    EXTERIOR: 'Nje',
    LIVING_ROOM: 'Sebule',
    BEDROOM: 'Chumba',
    BATHROOM: 'Bafu',
    KITCHEN: 'Jiko',
    OTHER: 'Nyingine',
  };
  return map[cat];
}

function SummaryRow({ label, value }: { label: string; value: string }) {
  return (
    <View style={[s.row, { justifyContent: 'space-between', paddingVertical: 7, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border }]}>
      <Text style={{ color: colors.subtext, fontSize: 13 }}>{label}</Text>
      <Text style={{ fontWeight: '700', fontSize: 13, color: colors.text, flexShrink: 1, textAlign: 'right' }}>{value}</Text>
    </View>
  );
}

function StepCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View>
      <Text style={[typography.title, { marginBottom: spacing.lg }]}>{title}</Text>
      {children}
    </View>
  );
}

function draftFromProperty(p: PropertyFull): ListingDraft {
  const base = emptyDraft();
  return {
    ...base,
    property_type: p.property_type,
    title: p.title,
    description: p.description,
    bedrooms: p.bedrooms,
    bathrooms: p.bathrooms,
    size_m2: p.size_m2 != null ? String(p.size_m2) : '',
    floor_number: p.floor_number != null ? String(p.floor_number) : '',
    furnished: p.furnished,
    max_occupants: p.max_occupants != null ? String(p.max_occupants) : '',
    house_rules: p.house_rules || '',
    amenities: p.amenities,
    price_monthly: String(p.price_monthly),
    price_weekly: p.price_weekly != null ? String(p.price_weekly) : '',
    price_daily: p.price_daily != null ? String(p.price_daily) : '',
    availability: p.availability_date ? 'date' : 'now',
    availability_date: p.availability_date || '',
    location: {
      latitude: p.latitude,
      longitude: p.longitude,
      region: p.region || '',
      city: p.city || '',
      district: p.district || '',
      neighborhood: p.neighborhood || '',
      street: p.street || '',
      landmark: p.landmark || '',
    },
  };
}

const wiz = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    backgroundColor: colors.white,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  typeCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.white,
    borderRadius: radius.lg,
    borderWidth: 1.6,
    borderColor: colors.border,
    padding: spacing.lg,
  },
  typeCardActive: { borderColor: colors.blue, backgroundColor: colors.blue50 },
  twoCol: { flexDirection: 'row', gap: spacing.md },
  switchTrack: { width: 46, height: 27, borderRadius: 14, backgroundColor: '#CBD8EC', padding: 3, justifyContent: 'center' },
  switchKnob: { width: 21, height: 21, borderRadius: 11, backgroundColor: colors.white },
  customInput: {
    flex: 1,
    backgroundColor: colors.white,
    borderWidth: 1.5,
    borderColor: colors.border,
    borderRadius: radius.md,
    height: 38,
    paddingHorizontal: 12,
    color: colors.text,
    fontSize: 13,
  },
  footer: {
    flexDirection: 'row',
    gap: spacing.md,
    padding: spacing.xl,
    paddingTop: spacing.md,
    backgroundColor: colors.white,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.border,
  },
});
