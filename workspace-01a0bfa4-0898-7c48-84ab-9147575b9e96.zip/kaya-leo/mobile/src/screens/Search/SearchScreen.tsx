import React, { useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useRoute } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RouteProp } from '@react-navigation/native';
import * as Location from 'expo-location';
import { PropertyRowCard } from '../../components/PropertyCard';
import { BottomSheet } from '../../components/Modals';
import { Button, Chip, EmptyState, ErrorState, Skeleton } from '../../components/ui';
import { colors, radius, spacing, styles as s, typography } from '../../theme';
import { useT } from '../../i18n';
import { useAmenities, useFavoriteIds, useSearchResults, useToggleFavorite } from '../../hooks/queries';
import { useAuth } from '../../state/AuthContext';
import { PROPERTY_TYPE_LABELS, type SortOption } from '../../types/models';
import type { RootStackParamList } from '../../types/navigation';
import { formatTZS } from '../../utils/format';

const SORTS: Array<{ id: SortOption; key: 'sort_newest' | 'sort_price_asc' | 'sort_price_desc' | 'sort_distance' | 'sort_recommended' }> = [
  { id: 'recommended', key: 'sort_recommended' },
  { id: 'newest', key: 'sort_newest' },
  { id: 'price_asc', key: 'sort_price_asc' },
  { id: 'price_desc', key: 'sort_price_desc' },
  { id: 'distance', key: 'sort_distance' },
];

export default function SearchScreen() {
  const nav = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const route = useRoute<RouteProp<RootStackParamList, 'Search'>>();
  const { t } = useT();
  const { session } = useAuth();
  const favIds = useFavoriteIds(session);
  const toggleFavorite = useToggleFavorite();
  const amenitiesQuery = useAmenities();

  const [text, setText] = useState(route.params?.initialQuery || '');
  const [debounced, setDebounced] = useState(route.params?.initialQuery || '');
  const [showFilters, setShowFilters] = useState(false);
  const [showSort, setShowSort] = useState(false);
  const [gps, setGps] = useState<{ lat: number; lng: number } | null>(null);

  // filters state
  const [type, setType] = useState<string | undefined>(undefined);
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [beds, setBeds] = useState(0);
  const [baths, setBaths] = useState(0);
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([]);
  const [furnishedOnly, setFurnishedOnly] = useState(false);
  const [availableNow, setAvailableNow] = useState(false);
  const [sort, setSort] = useState<SortOption>('recommended');

  useEffect(() => {
    const h = setTimeout(() => setDebounced(text.trim()), 450);
    return () => clearTimeout(h);
  }, [text]);

  const filters = useMemo(
    () => ({
      q: debounced || undefined,
      property_type: type as never,
      min_price: minPrice ? Number(minPrice) : undefined,
      max_price: maxPrice ? Number(maxPrice) : undefined,
      bedrooms: beds || undefined,
      bathrooms: baths || undefined,
      amenities: selectedAmenities.length ? selectedAmenities : undefined,
      furnished: furnishedOnly || undefined,
      available_now: availableNow || undefined,
      sort,
      near_lat: sort === 'distance' && gps ? gps.lat : undefined,
      near_lng: sort === 'distance' && gps ? gps.lng : undefined,
      page_size: 10,
    }),
    [debounced, type, minPrice, maxPrice, beds, baths, selectedAmenities, furnishedOnly, availableNow, sort, gps]
  );

  const results = useSearchResults(filters);
  const items = results.data?.pages.flatMap((p) => p.items) || [];
  const total = results.data?.pages[0]?.total ?? 0;

  const useMyLocation = async () => {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status === 'granted') {
      const pos = await Location.getCurrentPositionAsync({});
      setGps({ lat: pos.coords.latitude, lng: pos.coords.longitude });
      setSort('distance');
    }
  };

  const activeFilterCount =
    (type ? 1 : 0) + (minPrice ? 1 : 0) + (maxPrice ? 1 : 0) + (beds ? 1 : 0) + (baths ? 1 : 0) +
    selectedAmenities.length + (furnishedOnly ? 1 : 0) + (availableNow ? 1 : 0);

  const isFav = (id: string) => favIds.data?.ids.includes(id) ?? false;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.white }} edges={['top']}>
      {/* Search field */}
      <View style={search.header}>
        <Pressable onPress={() => nav.goBack()} hitSlop={8}>
          <Ionicons name="arrow-back" size={23} color={colors.text} />
        </Pressable>
        <View style={search.field}>
          <Ionicons name="search" size={17} color={colors.blue} />
          <TextInput
            value={text}
            onChangeText={setText}
            placeholder={t('search_input_hint')}
            placeholderTextColor={colors.muted}
            style={{ flex: 1, marginLeft: 8, fontSize: 14.5, color: colors.text }}
            autoFocus={!route.params?.initialQuery}
            returnKeyType="search"
          />
          {text ? (
            <Pressable onPress={() => setText('')} hitSlop={8}>
              <Ionicons name="close-circle" size={17} color={colors.muted} />
            </Pressable>
          ) : null}
        </View>
      </View>

      {/* Filter + sort row */}
      <View style={[s.row, { paddingHorizontal: spacing.xl, gap: spacing.sm, paddingBottom: spacing.md }]}>
        <Pressable style={[search.pill, activeFilterCount ? search.pillActive : null]} onPress={() => setShowFilters(true)}>
          <Ionicons name="options" size={15} color={activeFilterCount ? colors.royal : colors.subtext} />
          <Text style={[search.pillText, activeFilterCount > 0 && { color: colors.royal, fontWeight: '800' }]}>
            {t('filters')}{activeFilterCount ? ` · ${activeFilterCount}` : ''}
          </Text>
        </Pressable>
        <Pressable style={search.pill} onPress={() => setShowSort(true)}>
          <Ionicons name="swap-vertical" size={15} color={colors.subtext} />
          <Text style={search.pillText}>{SORTS.find((x) => x.id === sort) ? t(SORTS.find((x) => x.id === sort)!.key) : t('sort')}</Text>
        </Pressable>
        <Pressable style={[search.pill, gps && sort === 'distance' ? search.pillActive : null]} onPress={useMyLocation}>
          <Ionicons name="navigate" size={14} color={colors.blue} />
        </Pressable>
      </View>

      {/* Results */}
      {results.isLoading ? (
        <View style={{ padding: spacing.xl, gap: spacing.md }}>
          {[1, 2, 3].map((i) => (
            <View key={i} style={[s.card, { padding: spacing.md, flexDirection: 'row', gap: spacing.md }]}>
              <Skeleton width={100} height={90} />
              <View style={{ flex: 1, gap: 8, paddingTop: 4 }}>
                <Skeleton width={'70%' as const} height={14} />
                <Skeleton width={'50%' as const} height={11} />
                <Skeleton width={'40%' as const} height={14} />
              </View>
            </View>
          ))}
        </View>
      ) : results.isError ? (
        <ErrorState message={t('load_failed')} onRetry={() => results.refetch()} />
      ) : items.length === 0 ? (
        <EmptyState icon="search-outline" title={t('empty_generic')} subtitle={t('clear_filters')} />
      ) : (
        <FlatList
          data={items}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ paddingHorizontal: spacing.xl, paddingBottom: spacing.xxl }}
          ListHeaderComponent={
            <Text style={[typography.small, { marginBottom: spacing.md }]}>
              {total} {t('results')}
            </Text>
          }
          renderItem={({ item }) => (
            <PropertyRowCard
              property={{ ...item, is_favorite: isFav(item.id) }}
              onPress={() => nav.navigate('PropertyDetails', { propertyId: item.id })}
              onToggleFavorite={() => toggleFavorite.mutate({ propertyId: item.id, favorited: isFav(item.id) })}
            />
          )}
          onEndReachedThreshold={0.4}
          onEndReached={() => {
            if (results.hasNextPage && !results.isFetchingNextPage) results.fetchNextPage();
          }}
          ListFooterComponent={
            results.isFetchingNextPage ? (
              <ActivityIndicator color={colors.blue} style={{ marginVertical: spacing.lg }} />
            ) : null
          }
        />
      )}

      {/* ---------- Filters bottom sheet ---------- */}
      <Modal visible={showFilters} transparent animationType="slide" onRequestClose={() => setShowFilters(false)}>
        <View style={{ flex: 1, backgroundColor: 'rgba(10,42,94,0.45)', justifyContent: 'flex-end' }}>
          <Pressable style={{ flex: 1 }} onPress={() => setShowFilters(false)} />
          <View style={search.sheet}>
            <View style={search.handle} />
            <ScrollView showsVerticalScrollIndicator={false}>
              <Text style={typography.title}>{t('filters')}</Text>

              <Text style={[search.groupLabel, { marginTop: spacing.lg }]}>{t('filter_type')}</Text>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
                {(['APARTMENT', 'HOUSE', 'ROOM'] as const).map((tp) => (
                  <Chip
                    key={tp}
                    label={`${PROPERTY_TYPE_LABELS[tp].sw}`}
                    active={type === tp}
                    onPress={() => setType(type === tp ? undefined : tp)}
                  />
                ))}
              </View>

              <Text style={[search.groupLabel, { marginTop: spacing.sm }]}>{t('filter_price')}</Text>
              <View style={[s.row, { gap: spacing.md }]}>
                <View style={{ flex: 1 }}>
                  <Text style={typography.tiny}>{t('filter_min')}</Text>
                  <TextInput
                    value={minPrice}
                    onChangeText={setMinPrice}
                    keyboardType="number-pad"
                    placeholder="0"
                    placeholderTextColor={colors.muted}
                    style={search.numField}
                  />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={typography.tiny}>{t('filter_max')}</Text>
                  <TextInput
                    value={maxPrice}
                    onChangeText={setMaxPrice}
                    keyboardType="number-pad"
                    placeholder="2,000,000"
                    placeholderTextColor={colors.muted}
                    style={search.numField}
                  />
                </View>
              </View>
              {minPrice && maxPrice ? (
                <Text style={typography.tiny}>
                  {formatTZS(Number(minPrice))} — {formatTZS(Number(maxPrice))}
                </Text>
              ) : null}

              <View style={[s.row, { marginTop: spacing.lg, gap: spacing.xl }]}>
                <View>
                  <Text style={search.groupLabel}>{t('filter_beds')} ≥</Text>
                  <Stepper value={beds} onChange={setBeds} />
                </View>
                <View>
                  <Text style={search.groupLabel}>{t('filter_baths')} ≥</Text>
                  <Stepper value={baths} onChange={setBaths} />
                </View>
              </View>

              <Text style={[search.groupLabel, { marginTop: spacing.lg }]}>{t('filter_amenities')}</Text>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
                {(amenitiesQuery.data?.items || []).map((a) => (
                  <Chip
                    key={a.id}
                    label={a.name}
                    active={selectedAmenities.includes(a.name)}
                    onPress={() =>
                      setSelectedAmenities((prev) =>
                        prev.includes(a.name) ? prev.filter((x) => x !== a.name) : [...prev, a.name]
                      )
                    }
                  />
                ))}
              </View>

              <View style={[s.row, { marginTop: spacing.lg, justifyContent: 'space-between' }]}>
                <Text style={typography.body}>{t('filter_furnished')}</Text>
                <SwitchLike on={furnishedOnly} onToggle={() => setFurnishedOnly((v) => !v)} />
              </View>
              <View style={[s.row, { justifyContent: 'space-between', marginTop: spacing.md }]}>
                <Text style={typography.body}>{t('filter_available')}</Text>
                <SwitchLike on={availableNow} onToggle={() => setAvailableNow((v) => !v)} />
              </View>
            </ScrollView>

            <View style={[s.row, { gap: spacing.md, marginTop: spacing.lg }]}>
              <Button
                title={t('clear_filters')}
                variant="secondary"
                style={{ flex: 1 }}
                onPress={() => {
                  setType(undefined);
                  setMinPrice('');
                  setMaxPrice('');
                  setBeds(0);
                  setBaths(0);
                  setSelectedAmenities([]);
                  setFurnishedOnly(false);
                  setAvailableNow(false);
                }}
              />
              <Button title={t('apply')} style={{ flex: 1 }} onPress={() => setShowFilters(false)} />
            </View>
          </View>
        </View>
      </Modal>

      {/* ---------- Sort sheet ---------- */}
      <BottomSheet visible={showSort} onClose={() => setShowSort(false)}>
        <Text style={[typography.title, { marginBottom: spacing.md }]}>{t('sort')}</Text>
        {SORTS.map((opt) => (
          <Pressable
            key={opt.id}
            style={[s.row, { paddingVertical: 13, justifyContent: 'space-between' }]}
            onPress={() => {
              setSort(opt.id);
              setShowSort(false);
            }}
          >
            <Text style={[typography.body, sort === opt.id && { color: colors.royal, fontWeight: '800' }]}>
              {t(opt.key)}
            </Text>
            {sort === opt.id ? <Ionicons name="checkmark" size={20} color={colors.royal} /> : null}
          </Pressable>
        ))}
      </BottomSheet>
    </SafeAreaView>
  );
}

function Stepper({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  return (
    <View style={[s.row, { gap: 12, marginTop: 6 }]}>
      <Pressable style={search.stepBtn} onPress={() => onChange(Math.max(0, value - 1))}>
        <Ionicons name="remove" size={16} color={colors.royal} />
      </Pressable>
      <Text style={{ width: 22, textAlign: 'center', fontWeight: '800', fontSize: 16 }}>{value}</Text>
      <Pressable style={search.stepBtn} onPress={() => onChange(Math.min(10, value + 1))}>
        <Ionicons name="add" size={16} color={colors.royal} />
      </Pressable>
    </View>
  );
}

function SwitchLike({ on, onToggle }: { on: boolean; onToggle: () => void }) {
  return (
    <Pressable
      onPress={onToggle}
      style={[search.switchTrack, on && { backgroundColor: colors.royal }]}
    >
      <View style={[search.switchKnob, on && { alignSelf: 'flex-end' }]} />
    </Pressable>
  );
}

const search = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: spacing.xl, paddingTop: spacing.md, paddingBottom: spacing.md },
  field: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.blue50,
    borderRadius: radius.pill,
    borderWidth: 1.5,
    borderColor: colors.border,
    paddingHorizontal: 14,
    height: 46,
  },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    borderWidth: 1.5,
    borderColor: colors.border,
    borderRadius: radius.pill,
    paddingHorizontal: 13,
    height: 36,
    backgroundColor: colors.white,
  },
  pillActive: { backgroundColor: colors.skyLight, borderColor: colors.blue },
  pillText: { fontSize: 13, fontWeight: '700', color: colors.subtext },
  sheet: {
    backgroundColor: colors.white,
    borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl,
    padding: spacing.xl,
    paddingBottom: 34,
    maxHeight: '86%',
  },
  handle: { alignSelf: 'center', width: 44, height: 5, borderRadius: 3, backgroundColor: colors.border, marginBottom: spacing.md },
  groupLabel: { fontSize: 13, fontWeight: '800', color: colors.text, marginBottom: 8 },
  numField: {
    backgroundColor: colors.blue50,
    borderWidth: 1.5,
    borderColor: colors.border,
    borderRadius: radius.md,
    height: 44,
    paddingHorizontal: 12,
    color: colors.text,
    marginTop: 2,
  },
  stepBtn: { width: 30, height: 30, borderRadius: 15, backgroundColor: colors.blue50, alignItems: 'center', justifyContent: 'center', borderWidth: 1.2, borderColor: colors.border },
  switchTrack: { width: 46, height: 27, borderRadius: 14, backgroundColor: '#CBD8EC', padding: 3, justifyContent: 'center' },
  switchKnob: { width: 21, height: 21, borderRadius: 11, backgroundColor: colors.white },
});
