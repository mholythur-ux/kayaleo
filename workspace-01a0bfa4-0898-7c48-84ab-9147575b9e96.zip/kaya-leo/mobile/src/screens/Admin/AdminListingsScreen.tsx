import React, { useState } from 'react';
import { Alert, FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useRoute } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RouteProp } from '@react-navigation/native';
import { useQueryClient } from '@tanstack/react-query';
import { PropertyRowCard } from '../../components/PropertyCard';
import { Badge, Button, EmptyState, ErrorState, Skeleton } from '../../components/ui';
import { colors, radius, spacing, styles as s, typography } from '../../theme';
import { useT } from '../../i18n';
import { useAdminListings, keys as qk } from '../../hooks/queries';
import { adminApi } from '../../api';
import type { PropertyFull } from '../../types/models';
import type { RootStackParamList } from '../../types/navigation';

export default function AdminListingsScreen() {
  const nav = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const route = useRoute<RouteProp<RootStackParamList, 'AdminListings'>>();
  const { t } = useT();
  const qc = useQueryClient();
  const [status, setStatus] = useState<string | undefined>(route.params?.status);
  const query = useAdminListings(status);

  const moderate = (p: PropertyFull, action: 'approve' | 'reject' | 'suspend') => {
    const run = async (reason?: string) => {
      try {
        await adminApi.moderate(p.id, action, reason);
        qc.invalidateQueries({ queryKey: ['adminListings'] });
        qc.invalidateQueries({ queryKey: qk.adminStats });
      } catch (e) {
        Alert.alert('Kaya Leo', (e as Error).message);
      }
    };
    if (action === 'reject') {
      Alert.alert('Kataa tangazo', `Kataa "${p.title}"? Sababu itamwonekana mwenye nyumba.`, [
        { text: t('cancel'), style: 'cancel' },
        { text: t('reject'), style: 'destructive', onPress: () => run('Haitoshi vigezo vya Kaya Leo') },
      ]);
      return;
    }
    Alert.alert(action === 'suspend' ? t('suspend') : t('approve'), `"${p.title}"?`, [
      { text: t('cancel'), style: 'cancel' },
      { text: t('confirm'), style: 'default', onPress: () => run() },
    ]);
  };

  const removeListing = (p: PropertyFull) => {
    Alert.alert(t('delete'), `Futa "${p.title}" kabisa (ulaghai)?`, [
      { text: t('cancel'), style: 'cancel' },
      {
        text: t('delete'),
        style: 'destructive',
        onPress: async () => {
          try {
            await adminApi.removeListing(p.id);
            qc.invalidateQueries({ queryKey: ['adminListings'] });
            qc.invalidateQueries({ queryKey: qk.adminStats });
          } catch (e) {
            Alert.alert('Kaya Leo', (e as Error).message);
          }
        },
      },
    ]);
  };

  const tabs = [
    { id: undefined, label: 'Zote' },
    { id: 'pending', label: 'Ukaguzini' },
    { id: 'approved', label: 'Zilizoidhinishwa' },
    { id: 'rejected', label: 'Zilizokataliwa' },
    { id: 'suspended', label: 'Zilizosimamishwa' },
  ];

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }} edges={['top']}>
      <View style={adm.header}>
        <Pressable onPress={() => nav.goBack()} hitSlop={8}>
          <Ionicons name="arrow-back" size={23} color={colors.text} />
        </Pressable>
        <Text style={typography.title}>Udhibiti wa Tangazo</Text>
        <View style={{ width: 23 }} />
      </View>

      <FlatList
        horizontal
        showsHorizontalScrollIndicator={false}
        data={tabs}
        keyExtractor={(item) => String(item.id)}
        style={{ backgroundColor: colors.white }}
        contentContainerStyle={{ paddingHorizontal: spacing.xl, paddingBottom: spacing.md }}
        renderItem={({ item }) => (
          <Pressable style={[adm.tab, status === item.id && adm.tabActive]} onPress={() => setStatus(item.id)}>
            <Text style={[adm.tabText, status === item.id && adm.tabTextActive]}>{item.label}</Text>
          </Pressable>
        )}
      />

      <FlatList
        data={query.data?.items || []}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: spacing.xl, paddingBottom: spacing.xxxl }}
        renderItem={({ item }) => (
          <View>
            <PropertyRowCard
              property={item}
              statusLabel={`Hali: ${item.status}`}
              onPress={() => nav.navigate('PropertyDetails', { propertyId: item.id })}
              onToggleFavorite={() => {}}
            />
            <View style={[s.row, { gap: 8, marginTop: -8, marginBottom: spacing.lg, flexWrap: 'wrap' }]}>
              {item.status !== 'approved' ? (
                <Button title={t('approve')} small icon="checkmark" onPress={() => moderate(item, 'approve')} />
              ) : null}
              {item.status !== 'rejected' ? (
                <Button title={t('reject')} small variant="secondary" icon="close" onPress={() => moderate(item, 'reject')} />
              ) : null}
              {item.status === 'approved' ? (
                <Button title={t('suspend')} small variant="secondary" icon="pause" onPress={() => moderate(item, 'suspend')} />
              ) : null}
              <Button title={t('delete')} small variant="danger" icon="trash" onPress={() => removeListing(item)} />
            </View>
          </View>
        )}
        ListEmptyComponent={
          query.isLoading ? (
            <View style={{ gap: spacing.md }}>
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} width={'100%'} height={90} />
              ))}
            </View>
          ) : query.isError ? (
            <ErrorState message={t('load_failed')} onRetry={() => query.refetch()} />
          ) : (
            <EmptyState icon="checkmark-done" title="Hakuna tangazo katika hali hii" />
          )
        }
      />
    </SafeAreaView>
  );
}

const adm = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    backgroundColor: colors.white,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  tab: {
    paddingHorizontal: 14,
    height: 34,
    borderRadius: radius.pill,
    borderWidth: 1.4,
    borderColor: colors.border,
    backgroundColor: colors.white,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
    marginTop: spacing.md,
  },
  tabActive: { backgroundColor: colors.royal, borderColor: colors.royal },
  tabText: { fontSize: 12.5, fontWeight: '700', color: colors.subtext },
  tabTextActive: { color: colors.white },
});
