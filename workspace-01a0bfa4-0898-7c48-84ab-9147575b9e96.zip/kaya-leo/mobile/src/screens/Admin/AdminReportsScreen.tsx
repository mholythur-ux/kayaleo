import React, { useState } from 'react';
import { Alert, FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useQueryClient } from '@tanstack/react-query';
import { Badge, Button, EmptyState, ErrorState, Skeleton } from '../../components/ui';
import { colors, spacing, styles as s, typography } from '../../theme';
import { useT } from '../../i18n';
import { useAdminReports, keys as qk } from '../../hooks/queries';
import { adminApi } from '../../api';
import type { RootStackParamList } from '../../types/navigation';
import { timeAgo } from '../../utils/format';

type ReportRow = {
  id: string;
  property_id: string;
  reason: string;
  details: string;
  status: string;
  created_at: string;
  property_title?: string | null;
};

const REASON_LABELS: Record<string, string> = {
  FAKE_PROPERTY: 'Nyumba ya uongo',
  WRONG_INFORMATION: 'Taarifa si sahihi',
  SCAM_SUSPICIOUS: 'Utapeli',
  INCORRECT_PRICE: 'Bei si sahihi',
  ALREADY_UNAVAILABLE: 'Haipatikani',
  INAPPROPRIATE_CONTENT: 'Maudhui yasiyofaa',
  OTHER: 'Nyingine',
};

export default function AdminReportsScreen() {
  const nav = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { t } = useT();
  const qc = useQueryClient();
  const [status, setStatus] = useState<'open' | 'resolved' | 'dismissed' | undefined>('open');
  const query = useAdminReports(status);

  const setReportStatus = (id: string, newStatus: 'resolved' | 'dismissed') => {
    Alert.alert(newStatus === 'resolved' ? t('resolve') : t('dismiss'), 'Una uhakika?', [
      { text: t('cancel'), style: 'cancel' },
      {
        text: t('confirm'),
        onPress: async () => {
          try {
            await adminApi.setReportStatus(id, newStatus);
            qc.invalidateQueries({ queryKey: ['adminReports'] });
            qc.invalidateQueries({ queryKey: qk.adminStats });
          } catch (e) {
            Alert.alert('Kaya Leo', (e as Error).message);
          }
        },
      },
    ]);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }} edges={['top']}>
      <View style={rep.header}>
        <Pressable onPress={() => nav.goBack()} hitSlop={8}>
          <Ionicons name="arrow-back" size={23} color={colors.text} />
        </Pressable>
        <Text style={typography.title}>{t('reports_title')}</Text>
        <View style={{ width: 23 }} />
      </View>

      <View style={[s.row, { paddingHorizontal: spacing.xl, paddingVertical: spacing.md, backgroundColor: colors.white, gap: 8 }]}>
        {(['open', 'resolved', 'dismissed'] as const).map((st) => (
          <Pressable key={st} style={[rep.tab, status === st && rep.tabActive]} onPress={() => setStatus(st)}>
            <Text style={[rep.tabText, status === st && rep.tabTextActive]}>
              {st === 'open' ? 'Wazi' : st === 'resolved' ? 'Zilizomalizika' : 'Zilizopuuzwa'}
            </Text>
          </Pressable>
        ))}
      </View>

      <FlatList
        data={(query.data?.items as ReportRow[]) || []}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: spacing.xl, paddingBottom: spacing.xxl }}
        renderItem={({ item }) => (
          <View style={[s.card, { padding: spacing.md, marginBottom: spacing.md }]}>
            <View style={[s.row, { justifyContent: 'space-between' }]}>
              <Badge text={REASON_LABELS[item.reason] || item.reason} tone="danger" />
              <Text style={typography.tiny}>{timeAgo(item.created_at)}</Text>
            </View>
            {item.property_title ? (
              <Text style={{ fontWeight: '800', fontSize: 13.5, marginTop: 8 }}>{item.property_title}</Text>
            ) : null}
            {item.details ? <Text style={[typography.small, { marginTop: 4 }]}>{item.details}</Text> : null}
            <View style={[s.row, { gap: 8, marginTop: spacing.md }]}>
              {item.status === 'open' ? (
                <>
                  <Button title={t('resolve')} small icon="checkmark" onPress={() => setReportStatus(item.id, 'resolved')} />
                  <Button title={t('dismiss')} small variant="secondary" onPress={() => setReportStatus(item.id, 'dismissed')} />
                </>
              ) : (
                <Badge text={item.status} />
              )}
            </View>
          </View>
        )}
        ListEmptyComponent={
          query.isLoading ? (
            <View style={{ gap: spacing.md }}>
              {[1, 2].map((i) => (
                <Skeleton key={i} width={'100%'} height={90} />
              ))}
            </View>
          ) : query.isError ? (
            <ErrorState message={t('load_failed')} onRetry={() => query.refetch()} />
          ) : (
            <EmptyState icon="flag-outline" title="Hakuna ripoti hapa" />
          )
        }
      />
    </SafeAreaView>
  );
}

const rep = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    backgroundColor: colors.white,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  tab: {
    paddingHorizontal: 14,
    height: 34,
    borderRadius: 999,
    borderWidth: 1.4,
    borderColor: colors.border,
    backgroundColor: colors.white,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabActive: { backgroundColor: colors.royal, borderColor: colors.royal },
  tabText: { fontSize: 12.5, fontWeight: '700', color: colors.subtext },
  tabTextActive: { color: colors.white },
});
