import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { ErrorState, Skeleton, StatCard } from '../../components/ui';
import { colors, spacing, styles as s, typography } from '../../theme';
import { useT } from '../../i18n';
import { useAdminStats } from '../../hooks/queries';
import type { RootStackParamList } from '../../types/navigation';

type Nav = NativeStackNavigationProp<RootStackParamList>;

export default function AdminDashboardScreen() {
  const nav = useNavigation<Nav>();
  const { t } = useT();
  const stats = useAdminStats(true);

  const st = stats.data?.stats;

  const sections: Array<{
    icon: keyof typeof Ionicons.glyphMap;
    title: string;
    subtitle: string;
    badge?: number;
    onPress: () => void;
  }> = [
    {
      icon: 'hourglass',
      title: 'Uidhinishaji wa tangazo',
      subtitle: 'Kubali, kataa au simamisha tangazo',
      badge: st?.pending_listings,
      onPress: () => nav.navigate('AdminListings', { status: 'pending' }),
    },
    {
      icon: 'flag',
      title: t('reports_title'),
      subtitle: 'Ripoti kutoka kwa watumiaji',
      badge: st?.open_reports,
      onPress: () => nav.navigate('AdminReports', undefined),
    },
    {
      icon: 'people',
      title: 'Watumiaji na Wenyenumba',
      subtitle: 'Thibitisha wenyenumba, badilisha majukumu',
      onPress: () => nav.navigate('AdminUsers', undefined),
    },
    {
      icon: 'list',
      title: 'Tangazo zote',
      subtitle: 'Tazama na dhibiti tangazo zote',
      onPress: () => nav.navigate('AdminListings', undefined),
    },
  ];

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.navy }} edges={['top']}>
      <View style={{ paddingHorizontal: spacing.xl, paddingTop: spacing.lg, paddingBottom: spacing.xl }}>
        <View style={[s.row, { justifyContent: 'space-between' }]}>
          <View>
            <Text style={{ color: colors.sky, fontWeight: '700', fontSize: 12 }}>KAYA LEO ADMIN</Text>
            <Text style={[typography.title, { color: colors.white, marginTop: 2 }]}>Dashibodi ya Msimamizi</Text>
          </View>
          <Pressable onPress={() => nav.goBack()} hitSlop={8} style={adm.backBtn}>
            <Ionicons name="close" size={20} color={colors.white} />
          </Pressable>
        </View>
      </View>

      <View style={{ flex: 1, backgroundColor: colors.bg, borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingTop: spacing.xl }}>
        {stats.isLoading ? (
          <View style={{ paddingHorizontal: spacing.xl, flexDirection: 'row', gap: 8 }}>
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} width={'30%'} height={72} />
            ))}
          </View>
        ) : stats.isError ? (
          <ErrorState message={t('load_failed')} onRetry={() => stats.refetch()} />
        ) : st ? (
          <View style={{ paddingHorizontal: spacing.xl }}>
            <View style={{ flexDirection: 'row', gap: 8, marginBottom: 8 }}>
              <StatCard icon="people" value={st.total_users} label={t('admin_stats_users')} />
              <StatCard icon="business" value={st.total_hosts} label={t('admin_stats_hosts')} />
              <StatCard icon="home" value={st.total_properties} label={t('admin_stats_properties')} />
            </View>
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <StatCard icon="time" value={st.pending_listings} label={t('admin_stats_pending')} tone={colors.warning} />
              <StatCard icon="checkmark-circle" value={st.approved_listings} label="Zilizoidhinishwa" tone={colors.success} />
              <StatCard icon="flag" value={st.open_reports} label={t('reports_title')} tone={colors.danger} />
            </View>
          </View>
        ) : null}

        <View style={{ padding: spacing.xl, gap: spacing.md }}>
          {sections.map((sec) => (
            <Pressable key={sec.title} style={[s.card, adm.row]} onPress={sec.onPress} android_ripple={{ color: colors.blue50 }}>
              <View style={[adm.iconWrap, { backgroundColor: (sec.badge || 0) > 0 ? colors.blue50 : colors.blue50 }]}>
                <Ionicons name={sec.icon} size={20} color={colors.royal} />
                {sec.badge ? (
                  <View style={adm.badge}>
                    <Text style={{ color: colors.white, fontSize: 10, fontWeight: '800' }}>{sec.badge}</Text>
                  </View>
                ) : null}
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontWeight: '800', fontSize: 14.5, color: colors.text }}>{sec.title}</Text>
                <Text style={typography.tiny}>{sec.subtitle}</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={colors.muted} />
            </Pressable>
          ))}
        </View>
      </View>
    </SafeAreaView>
  );
}

const adm = StyleSheet.create({
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(255,255,255,0.14)', alignItems: 'center', justifyContent: 'center' },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: spacing.lg },
  iconWrap: { width: 42, height: 42, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  badge: {
    position: 'absolute',
    top: -6,
    right: -8,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: colors.heart,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 5,
    borderWidth: 2,
    borderColor: colors.white,
  },
});
