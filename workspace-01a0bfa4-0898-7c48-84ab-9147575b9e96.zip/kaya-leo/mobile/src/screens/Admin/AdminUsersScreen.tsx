import React from 'react';
import { Alert, FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useQueryClient } from '@tanstack/react-query';
import { Avatar, Badge, EmptyState, ErrorState, Skeleton } from '../../components/ui';
import { colors, spacing, styles as s, typography } from '../../theme';
import { useT } from '../../i18n';
import { useAdminUsers, keys as qk } from '../../hooks/queries';
import { adminApi } from '../../api';
import type { Profile } from '../../types/models';
import type { RootStackParamList } from '../../types/navigation';

export default function AdminUsersScreen() {
  const nav = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { t } = useT();
  const qc = useQueryClient();
  const query = useAdminUsers(true);

  const verifyHost = (u: Profile) => {
    const run = async () => {
      try {
        await adminApi.setUserVerified(u.id, !u.is_verified);
        qc.invalidateQueries({ queryKey: qk.adminUsers });
      } catch (e) {
        Alert.alert('Kaya Leo', (e as Error).message);
      }
    };
    Alert.alert(
      t('approve_host'),
      u.is_verified ? `Ondoa uthibitisho wa "${u.full_name}"?` : `Thibitisha "${u.full_name}" kama mwenye nyumba mwaminifu?`,
      [
        { text: t('cancel'), style: 'cancel' },
        { text: t('confirm'), onPress: run },
      ]
    );
  };

  const makeRole = (u: Profile, role: 'USER' | 'HOST' | 'ADMIN') => {
    Alert.alert('Badilisha jukumu', ` "${u.full_name}" → ${role}?`, [
      { text: t('cancel'), style: 'cancel' },
      {
        text: t('confirm'),
        onPress: async () => {
          try {
            await adminApi.setUserRole(u.id, role);
            qc.invalidateQueries({ queryKey: qk.adminUsers });
          } catch (e) {
            Alert.alert('Kaya Leo', (e as Error).message);
          }
        },
      },
    ]);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }} edges={['top']}>
      <View style={users.header}>
        <Pressable onPress={() => nav.goBack()} hitSlop={8}>
          <Ionicons name="arrow-back" size={23} color={colors.text} />
        </Pressable>
        <Text style={typography.title}>Watumiaji ({query.data?.total ?? '...'})</Text>
        <View style={{ width: 23 }} />
      </View>

      <FlatList
        data={query.data?.items || []}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: spacing.xl, paddingBottom: spacing.xxl }}
        renderItem={({ item }) => (
          <View style={[s.card, users.card]}>
            <Avatar uri={item.avatar_url} name={item.full_name} size={44} />
            <View style={{ flex: 1, marginLeft: spacing.md }}>
              <View style={[s.row, { gap: 6 }]}>
                <Text style={{ fontWeight: '800', fontSize: 14, flexShrink: 1 }} numberOfLines={1}>
                  {item.full_name}
                </Text>
                {item.is_verified ? <Badge text="✓" tone="success" /> : null}
                <Badge text={item.role === 'ADMIN' ? 'Admin' : item.role === 'HOST' ? 'Mwenye Nyumba' : 'Mwanachama'} tone="blue" />
              </View>
              <Text style={typography.tiny} numberOfLines={1}>
                {item.email} {item.phone ? `· ${item.phone}` : ''}
              </Text>
              <View style={[s.row, { gap: 8, marginTop: 8 }]}>
                {item.role !== 'ADMIN' ? (
                  <Pressable style={users.smallBtn} onPress={() => verifyHost(item)}>
                    <Ionicons name={item.is_verified ? 'shield-half' : 'shield-checkmark'} size={14} color={colors.royal} />
                    <Text style={users.smallBtnText}>{item.is_verified ? 'Ondoa ✓' : t('approve_host')}</Text>
                  </Pressable>
                ) : null}
                {item.role !== 'ADMIN' ? (
                  <Pressable style={users.smallBtn} onPress={() => makeRole(item, 'ADMIN')}>
                    <Ionicons name="key" size={14} color={colors.warning} />
                    <Text style={users.smallBtnText}>Fanya Admin</Text>
                  </Pressable>
                ) : null}
              </View>
            </View>
          </View>
        )}
        ListEmptyComponent={
          query.isLoading ? (
            <View style={{ gap: spacing.md }}>
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} width={'100%'} height={70} />
              ))}
            </View>
          ) : query.isError ? (
            <ErrorState message={t('load_failed')} onRetry={() => query.refetch()} />
          ) : (
            <EmptyState icon="people-outline" title="Hakuna watumiaji" />
          )
        }
      />
    </SafeAreaView>
  );
}

const users = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    backgroundColor: colors.white,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  card: { flexDirection: 'row', alignItems: 'center', padding: spacing.md, marginBottom: spacing.md },
  smallBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: colors.blue50,
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderWidth: 1.2,
    borderColor: colors.border,
  },
  smallBtnText: { fontSize: 11.5, fontWeight: '800', color: colors.royal },
});
