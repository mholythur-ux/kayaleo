import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { colors, spacing, styles as s, typography } from '../../theme';
import type { RootStackParamList } from '../../types/navigation';

export default function TermsPrivacyScreen() {
  const nav = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }} edges={['top']}>
      <View style={terms.header}>
        <Pressable onPress={() => nav.goBack()} hitSlop={8}>
          <Ionicons name="arrow-back" size={23} color={colors.text} />
        </Pressable>
        <Text style={typography.title}>Masharti na Faragha</Text>
        <View style={{ width: 23 }} />
      </View>
      <ScrollView contentContainerStyle={{ padding: spacing.xl }}>
        <View style={[s.card, { padding: spacing.xl }]}>
          <Text style={typography.h2}>Masharti ya matumizi</Text>
          <Text style={[terms.p]}>
            1. Kaya Leo ni jukwaa linalounganisha wapangaji na wenyenumba. Hatumiliki nyumba zilizotangazwa.
          </Text>
          <Text style={terms.p}>
            2. Kila tangazo hukaguliwa na timu yetu kabla ya kuchapishwa. Hakikisha unatembelea nyumba na kuhakiki
            umilikii kabla ya malipo yoyote.
          </Text>
          <Text style={terms.p}>
            3. Kutangaza taarifa za uongo kunasababisha kufutwa kwa akaunti.
          </Text>
          <Text style={[typography.h2, { marginTop: spacing.xl }]}>Faragha</Text>
          <Text style={terms.p}>
            1. Tunahifadhi taarifa zako kwa usalama (Supabase + Row Level Security). Hatuwiuzi kwa mtu yeyote.
          </Text>
          <Text style={terms.p}>
            2. Mahali halisi sahihi sahihi (GPS) ya nyumba haionyeshwi hadharani — wapangaji wanaona eneo kwa
            ukaribu tu. Mwenye nyumba anaweza kutoa maelekezo kwa njia ya ujumbe.
          </Text>
          <Text style={terms.p}>
            3. Unaweza kufuta akaunti yako wakati wowote kwa kuwasiliana na support@kayaleo.app.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const terms = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    backgroundColor: colors.white,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  p: { color: colors.subtext, fontSize: 13.5, lineHeight: 21, marginTop: 10 },
});
