import React from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Avatar, Badge } from '../../components/ui';
import { colors, radius, spacing, styles as s, typography } from '../../theme';
import { useT } from '../../i18n';
import { useAuth } from '../../state/AuthContext';
import type { RootStackParamList } from '../../types/navigation';

type Nav = NativeStackNavigationProp<RootStackParamList>;

export default function ProfileScreen() {
  const nav = useNavigation<Nav>();
  const { t } = useT();
  const { profile, signOut } = useAuth();

  if (!profile) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }} edges={['top']}>
        <Text style={prof.title}>{t('tab_profile')}</Text>
        <EmptyProfile />
      </SafeAreaView>
    );
  }

  const menu: Array<{ icon: keyof typeof Ionicons.glyphMap; label: string; onPress: () => void }> = [
    { icon: 'person-circle', label: t('edit_profile'), onPress: () => nav.navigate('EditProfile') },
    { icon: 'document-text', label: t('my_inquiries'), onPress: () => nav.navigate('MyInquiries') },
    { icon: 'star-half', label: t('my_reviews'), onPress: () => nav.navigate('MyReviews') },
    { icon: 'settings', label: t('account_settings'), onPress: () => nav.navigate('Settings') },
    { icon: 'help-circle', label: t('help_support'), onPress: () => nav.navigate('HelpSupport') },
    { icon: 'shield-checkmark', label: t('terms_privacy'), onPress: () => nav.navigate('TermsPrivacy') },
  ];

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }} edges={['top']}>
      <ScrollView contentContainerStyle={{ paddingBottom: spacing.xxxl }}>
        {/* header card */}
        <View style={prof.headerCard}>
          <Avatar uri={profile.avatar_url} name={profile.full_name} size={78} />
          <Text style={prof.name}>{profile.full_name}</Text>
          <View style={[s.row, { gap: 6, marginTop: 2 }]}>
            {profile.is_verified ? <Badge text="✓ Thibitishwa" tone="success" /> : null}
            <Badge text={profile.role === 'HOST' ? 'Mwenye Nyumba' : profile.role === 'ADMIN' ? 'Admin' : 'Mwanachama'} tone="blue" />
          </View>
          <Text style={[typography.small, { marginTop: 8 }]}>{profile.email}</Text>
          {profile.phone ? <Text style={typography.small}>{profile.phone}</Text> : null}
          {profile.bio ? <Text style={[typography.small, { marginTop: 6, fontStyle: 'italic' }]}>"{profile.bio}"</Text> : null}
        </View>

        {/* HOST MODE */}
        <View style={{ paddingHorizontal: spacing.xl }}>
          {profile.is_host ? (
            <Pressable style={[s.card, prof.hostCard]} onPress={() => nav.navigate('HostDashboard')}>
              <View style={[s.row, { gap: 12, flex: 1 }]}>
                <View style={prof.hostIcon}>
                  <Ionicons name="business" size={22} color={colors.white} />
                </View>
                <View>
                  <Text style={{ fontWeight: '800', fontSize: 15, color: colors.navy }}>{t('host_dashboard')}</Text>
                  <Text style={typography.tiny}>Tangazo, maombi, ujumbe na takwimu</Text>
                </View>
              </View>
              <Ionicons name="chevron-forward" size={20} color={colors.royal} />
            </Pressable>
          ) : (
            <Pressable style={[s.card, prof.hostCard]} onPress={() => nav.navigate('HostOnboarding')}>
              <View style={[s.row, { gap: 12, flex: 1 }]}>
                <View style={prof.hostIcon}>
                  <Ionicons name="rocket" size={22} color={colors.white} />
                </View>
                <View>
                  <Text style={{ fontWeight: '800', fontSize: 15, color: colors.navy }}>{t('become_host')}</Text>
                  <Text style={typography.tiny}>{t('become_host_sub')}</Text>
                </View>
              </View>
              <Ionicons name="chevron-forward" size={20} color={colors.royal} />
            </Pressable>
          )}

          {profile.role === 'ADMIN' ? (
            <Pressable style={[s.card, prof.hostCard, { backgroundColor: '#101a3a', marginBottom: spacing.lg }]} onPress={() => nav.navigate('AdminDashboard')}>
              <View style={[s.row, { gap: 12, flex: 1 }]}>
                <View style={[prof.hostIcon, { backgroundColor: '#31437a' }]}>
                  <Ionicons name="shield" size={22} color={colors.white} />
                </View>
                <View>
                  <Text style={{ fontWeight: '800', fontSize: 15, color: colors.white }}>{t('admin_panel')}</Text>
                  <Text style={[typography.tiny, { color: '#9FB0D8' }]}>Uidhinishaji, watumiaji na ripoti</Text>
                </View>
              </View>
              <Ionicons name="chevron-forward" size={20} color="#9FB0D8" />
            </Pressable>
          ) : null}
        </View>

        {/* menu */}
        <View style={[s.card, { marginHorizontal: spacing.xl, paddingVertical: 4 }]}>
          {menu.map((item, idx) => (
            <Pressable
              key={item.label}
              onPress={item.onPress}
              style={[prof.menuRow, idx > 0 && { borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.border }]}
              android_ripple={{ color: colors.blue50 }}
            >
              <Ionicons name={item.icon} size={19} color={colors.blue} />
              <Text style={[prof.menuLabel]}>{item.label}</Text>
              <Ionicons name="chevron-forward" size={17} color={colors.muted} />
            </Pressable>
          ))}
        </View>

        {/* logout */}
        <Pressable
          style={[s.card, prof.logoutBtn]}
          onPress={() =>
            Alert.alert('Kaya Leo', t('confirm_logout'), [
              { text: t('cancel'), style: 'cancel' },
              { text: t('logout'), style: 'destructive', onPress: () => signOut() },
            ])
          }
        >
          <Ionicons name="log-out" size={19} color={colors.danger} />
          <Text style={{ color: colors.danger, fontWeight: '800', marginLeft: 10 }}>{t('logout')}</Text>
        </Pressable>

        <Text style={[typography.tiny, { textAlign: 'center', marginTop: spacing.lg }]}>
          Kaya Leo v1.0 · Nyumba za kupanga Tanzania
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

function EmptyProfile() {
  const { t } = useT();
  return (
    <View style={{ alignItems: 'center', paddingTop: 80, paddingHorizontal: spacing.xxl }}>
      <Ionicons name="person-circle-outline" size={80} color={colors.sky} />
      <Text style={[typography.h2, { marginTop: spacing.lg }]}>Ingia kwanza</Text>
      <Text style={[typography.small, { textAlign: 'center', marginTop: 6 }]}>
        Ingia kwenye akaunti yako kuona wasifu, uliyopendwa na ujumbe wako.
      </Text>
    </View>
  );
}

const prof = StyleSheet.create({
  title: { fontSize: 24, fontWeight: '900', color: colors.text, paddingHorizontal: spacing.xl, paddingTop: spacing.lg },
  headerCard: {
    backgroundColor: colors.white,
    alignItems: 'center',
    padding: spacing.xxl,
    paddingTop: spacing.xl,
    borderBottomLeftRadius: radius.xl,
    borderBottomRightRadius: radius.xl,
    marginBottom: spacing.xl,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  name: { fontSize: 20, fontWeight: '900', color: colors.text, marginTop: 10 },
  hostCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing.lg,
    marginBottom: spacing.lg,
    backgroundColor: '#EAF1FF',
    borderColor: '#C8DBFF',
  },
  hostIcon: {
    width: 44,
    height: 44,
    borderRadius: 13,
    backgroundColor: colors.royal,
    alignItems: 'center',
    justifyContent: 'center',
  },
  menuRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, paddingHorizontal: spacing.lg, gap: 12 },
  menuLabel: { flex: 1, fontSize: 14.5, fontWeight: '600', color: colors.text },
  logoutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: spacing.xl,
    marginTop: spacing.lg,
    padding: 15,
    borderColor: '#F6CFCF',
    backgroundColor: '#FDF3F3',
  },
});
