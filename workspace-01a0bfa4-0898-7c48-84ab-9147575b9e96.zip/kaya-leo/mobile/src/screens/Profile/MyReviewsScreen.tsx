import React from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useQuery } from '@tanstack/react-query';
import { EmptyState, ErrorState, RatingStars, Skeleton } from '../../components/ui';
import { colors, spacing, styles as s, typography } from '../../theme';
import { useT } from '../../i18n';
import { useAuth } from '../../state/AuthContext';
import { reviewsApi } from '../../api';
import type { RootStackParamList } from '../../types/navigation';
import { timeAgo } from '../../utils/format';

export default function MyReviewsScreen() {
  const nav = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { t } = useT();
  const { session } = useAuth();
  const query = useQuery({ queryKey: ['myReviews'], queryFn: reviewsApi.mine, enabled: Boolean(session) });

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }} edges={['top']}>
      <View style={rv.header}>
        <Pressable onPress={() => nav.goBack()} hitSlop={8}>
          <Ionicons name="arrow-back" size={23} color={colors.text} />
        </Pressable>
        <Text style={typography.title}>{t('my_reviews')}</Text>
        <View style={{ width: 23 }} />
      </View>
      {query.isLoading ? (
        <View style={{ padding: spacing.xl, gap: spacing.md }}>
          {[1, 2].map((i) => (
            <Skeleton key={i} width={'100%'} height={80} />
          ))}
        </View>
      ) : query.isError ? (
        <ErrorState message={t('load_failed')} onRetry={() => query.refetch()} />
      ) : !query.data?.items.length ? (
        <EmptyState icon="star-outline" title="Hakuna maoni yako bado" subtitle="Tembelea nyumba kisha andika maoni." />
      ) : (
        <FlatList
          data={query.data.items}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: spacing.xl }}
          renderItem={({ item }) => (
            <Pressable
              style={[s.card, { padding: spacing.md, marginBottom: spacing.md }]}
              onPress={() => nav.navigate('PropertyDetails', { propertyId: item.property_id })}
            >
              <View style={[s.row, { justifyContent: 'space-between' }]}>
                <RatingStars rating={item.rating} />
                <Text style={typography.tiny}>{timeAgo(item.created_at)}</Text>
              </View>
              <Text style={[typography.small, { marginTop: 6 }]}>{item.comment || '—'}</Text>
            </Pressable>
          )}
        />
      )}
    </SafeAreaView>
  );
}

const rv = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    backgroundColor: colors.white,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
});
