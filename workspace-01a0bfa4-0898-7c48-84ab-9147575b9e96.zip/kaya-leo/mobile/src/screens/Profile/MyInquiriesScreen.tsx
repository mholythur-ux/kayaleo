import React from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Badge, EmptyState, ErrorState, Skeleton } from '../../components/ui';
import { colors, radius, spacing, styles as s, typography } from '../../theme';
import { useT } from '../../i18n';
import { useMyInquiries } from '../../hooks/queries';
import { useAuth } from '../../state/AuthContext';
import type { RootStackParamList } from '../../types/navigation';
import { formatTZS, timeAgo } from '../../utils/format';

const placeholder = require('../../../assets/placeholder.jpg');

export default function MyInquiriesScreen() {
  const nav = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { t } = useT();
  const { session } = useAuth();
  const query = useMyInquiries(Boolean(session));

  const statusBadge = (status: string) =>
    status === 'new' ? <Badge text="Mpya" tone="blue" /> : status === 'contacted' ? <Badge text="Imejibiwa" tone="success" /> : <Badge text="Imefungwa" />;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }} edges={['top']}>
      <View style={inq.header}>
        <Pressable onPress={() => nav.goBack()} hitSlop={8}>
          <Ionicons name="arrow-back" size={23} color={colors.text} />
        </Pressable>
        <Text style={typography.title}>{t('my_inquiries')}</Text>
        <View style={{ width: 23 }} />
      </View>
      {query.isLoading ? (
        <View style={{ padding: spacing.xl, gap: spacing.md }}>
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} width={'100%'} height={84} />
          ))}
        </View>
      ) : query.isError ? (
        <ErrorState message={t('load_failed')} onRetry={() => query.refetch()} />
      ) : !query.data?.items.length ? (
        <EmptyState icon="document-text-outline" title="Hakuna maombi bado" subtitle="Tumia 'Omba kukodisha' kwenye tangazo lolote." />
      ) : (
        <FlatList
          data={query.data.items}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: spacing.xl }}
          renderItem={({ item }) => (
            <Pressable
              style={[s.card, inq.card]}
              onPress={() => item.property && nav.navigate('PropertyDetails', { propertyId: item.property.id })}
            >
              <Image source={item.property?.image_url ? { uri: item.property.image_url } : placeholder} style={inq.thumb} contentFit="cover" />
              <View style={{ flex: 1, marginLeft: spacing.md }}>
                <View style={[s.row, { justifyContent: 'space-between' }]}>
                  <Text style={{ fontWeight: '800', fontSize: 13.5, flexShrink: 1 }} numberOfLines={1}>
                    {item.property?.title || 'Nyumba'}
                  </Text>
                  {statusBadge(item.status)}
                </View>
                <Text style={[typography.small, { marginTop: 3 }]} numberOfLines={2}>
                  {item.message}
                </Text>
                <View style={[s.row, { justifyContent: 'space-between', marginTop: 4 }]}>
                  <Text style={typography.tiny}>{timeAgo(item.created_at)}</Text>
                  {item.property ? <Text style={{ color: colors.royal, fontWeight: '800', fontSize: 12 }}>{formatTZS(item.property.price_monthly)}</Text> : null}
                </View>
              </View>
            </Pressable>
          )}
        />
      )}
    </SafeAreaView>
  );
}

const inq = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    backgroundColor: colors.white,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  card: { flexDirection: 'row', padding: spacing.md, marginBottom: spacing.md },
  thumb: { width: 62, height: 62, borderRadius: radius.md },
});
