import React, { useState } from 'react';
import { Alert, Image, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import * as ImagePicker from 'expo-image-picker';
import { Avatar, Button, Input } from '../../components/ui';
import { colors, radius, spacing, typography } from '../../theme';
import { useT } from '../../i18n';
import { useAuth } from '../../state/AuthContext';
import { profileApi } from '../../api';
import { uploadToBucket } from '../../services/supabase';
import type { RootStackParamList } from '../../types/navigation';

export default function EditProfileScreen() {
  const nav = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { t } = useT();
  const { profile, refreshProfile } = useAuth();
  const [fullName, setFullName] = useState(profile?.full_name || '');
  const [phone, setPhone] = useState(profile?.phone || '');
  const [bio, setBio] = useState(profile?.bio || '');
  const [avatarUri, setAvatarUri] = useState<string | null>(profile?.avatar_url || null);
  const [pendingLocalUri, setPendingLocalUri] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const pickAvatar = async () => {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) {
      Alert.alert('Kaya Leo', 'Ruhusu kupata gallery kwanza.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.7,
    });
    if (!result.canceled && result.assets[0]) {
      setPendingLocalUri(result.assets[0].uri);
      setAvatarUri(result.assets[0].uri);
    }
  };

  const save = async () => {
    if (fullName.trim().length < 2) {
      Alert.alert('Kaya Leo', 'Jina kamili linahitajika.');
      return;
    }
    setSaving(true);
    try {
      let avatar_url = profile?.avatar_url || null;
      if (pendingLocalUri) {
        const up = await uploadToBucket('avatars', pendingLocalUri, 'avatar.jpg');
        avatar_url = up.url;
      }
      await profileApi.update({ full_name: fullName.trim(), phone: phone.trim(), bio: bio.trim(), avatar_url });
      await refreshProfile();
      Alert.alert('Kaya Leo', 'Wasifu umehifadhiwa.');
      nav.goBack();
    } catch (e) {
      Alert.alert('Kaya Leo', (e as Error).message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }} edges={['top']}>
      <ScrollView contentContainerStyle={{ padding: spacing.xl }}>
        <View style={ed.header}>
          <Pressable onPress={() => nav.goBack()} hitSlop={8}>
            <Ionicons name="arrow-back" size={23} color={colors.text} />
          </Pressable>
          <Text style={typography.title}>{t('edit_profile')}</Text>
          <View style={{ width: 23 }} />
        </View>

        <Pressable style={{ alignItems: 'center', marginVertical: spacing.xl }} onPress={pickAvatar}>
          {avatarUri && Image ? (
            <Image source={{ uri: avatarUri }} style={{ width: 96, height: 96, borderRadius: 48 }} />
          ) : (
            <Avatar name={fullName} size={96} />
          )}
          <View style={ed.cameraBadge}>
            <Ionicons name="camera" size={13} color={colors.white} />
          </View>
          <Text style={{ color: colors.royal, fontWeight: '700', marginTop: 8, fontSize: 13 }}>Badilisha picha</Text>
        </Pressable>

        <Input label={t('full_name')} value={fullName} onChangeText={setFullName} placeholder="Jina kamili" />
        <Input label={t('phone')} value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder="+255 7XX XXX XXX" />
        <Input label={t('description')} value={bio} onChangeText={setBio} placeholder="Maelezo mafupi kuhusu wewe..." multiline style={{ height: 90, textAlignVertical: 'top', paddingTop: 12 }} />

        <Button title={t('save')} icon="checkmark" onPress={save} loading={saving} style={{ marginTop: spacing.md }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const ed = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  cameraBadge: {
    position: 'absolute',
    right: '32%',
    top: 66,
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: colors.royal,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: colors.white,
  },
});
