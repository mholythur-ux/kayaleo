import React from 'react';
import { Linking, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { colors, spacing, styles as s, typography } from '../../theme';
import type { RootStackParamList } from '../../types/navigation';

export default function HelpSupportScreen() {
  const nav = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }} edges={['top']}>
      <View style={help.header}>
        <Pressable onPress={() => nav.goBack()} hitSlop={8}>
          <Ionicons name="arrow-back" size={23} color={colors.text} />
        </Pressable>
        <Text style={typography.title}>Msaada na Usaidizi</Text>
        <View style={{ width: 23 }} />
      </View>
      <View style={[s.card, { margin: spacing.xl, padding: spacing.xl }]}>
        <Text style={typography.h2}>Tunawakaribisha!</Text>
        <Text style={[typography.small, { marginTop: 8, lineHeight: 20 }]}>
          Kaya Leo ni soko la nyumba za kupanga Tanzania. Kwa maswali, malalamiko au mapendekezo, wasiliana nasi:
        </Text>
        <Pressable style={[help.row, { marginTop: spacing.lg }]} onPress={() => Linking.openURL('mailto:support@kayaleo.app')}>
          <Ionicons name="mail" size={18} color={colors.blue} />
          <Text style={help.rowText}>support@kayaleo.app</Text>
        </Pressable>
        <Pressable style={help.row} onPress={() => Linking.openURL('tel:+255700000000')}>
          <Ionicons name="call" size={18} color={colors.blue} />
          <Text style={help.rowText}>+255 700 000 000</Text>
        </Pressable>
        <Pressable style={help.row} onPress={() => Linking.openURL('https://www.kayaleo.app')}>
          <Ionicons name="globe" size={18} color={colors.blue} />
          <Text style={help.rowText}>www.kayaleo.app</Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

const help = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    backgroundColor: colors.white,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 10 },
  rowText: { color: colors.royal, fontWeight: '700', fontSize: 14 },
});
