import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Chip } from '../../components/ui';
import { colors, spacing, styles as s, typography } from '../../theme';
import { useT, type Lang } from '../../i18n';
import type { RootStackParamList } from '../../types/navigation';

export default function SettingsScreen() {
  const nav = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { t, lang, setLang } = useT();
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }} edges={['top']}>
      <View style={set.header}>
        <Pressable onPress={() => nav.goBack()} hitSlop={8}>
          <Ionicons name="arrow-back" size={23} color={colors.text} />
        </Pressable>
        <Text style={typography.title}>{t('account_settings')}</Text>
        <View style={{ width: 23 }} />
      </View>
      <View style={[s.card, { margin: spacing.xl, padding: spacing.xl }]}>
        <Text style={[typography.h2, { marginBottom: 4 }]}>{t('language')}</Text>
        <Text style={[typography.small, { marginBottom: spacing.md }]}>Chagua lugha ya programu.</Text>
        <View style={{ flexDirection: 'row', gap: spacing.sm }}>
          <Chip label="Kiswahili" active={lang === 'sw'} onPress={() => setLang('sw' as Lang)} icon="language" />
          <Chip label="English" active={lang === 'en'} onPress={() => setLang('en' as Lang)} icon="language" />
        </View>
      </View>
    </SafeAreaView>
  );
}

const set = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    backgroundColor: colors.white,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
});
