import React, { useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Controller, useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { supabase } from '../../services/supabase';
import { Button, Input } from '../../components/ui';
import { colors, spacing, typography } from '../../theme';
import { useT } from '../../i18n';
import type { RootStackParamList } from '../../types/navigation';

const schema = z.object({
  email: z.string().email('Barua pepe si sahihi'),
  password: z.string().min(1, 'Weka nenosiri'),
});
type FormData = z.infer<typeof schema>;

export default function LoginScreen() {
  const nav = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { t } = useT();
  const [busy, setBusy] = useState(false);
  const { control, handleSubmit, formState } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { email: '', password: '' },
  });

  const onSubmit = async (data: FormData) => {
    setBusy(true);
    try {
      const { error } = await supabase.auth.signInWithPassword({ email: data.email, password: data.password });
      if (error) {
        Alert.alert(
          'Kaya Leo',
          error.message === 'Invalid login credentials' ? 'Email au nenosiri si sahihi.' : error.message
        );
      }
    } catch (e) {
      Alert.alert('Kaya Leo', (e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: colors.bg }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={log.wrap} keyboardShouldPersistTaps="handled">
        <Pressable style={log.back} onPress={() => nav.goBack()}>
          <Text style={{ color: colors.royal, fontWeight: '700' }}>‹ {t('back')}</Text>
        </Pressable>
        <View style={log.logoRow}>
          <View style={log.badge}>
            <Text style={{ color: colors.white, fontWeight: '900' }}>KL</Text>
          </View>
          <Text style={log.logo}>Kaya <Text style={{ color: colors.bright }}>Leo</Text></Text>
        </View>
        <Text style={[typography.title, { fontSize: 26, marginBottom: 4 }]}>{t('login_title')}</Text>
        <Text style={[typography.small, { marginBottom: spacing.xl }]}>Karibu tena kwenye nyumba zako.</Text>

        <Controller
          control={control}
          name="email"
          render={({ field: { onChange, onBlur, value } }) => (
            <Input
              label={t('email')}
              placeholder="jina@barua.com"
              value={value}
              onChangeText={onChange}
              onBlur={onBlur}
              keyboardType="email-address"
              autoCapitalize="none"
              error={formState.errors.email?.message}
            />
          )}
        />
        <Controller
          control={control}
          name="password"
          render={({ field: { onChange, onBlur, value } }) => (
            <Input
              label={t('password')}
              placeholder="••••••••"
              value={value}
              onChangeText={onChange}
              onBlur={onBlur}
              secureTextEntry
              error={formState.errors.password?.message}
            />
          )}
        />

        <Button title={t('login')} onPress={handleSubmit(onSubmit)} loading={busy} style={{ marginTop: spacing.sm }} />
        <View style={[log.row, { marginTop: spacing.xl }]}>
          <Text style={typography.small}>{t('no_account')} </Text>
          <Pressable onPress={() => nav.navigate('SignUp')}>
            <Text style={{ color: colors.royal, fontWeight: '800' }}>{t('signup')}</Text>
          </Pressable>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const log = StyleSheet.create({
  wrap: { padding: spacing.xl, paddingTop: 70, flexGrow: 1 },
  back: { position: 'absolute', top: 62, left: spacing.xl },
  logoRow: { flexDirection: 'row', alignItems: 'center', marginBottom: spacing.xl },
  badge: { width: 36, height: 36, borderRadius: 11, backgroundColor: colors.royal, alignItems: 'center', justifyContent: 'center', marginRight: 9 },
  logo: { fontSize: 20, fontWeight: '900', color: colors.navy },
  row: { flexDirection: 'row', justifyContent: 'center' },
});
