import React, { useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Controller, useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { supabase } from '../../services/supabase';
import { Button, Input } from '../../components/ui';
import { colors, spacing, typography } from '../../theme';
import { useT } from '../../i18n';
import type { RootStackParamList } from '../../types/navigation';

const schema = z.object({
  full_name: z.string().min(2, 'Jina kamili linahitajika'),
  phone: z.string().min(7, 'Namba ya simu si sahihi').max(20),
  email: z.string().email('Barua pepe si sahihi'),
  password: z.string().min(8, 'Nenosiri linahitaji herufi 8 au zaidi'),
});
type FormData = z.infer<typeof schema>;

export default function SignUpScreen() {
  const nav = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { t } = useT();
  const [busy, setBusy] = useState(false);
  const { control, handleSubmit, formState } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { full_name: '', phone: '', email: '', password: '' },
  });

  const onSubmit = async (data: FormData) => {
    setBusy(true);
    try {
      // Creates the auth user; a database trigger auto-creates the profile
      // from full_name/phone metadata (database/migrations/001_init.sql).
      const { data: result, error } = await supabase.auth.signUp({
        email: data.email,
        password: data.password,
        options: { data: { full_name: data.full_name, phone: data.phone } },
      });
      if (error) {
        Alert.alert('Kaya Leo', error.message);
      } else if (!result.session) {
        Alert.alert('Kaya Leo', 'Akaunti imeundwa! Thibitisha barua pepe yako kisha ingia.');
        nav.navigate('Login');
      }
      // With email confirmation disabled, the session starts immediately
      // and RootNavigator switches to MainTabs automatically.
    } catch (e) {
      Alert.alert('Kaya Leo', (e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: colors.bg }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={su.wrap} keyboardShouldPersistTaps="handled">
        <Pressable style={su.back} onPress={() => nav.goBack()}>
          <Text style={{ color: colors.royal, fontWeight: '700' }}>‹ {t('back')}</Text>
        </Pressable>
        <Text style={[typography.title, { fontSize: 26, marginBottom: 4 }]}>{t('signup_title')}</Text>
        <Text style={[typography.small, { marginBottom: spacing.xl }]}>
          Fungua akaunti bila malipo — pata nyumba au tangaza yako.
        </Text>

        <Controller
          control={control}
          name="full_name"
          render={({ field: { onChange, onBlur, value } }) => (
            <Input
              label={t('full_name')}
              placeholder="Mfano: Amina Hassan"
              value={value}
              onChangeText={onChange}
              onBlur={onBlur}
              error={formState.errors.full_name?.message}
            />
          )}
        />
        <Controller
          control={control}
          name="phone"
          render={({ field: { onChange, onBlur, value } }) => (
            <Input
              label={t('phone')}
              placeholder="+255 7XX XXX XXX"
              value={value}
              onChangeText={onChange}
              onBlur={onBlur}
              keyboardType="phone-pad"
              error={formState.errors.phone?.message}
            />
          )}
        />
        <Controller
          control={control}
          name="email"
          render={({ field: { onChange, onBlur, value } }) => (
            <Input
              label={t('email')}
              placeholder="jina@barua.com"
              value={value}
              onChangeText={onChange}
              onBlur={onBlur}
              keyboardType="email-address"
              autoCapitalize="none"
              error={formState.errors.email?.message}
            />
          )}
        />
        <Controller
          control={control}
          name="password"
          render={({ field: { onChange, onBlur, value } }) => (
            <Input
              label={t('password')}
              placeholder="Herufi 8 au zaidi"
              value={value}
              onChangeText={onChange}
              onBlur={onBlur}
              secureTextEntry
              error={formState.errors.password?.message}
            />
          )}
        />

        <Button title={t('signup')} onPress={handleSubmit(onSubmit)} loading={busy} style={{ marginTop: spacing.sm }} />
        <View style={[su.row, { marginTop: spacing.xl }]}>
          <Text style={typography.small}>{t('has_account')} </Text>
          <Pressable onPress={() => nav.navigate('Login')}>
            <Text style={{ color: colors.royal, fontWeight: '800' }}>{t('login')}</Text>
          </Pressable>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const su = StyleSheet.create({
  wrap: { padding: spacing.xl, paddingTop: 70, flexGrow: 1 },
  back: { position: 'absolute', top: 62, left: spacing.xl },
  row: { flexDirection: 'row', justifyContent: 'center' },
});
