import React from 'react';
import { ImageBackground, Pressable, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Button } from '../../components/ui';
import { colors, spacing, typography } from '../../theme';
import { useT } from '../../i18n';
import type { RootStackParamList } from '../../types/navigation';

const hero = require('../../../assets/hero-fallback.jpg');

export default function WelcomeScreen() {
  const nav = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { t } = useT();
  return (
    <View style={wel.wrap}>
      <ImageBackground source={hero} style={StyleSheet.absoluteFill} resizeMode="cover" />
      <LinearGradient colors={['rgba(10,42,94,0.35)', 'rgba(10,42,94,0.88)', '#0A2A5E']} style={StyleSheet.absoluteFill} />
      <View style={wel.logoRow}>
        <View style={wel.logoBadge}>
          <Text style={{ color: colors.white, fontWeight: '900', fontSize: 18 }}>KL</Text>
        </View>
        <View>
          <Text style={wel.logo}>Kaya <Text style={{ color: colors.sky }}>Leo</Text></Text>
          <Text style={wel.tagline}>{t('app_tagline')}</Text>
        </View>
      </View>
      <View style={{ flex: 1 }} />
      <Text style={[typography.hero, { marginBottom: spacing.sm }]}>{t('home_hero_title')}</Text>
      <Text style={wel.sub}>{t('welcome_sub')}</Text>
      <View style={{ marginTop: spacing.xxl, gap: spacing.md }}>
        <Button title={t('get_started')} icon="arrow-forward" onPress={() => nav.navigate('SignUp')} />
        <Button title={t('have_account')} variant="ghost" onPress={() => nav.navigate('Login')} />
      </View>
    </View>
  );
}

const wel = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: colors.navy, padding: spacing.xl, justifyContent: 'flex-end', paddingBottom: 48 },
  logoRow: { position: 'absolute', top: 74, left: spacing.xl, flexDirection: 'row', alignItems: 'center' },
  logoBadge: {
    width: 42,
    height: 42,
    borderRadius: 13,
    backgroundColor: colors.royal,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  logo: { color: colors.white, fontSize: 22, fontWeight: '900' },
  tagline: { color: colors.sky, fontSize: 12, fontWeight: '600' },
  sub: { color: '#C9DCF9', fontSize: 15, lineHeight: 22 },
});
