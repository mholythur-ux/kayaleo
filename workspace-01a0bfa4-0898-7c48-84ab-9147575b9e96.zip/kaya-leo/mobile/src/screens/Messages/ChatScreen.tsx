import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { useNavigation, useRoute } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RouteProp } from '@react-navigation/native';
import { ErrorState } from '../../components/ui';
import { colors, radius, spacing, styles as s, typography } from '../../theme';
import { useT } from '../../i18n';
import { useAuth } from '../../state/AuthContext';
import { useConversations, useMessages, useSendMessage } from '../../hooks/queries';
import type { RootStackParamList } from '../../types/navigation';
import { formatTZS, messageTime } from '../../utils/format';

const placeholder = require('../../../assets/placeholder.jpg');

export default function ChatScreen() {
  const route = useRoute<RouteProp<RootStackParamList, 'Chat'>>();
  const nav = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { conversationId } = route.params;
  const { t } = useT();
  const { session, profile } = useAuth();
  const query = useMessages(conversationId);
  const convQuery = useConversations(Boolean(session));
  const sendMutation = useSendMessage(conversationId);
  const [draft, setDraft] = useState('');
  const listRef = useRef<FlatList>(null);

  const conversation = convQuery.data?.items.find((c) => c.id === conversationId);
  const messages = query.data?.messages || [];
  const property = query.data?.property || conversation?.property;

  useEffect(() => {
    if (messages.length) {
      setTimeout(() => listRef.current?.scrollToEnd({ animated: false }), 120);
    }
  }, [messages.length]);

  const send = () => {
    const text = draft.trim();
    if (!text) return;
    setDraft('');
    sendMutation.mutate(text, {
      onError: () => {
        setDraft(text);
      },
    });
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.white }} edges={['top']}>
      {/* header with property reference */}
      <View style={chat.header}>
        <Pressable onPress={() => nav.goBack()} hitSlop={8}>
          <Ionicons name="arrow-back" size={23} color={colors.text} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={{ fontWeight: '800', fontSize: 15, color: colors.text }} numberOfLines={1}>
            {conversation?.other_participant?.full_name || 'Mazungumzo'}
          </Text>
          {property ? (
            <Pressable
              style={[s.row, { marginTop: 2 }]}
              onPress={() => nav.navigate('PropertyDetails', { propertyId: property.id })}
            >
              <Image
                source={property.image_url ? { uri: property.image_url } : placeholder}
                style={{ width: 22, height: 22, borderRadius: 6 }}
                contentFit="cover"
              />
              <Text
                style={{ marginLeft: 6, fontSize: 12, color: colors.royal, fontWeight: '700', flexShrink: 1 }}
                numberOfLines={1}
              >
                {property.title} · {formatTZS(property.price_monthly)}
              </Text>
            </Pressable>
          ) : null}
        </View>
      </View>

      {query.isLoading ? (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <ActivityIndicator color={colors.blue} />
        </View>
      ) : query.isError ? (
        <ErrorState message={t('load_failed')} onRetry={() => query.refetch()} />
      ) : (
        <KeyboardAvoidingView
          style={{ flex: 1, backgroundColor: colors.white }}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
          <FlatList
            ref={listRef}
            data={messages}
            keyExtractor={(m) => m.id}
            contentContainerStyle={{ padding: spacing.xl, paddingBottom: spacing.md }}
            ListEmptyComponent={
              <Text style={[typography.small, { textAlign: 'center', marginTop: 40 }]}>
                Anza mazungumzo — uliza bei, upatikanaji au tembelea nyumba.
              </Text>
            }
            renderItem={({ item }) => {
              const mine = item.sender_id === profile?.id;
              return (
                <View style={[chat.bubbleRow, { justifyContent: mine ? 'flex-end' : 'flex-start' }]}>
                  <View style={[chat.bubble, mine ? chat.bubbleMine : chat.bubbleTheirs]}>
                    <Text style={[chat.bubbleText, mine && { color: colors.white }]}>{item.message}</Text>
                    <Text style={[chat.time, mine && { color: '#CBD9F5' }]}>
                      {messageTime(item.created_at)}
                      {mine ? (item.read_at ? ' · ✓✓' : ' · ✓') : ''}
                    </Text>
                  </View>
                </View>
              );
            }}
          />

          {/* input */}
          <View style={[chat.inputBar, { paddingBottom: Platform.OS === 'ios' ? 24 : 12 }]}>
            <TextInput
              value={draft}
              onChangeText={setDraft}
              placeholder={t('type_message')}
              placeholderTextColor={colors.muted}
              style={chat.input}
              multiline
            />
            <Pressable
              style={[chat.sendBtn, !draft.trim() && { opacity: 0.5 }]}
              onPress={send}
              disabled={!draft.trim() || sendMutation.isPending}
            >
              {sendMutation.isPending ? (
                <ActivityIndicator size="small" color={colors.white} />
              ) : (
                <Ionicons name="send" size={18} color={colors.white} />
              )}
            </Pressable>
          </View>
        </KeyboardAvoidingView>
      )}
    </SafeAreaView>
  );
}

const chat = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
    backgroundColor: colors.white,
  },
  bubbleRow: { flexDirection: 'row', marginBottom: 10 },
  bubble: { maxWidth: '80%', borderRadius: 18, paddingHorizontal: 14, paddingVertical: 9 },
  bubbleMine: { backgroundColor: colors.royal, borderBottomRightRadius: 6 },
  bubbleTheirs: { backgroundColor: colors.blue50, borderBottomLeftRadius: 6, borderWidth: 1, borderColor: colors.border },
  bubbleText: { fontSize: 14.5, color: colors.text, lineHeight: 20 },
  time: { fontSize: 10, color: colors.muted, marginTop: 3, alignSelf: 'flex-end' },
  inputBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: spacing.lg,
    paddingTop: 10,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.border,
    backgroundColor: colors.white,
  },
  input: {
    flex: 1,
    backgroundColor: colors.blue50,
    borderRadius: radius.pill,
    borderWidth: 1.4,
    borderColor: colors.border,
    paddingHorizontal: 16,
    paddingTop: 11,
    paddingBottom: 11,
    fontSize: 14.5,
    color: colors.text,
    maxHeight: 110,
  },
  sendBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: colors.royal, alignItems: 'center', justifyContent: 'center' },
});
