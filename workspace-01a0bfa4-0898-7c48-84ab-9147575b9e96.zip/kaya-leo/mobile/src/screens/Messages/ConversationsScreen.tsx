import React from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Image } from 'expo-image';
import { Avatar, EmptyState, ErrorState, Skeleton } from '../../components/ui';
import { colors, radius, spacing, styles as s, typography } from '../../theme';
import { useT } from '../../i18n';
import { useConversations } from '../../hooks/queries';
import { useAuth } from '../../state/AuthContext';
import type { RootStackParamList } from '../../types/navigation';
import { formatTZS, timeAgo } from '../../utils/format';

const placeholder = require('../../../assets/placeholder.jpg');

export default function ConversationsScreen() {
  const nav = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { t } = useT();
  const { session } = useAuth();
  const query = useConversations(Boolean(session));

  if (!session) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }} edges={['top']}>
        <Text style={list.title}>{t('tab_messages')}</Text>
        <EmptyState icon="chatbubbles-outline" title={t('empty_messages')} subtitle="Ingia kuona mazungumzo yako." />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }} edges={['top']}>
      <Text style={list.title}>{t('tab_messages')}</Text>
      {query.isLoading ? (
        <View style={{ padding: spacing.xl, gap: spacing.md }}>
          {[1, 2, 3].map((i) => (
            <View key={i} style={[s.card, { padding: spacing.md, flexDirection: 'row', alignItems: 'center', gap: spacing.md }]}>
              <Skeleton width={48} height={48} circle />
              <View style={{ flex: 1, gap: 7 }}>
                <Skeleton width={'55%'} height={13} />
                <Skeleton width={'80%'} height={11} />
              </View>
            </View>
          ))}
        </View>
      ) : query.isError ? (
        <ErrorState message={t('load_failed')} onRetry={() => query.refetch()} />
      ) : !query.data?.items.length ? (
        <EmptyState icon="chatbubbles-outline" title={t('empty_messages')} subtitle={t('empty_messages_hint')} />
      ) : (
        <FlatList
          data={query.data.items}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ paddingHorizontal: spacing.xl, paddingBottom: spacing.xxl }}
          renderItem={({ item }) => (
            <Pressable
              style={[s.card, list.row, item.unread_count > 0 && { borderColor: colors.blue, borderWidth: 1.4 }]}
              onPress={() => nav.navigate('Chat', { conversationId: item.id })}
              android_ripple={{ color: colors.blue50 }}
            >
              {item.property?.image_url ? (
                <Image source={{ uri: item.property.image_url }} style={list.thumb} contentFit="cover" transition={200} />
              ) : (
                <Image source={placeholder} style={list.thumb} contentFit="cover" />
              )}
              <View style={{ flex: 1, marginLeft: spacing.md }}>
                <View style={[s.row, { justifyContent: 'space-between' }]}>
                  <Text style={[{ fontWeight: '800', fontSize: 14, color: colors.text, flexShrink: 1 }]} numberOfLines={1}>
                    {item.other_participant?.full_name || 'Mwenye nyumba'}
                  </Text>
                  <Text style={typography.tiny}>{item.last_message ? '' : ''}{timeAgo(item.updated_at)}</Text>
                </View>
                <Text style={[typography.tiny, { marginTop: 1 }]} numberOfLines={1}>
                  {item.property ? `${item.property.title} · ${formatTZS(item.property.price_monthly)}` : ''}
                </Text>
                <Text style={[list.lastMsg, item.unread_count > 0 && { color: colors.text, fontWeight: '700' }]} numberOfLines={1}>
                  {item.last_message || 'Anza mazungumzo...'}
                </Text>
              </View>
              {item.unread_count > 0 ? (
                <View style={list.unread}>
                  <Text style={{ color: colors.white, fontSize: 10, fontWeight: '800' }}>{item.unread_count}</Text>
                </View>
              ) : null}
            </Pressable>
          )}
        />
      )}
    </SafeAreaView>
  );
}

const list = StyleSheet.create({
  title: { fontSize: 24, fontWeight: '900', color: colors.text, paddingHorizontal: spacing.xl, paddingTop: spacing.lg, paddingBottom: spacing.lg },
  row: { flexDirection: 'row', alignItems: 'center', padding: spacing.md, marginBottom: spacing.md },
  thumb: { width: 48, height: 48, borderRadius: radius.md },
  lastMsg: { fontSize: 13, color: colors.subtext, marginTop: 3 },
  unread: {
    marginLeft: 8,
    minWidth: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: colors.royal,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 6,
  },
});
