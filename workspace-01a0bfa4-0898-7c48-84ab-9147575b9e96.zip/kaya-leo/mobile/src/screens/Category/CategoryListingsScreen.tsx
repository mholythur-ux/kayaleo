import React, { useMemo } from 'react';
import { FlatList, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Pressable } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RouteProp } from '@react-navigation/native';
import { PropertyRowCard } from '../../components/PropertyCard';
import { EmptyState, ErrorState, Skeleton } from '../../components/ui';
import { colors, spacing, styles as s, typography } from '../../theme';
import { useT } from '../../i18n';
import { useFavoriteIds, useFeatured, useRecommendations, useSearchResults, useToggleFavorite } from '../../hooks/queries';
import { useAuth } from '../../state/AuthContext';
import type { RootStackParamList } from '../../types/navigation';

/**
 * Generic listing screen used by:
 *  - the three category cards (Ghorofa / Nyumba / Chumba)
 *  - "Tazama zote" on Featured Houses / Mapendekezo kwako
 * Real data comes from the API with the right filters/sort.
 */
export default function CategoryListingsScreen() {
  const nav = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const route = useRoute<RouteProp<RootStackParamList, 'CategoryListings'>>();
  const { mode, propertyType, title } = route.params;
  const { t } = useT();
  const { session } = useAuth();
  const favIds = useFavoriteIds(session);
  const toggleFavorite = useToggleFavorite();

  const filters = useMemo(
    () =>
      mode === 'type'
        ? { property_type: propertyType, sort: 'recommended' as const, page_size: 10 }
        : mode === 'featured'
        ? { sort: 'recommended' as const, page_size: 10 }
        : { sort: 'newest' as const, page_size: 10 },
    [mode, propertyType]
  );

  const query = useSearchResults(filters);

  const items = query.data?.pages.flatMap((p) => p.items) || [];
  const isFav = (id: string) => favIds.data?.ids.includes(id) ?? false;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }} edges={['top']}>
      <View style={cat.header}>
        <Pressable onPress={() => nav.goBack()} hitSlop={10}>
          <Ionicons name="arrow-back" size={23} color={colors.text} />
        </Pressable>
        <Text style={typography.title}>{title}</Text>
        <View style={{ width: 23 }} />
      </View>

      {query.isLoading ? (
        <View style={{ padding: spacing.xl, gap: spacing.md }}>
          {[1, 2, 3, 4].map((i) => (
            <View key={i} style={[s.card, { padding: spacing.md, flexDirection: 'row', gap: spacing.md }]}>
              <Skeleton width={100} height={90} />
              <View style={{ flex: 1, gap: 8, paddingTop: 4 }}>
                <Skeleton width={'70%'} height={14} />
                <Skeleton width={'50%'} height={11} />
                <Skeleton width={'40%'} height={14} />
              </View>
            </View>
          ))}
        </View>
      ) : query.isError ? (
        <ErrorState message={t('load_failed')} onRetry={() => query.refetch()} />
      ) : items.length === 0 ? (
        <EmptyState icon="home-outline" title={t('empty_generic')} />
      ) : (
        <FlatList
          data={items}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ paddingHorizontal: spacing.xl, paddingBottom: spacing.xxl }}
          renderItem={({ item }) => (
            <PropertyRowCard
              property={{ ...item, is_favorite: isFav(item.id) }}
              onPress={() => nav.navigate('PropertyDetails', { propertyId: item.id })}
              onToggleFavorite={() => toggleFavorite.mutate({ propertyId: item.id, favorited: isFav(item.id) })}
            />
          )}
          onEndReachedThreshold={0.4}
          onEndReached={() => {
            if (query.hasNextPage && !query.isFetchingNextPage) query.fetchNextPage();
          }}
        />
      )}
    </SafeAreaView>
  );
}

const cat = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    backgroundColor: colors.white,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
});
