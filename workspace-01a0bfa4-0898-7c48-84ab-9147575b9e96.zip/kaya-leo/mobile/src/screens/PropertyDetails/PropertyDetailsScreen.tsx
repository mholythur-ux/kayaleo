import React, { useEffect, useState } from 'react';
import {
  Alert,
  Dimensions,
  Linking,
  Platform,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import MapView, { Marker, PROVIDER_DEFAULT } from 'react-native-maps';
import { useNavigation, useRoute } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RouteProp } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import { ImageGallery } from '../../components/ImageGallery';
import { HostCard } from '../../components/HostCard';
import { InquiryModal, ReportModal } from '../../components/Modals';
import { Avatar, Badge, Button, ErrorState, RatingStars, Skeleton } from '../../components/ui';
import { colors, radius, spacing, styles as s, typography } from '../../theme';
import { useT } from '../../i18n';
import { conversationsApi, inquiriesApi, registerView, reportsApi } from '../../api';
import { useAddReview, useProperty, useReviews, useToggleFavorite } from '../../hooks/queries';
import { useAuth } from '../../state/AuthContext';
import { PROPERTY_TYPE_LABELS } from '../../types/models';
import type { RootStackParamList } from '../../types/navigation';
import { formatTZS, locationLine, timeAgo } from '../../utils/format';

const { width: SCREEN_W } = Dimensions.get('window');

export default function PropertyDetailsScreen() {
  const route = useRoute<RouteProp<RootStackParamList, 'PropertyDetails'>>();
  const nav = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { propertyId } = route.params;
  const { t, lang } = useT();
  const { profile, session } = useAuth();
  const { data, isLoading, isError, refetch } = useProperty(propertyId);
  const property = data?.property;
  const reviewsQuery = useReviews(propertyId);
  const toggleFavorite = useToggleFavorite();

  const [reportOpen, setReportOpen] = useState(false);
  const [inquiryOpen, setInquiryOpen] = useState(false);
  const [startingChat, setStartingChat] = useState(false);
  const [sendingInquiry, setSendingInquiry] = useState(false);
  const [sendingReport, setSendingReport] = useState(false);
  const [reviewRating, setReviewRating] = useState(0);
  const [reviewText, setReviewText] = useState('');
  const addReview = useAddReview(propertyId);

  // count a view once per mount (server-side counter)
  useEffect(() => {
    registerView(propertyId);
  }, [propertyId]);

  if (isLoading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.bg, paddingTop: 60 }}>
        <Skeleton width={SCREEN_W} height={260} style={{ borderRadius: 0 }} />
        <View style={{ padding: spacing.xl, gap: 10 }}>
          <Skeleton width={'65%'} height={20} />
          <Skeleton width={'45%'} height={14} />
          <Skeleton width={'100%'} height={90} />
        </View>
      </View>
    );
  }
  if (isError || !property) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.bg, paddingTop: 80 }}>
        <ErrorState message={t('load_failed')} onRetry={() => refetch()} />
      </View>
    );
  }

  const isFav = Boolean(property.is_favorite);
  const isOwner = profile?.id === property.host_id;
  const photos = property.images.map((i) => i.image_url);
  const typeLabel = PROPERTY_TYPE_LABELS[property.property_type][lang];

  const onToggleFavorite = () => {
    if (!session) {
      Alert.alert('Kaya Leo', 'Ingia kwanza kuhifadhi nyumba.');
      return;
    }
    toggleFavorite.mutate({ propertyId, favorited: isFav });
  };

  const onShare = async () => {
    try {
      await Share.share({
        message: `${property.title} — ${formatTZS(property.price_monthly)}/mwezi\n${locationLine(property)}\nAngalia Kaya Leo app!`,
      });
    } catch {
      /* user cancelled */
    }
  };

  const onCall = () => {
    const phone = property.host?.phone?.replace(/\s/g, '');
    if (!phone) {
      Alert.alert('Kaya Leo', 'Namba ya simu ya mwenye nyumba haipatikani.');
      return;
    }
    Linking.openURL(`tel:${phone}`).catch(() => Alert.alert('Kaya Leo', 'Imeshindikana kufungua simu.'));
  };

  const onMessage = async () => {
    if (!session) {
      Alert.alert('Kaya Leo', 'Ingia kwanza kuwasiliana na mwenye nyumba.');
      return;
    }
    setStartingChat(true);
    try {
      const { conversation_id } = await conversationsApi.start(property.id);
      nav.navigate('Chat', { conversationId: conversation_id });
    } catch (e) {
      Alert.alert('Kaya Leo', (e as Error).message);
    } finally {
      setStartingChat(false);
    }
  };

  const onInquiry = async (message: string) => {
    setSendingInquiry(true);
    try {
      await inquiriesApi.create(property.id, message);
      setInquiryOpen(false);
      Alert.alert('Kaya Leo', t('inquiry_sent'));
    } catch (e) {
      Alert.alert('Kaya Leo', (e as Error).message);
    } finally {
      setSendingInquiry(false);
    }
  };

  const onReport = async (reason: string, details: string) => {
    if (!session) {
      Alert.alert('Kaya Leo', 'Ingia kwanza kuripoti.');
      return;
    }
    setSendingReport(true);
    try {
      await reportsApi.create(property.id, reason, details);
      setReportOpen(false);
      Alert.alert('Kaya Leo', t('report_sent'));
    } catch (e) {
      Alert.alert('Kaya Leo', (e as Error).message);
    } finally {
      setSendingReport(false);
    }
  };

  const submitReview = async () => {
    if (!session) {
      Alert.alert('Kaya Leo', 'Ingia kwanza kuandika maoni.');
      return;
    }
    if (!reviewRating) {
      Alert.alert('Kaya Leo', 'Chagua nyota 1–5.');
      return;
    }
    try {
      await addReview.mutateAsync({ rating: reviewRating, comment: reviewText.trim() });
      setReviewRating(0);
      setReviewText('');
      Alert.alert('Kaya Leo', t('review_sent'));
    } catch (e) {
      Alert.alert('Kaya Leo', (e as Error).message);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 130 }}>
        {/* ---------- Gallery + floating actions ---------- */}
        <View>
          <ImageGallery uris={photos} />
          <LinearGradient colors={['rgba(10,42,94,0.55)', 'transparent']} style={det.topGrad} />
          <View style={det.topBar}>
            <Pressable style={det.circleBtn} onPress={() => nav.goBack()} hitSlop={8}>
              <Ionicons name="arrow-back" size={20} color={colors.white} />
            </Pressable>
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <Pressable style={det.circleBtn} onPress={onShare} hitSlop={8}>
                <Ionicons name="share-social" size={19} color={colors.white} />
              </Pressable>
              <Pressable style={det.circleBtn} onPress={onToggleFavorite} hitSlop={8}>
                <Ionicons name={isFav ? 'heart' : 'heart-outline'} size={20} color={isFav ? colors.heart : colors.white} />
              </Pressable>
            </View>
          </View>
          {property.is_featured ? (
            <View style={det.popularBadge}>
              <Badge text={t('popular')} tone="blue" />
            </View>
          ) : null}
        </View>

        {/* ---------- Title block ---------- */}
        <View style={{ paddingHorizontal: spacing.xl, paddingTop: spacing.lg }}>
          <View style={[s.row, { justifyContent: 'space-between' }]}>
            <Text style={[typography.title, { flexShrink: 1 }]}>{property.title}</Text>
            <Badge text={typeLabel} tone="blue" />
          </View>
          <View style={[s.row, { gap: 4, marginTop: 6 }]}>
            <Ionicons name="location-sharp" size={14} color={colors.blue} />
            <Text style={typography.small}>{locationLine(property)}</Text>
          </View>
          <View style={[s.row, { gap: 14, marginTop: 10 }]}>
            <View style={[s.row, { gap: 5 }]}>
              <Ionicons name="bed-outline" size={15} color={colors.subtext} />
              <Text style={typography.small}>{property.bedrooms} {t('bedrooms')}</Text>
            </View>
            <View style={[s.row, { gap: 5 }]}>
              <Ionicons name="water-outline" size={15} color={colors.subtext} />
              <Text style={typography.small}>{property.bathrooms} {t('bathrooms')}</Text>
            </View>
            {property.size_m2 ? (
              <View style={[s.row, { gap: 5 }]}>
                <Ionicons name="resize-outline" size={14} color={colors.subtext} />
                <Text style={typography.small}>{property.size_m2} m²</Text>
              </View>
            ) : null}
            <View style={[s.row, { gap: 5 }]}>
              <Ionicons name="eye-outline" size={15} color={colors.subtext} />
              <Text style={typography.small}>{property.views_count}</Text>
            </View>
          </View>
          <Text style={{ color: colors.royal, fontWeight: '900', fontSize: 19, marginTop: 10 }}>
            {formatTZS(property.price_monthly)}
            <Text style={{ color: colors.subtext, fontWeight: '700', fontSize: 13 }}> / mwezi</Text>
          </Text>

          {/* availability */}
          <View style={[s.row, { marginTop: 10, gap: 6 }]}>
            <Ionicons
              name={property.is_available_now ? 'checkmark-circle' : 'time-outline'}
              size={15}
              color={property.is_available_now ? colors.success : colors.warning}
            />
            <Text style={[typography.small, { fontWeight: '700' }]}>
              {property.is_available_now
                ? t('available_now')
                : `${t('available_from')} ${property.availability_date || ''}`}
            </Text>
          </View>
          {property.furnished || property.max_occupants || property.floor_number != null ? (
            <View style={[s.row, { marginTop: 8, gap: 12 }]}>
              {property.furnished ? (
                <View style={[s.row, { gap: 5 }]}>
                  <Ionicons name="bed-outline" size={15} color={colors.blue} />
                  <Text style={typography.small}>{t('furnished')}</Text>
                </View>
              ) : null}
              {property.floor_number != null ? (
                <Text style={typography.small}>{t('floor')}: {property.floor_number}</Text>
              ) : null}
              {property.max_occupants ? (
                <Text style={typography.small}>{t('occupants')}: {property.max_occupants}</Text>
              ) : null}
            </View>
          ) : null}
        </View>

        {/* ---------- Description ---------- */}
        {property.description ? (
          <View style={det.section}>
            <Text style={det.sectionTitle}>{t('description')}</Text>
            <Text style={[typography.body, { lineHeight: 23 }]}>{property.description}</Text>
          </View>
        ) : null}

        {/* ---------- Amenities ---------- */}
        {property.amenities.length ? (
          <View style={det.section}>
            <Text style={det.sectionTitle}>{t('amenities')}</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
              {property.amenities.map((a) => (
                <View key={a} style={det.amenityChip}>
                  <Ionicons name="checkmark-circle" size={14} color={colors.blue} />
                  <Text style={{ marginLeft: 5, fontSize: 13, color: colors.text }}>{a}</Text>
                </View>
              ))}
            </View>
          </View>
        ) : null}

        {/* ---------- House rules ---------- */}
        {property.house_rules ? (
          <View style={det.section}>
            <Text style={det.sectionTitle}>{t('house_rules')}</Text>
            <Text style={[typography.body, { lineHeight: 23 }]}>{property.house_rules}</Text>
          </View>
        ) : null}

        {/* ---------- Location (approximate pin for privacy) ---------- */}
        {property.latitude != null && property.longitude != null ? (
          <View style={det.section}>
            <Text style={det.sectionTitle}>{t('location_section')}</Text>
            <View style={{ borderRadius: radius.lg, overflow: 'hidden', height: 160 }}>
              <MapView
                style={{ flex: 1 }}
                provider={PROVIDER_DEFAULT}
                scrollEnabled={false}
                zoomEnabled={false}
                initialRegion={{
                  latitude: property.latitude,
                  longitude: property.longitude,
                  latitudeDelta: 0.01,
                  longitudeDelta: 0.01,
                }}
              >
                <Marker coordinate={{ latitude: property.latitude, longitude: property.longitude }} />
              </MapView>
            </View>
            <Text style={[typography.tiny, { marginTop: 6 }]}>Eneo linaonyeshwa kwa ukaribu kwa usalama.</Text>
          </View>
        ) : null}

        {/* ---------- Host ---------- */}
        <View style={{ paddingHorizontal: spacing.xl, paddingTop: spacing.xl }}>
          <Text style={det.sectionTitle}>{t('host_section')}</Text>
          <HostCard host={property.host} rating={property.rating_avg} ratingCount={property.rating_count} />
        </View>

        {/* ---------- Reviews ---------- */}
        <View style={det.section}>
          <Text style={det.sectionTitle}>
            {t('reviews')} {property.rating_count ? `(${property.rating_count})` : ''}
          </Text>
          {reviewsQuery.data?.items.length ? (
            reviewsQuery.data.items.map((r) => (
              <View key={r.id} style={[s.card, { padding: spacing.md, marginBottom: spacing.md }]}>
                <View style={[s.row, { justifyContent: 'space-between' }]}>
                  <View style={s.row}>
                    <Avatar uri={r.reviewer?.avatar_url} name={r.reviewer?.full_name} size={34} />
                    <View style={{ marginLeft: 8 }}>
                      <Text style={{ fontWeight: '800', fontSize: 13 }}>{r.reviewer?.full_name || 'Mwanachama'}</Text>
                      <Text style={typography.tiny}>{timeAgo(r.created_at)}</Text>
                    </View>
                  </View>
                  <RatingStars rating={r.rating} />
                </View>
                {r.comment ? <Text style={[typography.small, { marginTop: 8 }]}>{r.comment}</Text> : null}
              </View>
            ))
          ) : (
            <Text style={typography.small}>Hakuna maoni bado. Kuwa wa kwanza!</Text>
          )}

          {/* write review */}
          {!isOwner ? (
            <View style={[s.card, { padding: spacing.md }]}>
              <Text style={{ fontWeight: '800', fontSize: 13, marginBottom: 8 }}>{t('write_review')}</Text>
              <View style={[s.row, { gap: 4, marginBottom: 8 }]}>
                {[1, 2, 3, 4, 5].map((i) => (
                  <Pressable key={i} onPress={() => setReviewRating(i)} hitSlop={6}>
                    <Ionicons name={i <= reviewRating ? 'star' : 'star-outline'} size={26} color={colors.star} />
                  </Pressable>
                ))}
              </View>
              <View style={{ backgroundColor: colors.blue50, borderRadius: radius.md, borderWidth: 1.2, borderColor: colors.border, padding: 10 }}>
                <TextInput
                  value={reviewText}
                  onChangeText={setReviewText}
                  placeholder="Sema uzoefu wako..."
                  placeholderTextColor={colors.muted}
                  multiline
                  style={{ minHeight: 46, color: colors.text, fontSize: 13.5, textAlignVertical: 'top' }}
                />
              </View>
              <Button
                title={t('send')}
                small
                icon="paper-plane"
                loading={addReview.isPending}
                onPress={submitReview}
                style={{ alignSelf: 'flex-end', marginTop: 8 }}
              />
            </View>
          ) : null}

          {/* report */}
          <Pressable style={[s.row, { gap: 6, alignSelf: 'center', marginTop: spacing.sm }]} onPress={() => setReportOpen(true)}>
            <Ionicons name="flag-outline" size={14} color={colors.muted} />
            <Text style={{ color: colors.muted, fontSize: 12.5, fontWeight: '600' }}>{t('report_listing')}</Text>
          </Pressable>
        </View>
      </ScrollView>

      {/* ---------- Sticky bottom bar ---------- */}
      <View style={[det.bottomBar, { paddingBottom: Platform.OS === 'ios' ? 30 : 16 }]}>
        <View style={{ flex: 1 }}>
          <Text style={{ color: colors.royal, fontWeight: '900', fontSize: 16 }}>{formatTZS(property.price_monthly)}</Text>
          <Text style={{ color: colors.subtext, fontSize: 11, fontWeight: '700' }}>/ mwezi</Text>
        </View>
        <Pressable style={det.roundAction} onPress={onToggleFavorite} hitSlop={4}>
          <Ionicons name={isFav ? 'heart' : 'heart-outline'} size={21} color={isFav ? colors.heart : colors.royal} />
        </Pressable>
        <Pressable style={det.roundAction} onPress={onCall} hitSlop={4}>
          <Ionicons name="call" size={20} color={colors.royal} />
        </Pressable>
        {!isOwner ? (
          <>
            <Button title={t('contact_host')} icon="chatbubble-ellipses" small loading={startingChat} onPress={onMessage} />
            <Button title={t('request_rent')} variant="secondary" small onPress={() => setInquiryOpen(true)} />
          </>
        ) : (
          <Button title={t('host_dashboard')} variant="secondary" small icon="business" onPress={() => nav.navigate('HostDashboard')} />
        )}
      </View>

      {/* modals */}
      <ReportModal visible={reportOpen} onClose={() => setReportOpen(false)} onSubmit={onReport} loading={sendingReport} />
      <InquiryModal
        visible={inquiryOpen}
        onClose={() => setInquiryOpen(false)}
        onSubmit={onInquiry}
        loading={sendingInquiry}
        propertyName={property.title}
      />
    </View>
  );
}

const det = StyleSheet.create({
  topGrad: { position: 'absolute', top: 0, left: 0, right: 0, height: 90 },
  topBar: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 54 : 40,
    left: spacing.xl,
    right: spacing.xl,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  circleBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: 'rgba(10,42,94,0.55)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  popularBadge: { position: 'absolute', bottom: 12, left: spacing.xl },
  section: { paddingHorizontal: spacing.xl, paddingTop: spacing.xl },
  sectionTitle: { fontSize: 16, fontWeight: '800', color: colors.text, marginBottom: spacing.md },
  amenityChip: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.white,
    borderRadius: radius.pill,
    borderWidth: 1.2,
    borderColor: colors.border,
    paddingHorizontal: 12,
    paddingVertical: 7,
  },
  bottomBar: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: colors.white,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: spacing.lg,
    paddingTop: 12,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.border,
  },
  roundAction: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.blue50,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
