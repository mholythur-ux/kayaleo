import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { supabase } from '../services/supabase';
import { profileApi } from '../api';
import type { Profile } from '../types/models';

interface AuthCtx {
  loading: boolean;
  session: boolean;
  profile: Profile | null;
  refreshProfile: () => Promise<void>;
  setProfile: (p: Profile | null) => void;
  signOut: () => Promise<void>;
}

const Ctx = createContext<AuthCtx>({
  loading: true,
  session: false,
  profile: null,
  refreshProfile: async () => {},
  setProfile: () => {},
  signOut: async () => {},
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [loading, setLoading] = useState(true);
  const [session, setSession] = useState(false);
  const [profile, setProfile] = useState<Profile | null>(null);

  const refreshProfile = useCallback(async () => {
    try {
      const { user } = await profileApi.me();
      setProfile(user);
    } catch {
      setProfile(null);
    }
  }, []);

  useEffect(() => {
    supabase.auth
      .getSession()
      .then(({ data }) => {
        setSession(Boolean(data.session));
        if (data.session) refreshProfile();
      })
      .finally(() => setLoading(false));

    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => {
      setSession(Boolean(s));
      if (s) refreshProfile();
      else setProfile(null);
    });
    return () => sub.subscription.unsubscribe();
  }, [refreshProfile]);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setProfile(null);
    setSession(false);
  }, []);

  const value = useMemo(
    () => ({ loading, session, profile, refreshProfile, setProfile, signOut }),
    [loading, session, profile, refreshProfile, signOut]
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  return useContext(Ctx);
}
