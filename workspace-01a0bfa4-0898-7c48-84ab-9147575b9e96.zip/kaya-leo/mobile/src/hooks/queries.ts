import {
  useInfiniteQuery,
  useMutation,
  useQuery,
  useQueryClient,
} from '@tanstack/react-query';
import {
  adminApi,
  conversationsApi,
  favoritesApi,
  getFeatured,
  getRecommendations,
  getProperty,
  hostApi,
  inquiriesApi,
  metaApi,
  profileApi,
  reviewsApi,
  searchProperties,
} from '../api';
import type { SearchFilters } from '../types/models';

export const keys = {
  featured: ['properties', 'featured'] as const,
  recommended: ['properties', 'recommended'] as const,
  property: (id: string) => ['property', id] as const,
  search: (f: SearchFilters) => ['properties', 'search', f] as const,
  favorites: ['favorites'] as const,
  favoriteIds: ['favoriteIds'] as const,
  conversations: ['conversations'] as const,
  messages: (id: string) => ['messages', id] as const,
  me: ['me'] as const,
  reviews: (id: string) => ['reviews', id] as const,
  myInquiries: ['myInquiries'] as const,
  hostDashboard: ['hostDashboard'] as const,
  hostProperties: (status?: string) => ['hostProperties', status ?? 'all'] as const,
  amenities: ['amenities'] as const,
  regions: ['regions'] as const,
  adminStats: ['adminStats'] as const,
  adminListings: (status?: string) => ['adminListings', status ?? 'all'] as const,
  adminUsers: ['adminUsers'] as const,
  adminReports: (status?: string) => ['adminReports', status ?? 'all'] as const,
};

export function useFeatured() {
  return useQuery({ queryKey: keys.featured, queryFn: getFeatured, staleTime: 5 * 60_000 });
}

export function useRecommendations() {
  return useQuery({ queryKey: keys.recommended, queryFn: getRecommendations, staleTime: 5 * 60_000 });
}

export function useProperty(id: string) {
  return useQuery({ queryKey: keys.property(id), queryFn: () => getProperty(id), enabled: Boolean(id) });
}

export function useSearchResults(filters: SearchFilters) {
  return useInfiniteQuery({
    queryKey: keys.search(filters),
    queryFn: ({ pageParam }) => searchProperties({ ...filters, page: pageParam as number }),
    initialPageParam: 1,
    getNextPageParam: (last) => {
      const loaded = last.items.length;
      const has = last.page * last.page_size < last.total;
      return has && loaded > 0 ? last.page + 1 : undefined;
    },
    enabled: true,
  });
}

export function useFavorites(enabled: boolean) {
  return useQuery({ queryKey: keys.favorites, queryFn: favoritesApi.list, enabled });
}

export function useFavoriteIds(enabled: boolean) {
  return useQuery({ queryKey: keys.favoriteIds, queryFn: favoritesApi.ids, enabled, staleTime: 30_000 });
}

export function useToggleFavorite() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ propertyId, favorited }: { propertyId: string; favorited: boolean }) =>
      favorited ? favoritesApi.remove(propertyId) : favoritesApi.add(propertyId),
    onMutate: async ({ propertyId, favorited }) => {
      await qc.cancelQueries({ queryKey: keys.favoriteIds });
      const prev = qc.getQueryData<{ ids: string[] }>(keys.favoriteIds);
      if (prev) {
        const ids = favorited ? prev.ids.filter((i) => i !== propertyId) : [...prev.ids, propertyId];
        qc.setQueryData(keys.favoriteIds, { ids });
      }
      return { prev };
    },
    onError: (_e, _v, ctx) => {
      if (ctx?.prev) qc.setQueryData(keys.favoriteIds, ctx.prev);
    },
    onSettled: () => {
      qc.invalidateQueries({ queryKey: keys.favoriteIds });
      qc.invalidateQueries({ queryKey: keys.favorites });
    },
  });
}

export function useConversations(enabled: boolean) {
  return useQuery({
    queryKey: keys.conversations,
    queryFn: conversationsApi.list,
    enabled,
    refetchInterval: 15_000,
  });
}

export function useMessages(conversationId: string) {
  return useQuery({
    queryKey: keys.messages(conversationId),
    queryFn: () => conversationsApi.messages(conversationId),
    enabled: Boolean(conversationId),
    refetchInterval: 6_000,
  });
}

export function useSendMessage(conversationId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (message: string) => conversationsApi.send(conversationId, message),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: keys.messages(conversationId) });
      qc.invalidateQueries({ queryKey: keys.conversations });
    },
  });
}

export function useAmenities() {
  return useQuery({ queryKey: keys.amenities, queryFn: metaApi.amenities, staleTime: 10 * 60_000 });
}

export function useRegions() {
  return useQuery({ queryKey: keys.regions, queryFn: metaApi.regions, staleTime: 10 * 60_000 });
}

export function useReviews(propertyId: string) {
  return useQuery({ queryKey: keys.reviews(propertyId), queryFn: () => reviewsApi.list(propertyId), enabled: Boolean(propertyId) });
}

export function useAddReview(propertyId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ rating, comment }: { rating: number; comment: string }) =>
      reviewsApi.create(propertyId, rating, comment),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: keys.reviews(propertyId) });
      qc.invalidateQueries({ queryKey: keys.property(propertyId) });
    },
  });
}

export function useMyInquiries(enabled: boolean) {
  return useQuery({ queryKey: keys.myInquiries, queryFn: inquiriesApi.mine, enabled });
}

export function useCreateInquiry(propertyId: string) {
  return useMutation({
    mutationFn: (message: string) => inquiriesApi.create(propertyId, message),
  });
}

export function useHostDashboard(enabled: boolean) {
  return useQuery({ queryKey: keys.hostDashboard, queryFn: hostApi.dashboard, enabled });
}

export function useHostProperties(status?: string) {
  return useQuery({ queryKey: keys.hostProperties(status), queryFn: () => hostApi.properties(status) });
}

export function useAdminStats(enabled: boolean) {
  return useQuery({ queryKey: keys.adminStats, queryFn: adminApi.stats, enabled });
}

export function useAdminListings(status?: string) {
  return useQuery({ queryKey: keys.adminListings(status), queryFn: () => adminApi.listings(status) });
}

export function useAdminUsers(enabled: boolean) {
  return useQuery({ queryKey: keys.adminUsers, queryFn: adminApi.users, enabled });
}

export function useAdminReports(status?: string) {
  return useQuery({ queryKey: keys.adminReports(status), queryFn: () => adminApi.reports(status) });
}

export function useMe(enabled: boolean) {
  return useQuery({ queryKey: keys.me, queryFn: profileApi.me, enabled });
}
