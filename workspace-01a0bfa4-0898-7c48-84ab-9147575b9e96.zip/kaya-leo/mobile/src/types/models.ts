export type Role = 'USER' | 'HOST' | 'ADMIN';
export type PropertyType = 'APARTMENT' | 'HOUSE' | 'ROOM';
export type PropertyStatus = 'draft' | 'pending' | 'approved' | 'rejected' | 'suspended';
export type ImageCategory = 'EXTERIOR' | 'LIVING_ROOM' | 'BEDROOM' | 'BATHROOM' | 'KITCHEN' | 'OTHER';
export type InquiryStatus = 'new' | 'contacted' | 'closed';

export interface Profile {
  id: string;
  full_name: string;
  phone: string | null;
  email: string | null;
  avatar_url: string | null;
  bio: string | null;
  role: Role;
  is_host: boolean;
  is_verified: boolean;
  created_at: string;
  updated_at: string;
}

export interface PropertyImage {
  id: string;
  property_id: string;
  image_url: string;
  storage_path: string | null;
  category: ImageCategory;
  sort_order: number;
  is_cover: boolean;
}

export interface HostInfo {
  id: string;
  full_name: string;
  avatar_url: string | null;
  is_verified: boolean;
  phone: string | null;
  created_at: string;
}

export interface Property {
  id: string;
  host_id: string;
  title: string;
  description: string;
  property_type: PropertyType;
  status: PropertyStatus;
  price_monthly: number;
  price_weekly: number | null;
  price_daily: number | null;
  bedrooms: number;
  bathrooms: number;
  size_m2: number | null;
  floor_number: number | null;
  furnished: boolean;
  max_occupants: number | null;
  house_rules: string | null;
  latitude: number | null;
  longitude: number | null;
  country: string;
  region: string | null;
  city: string | null;
  district: string | null;
  neighborhood: string | null;
  street: string | null;
  landmark: string | null;
  availability_date: string | null;
  is_featured: boolean;
  views_count: number;
  favorites_count: number;
  rejection_reason: string | null;
  created_at: string;
  updated_at: string;
}

export interface PropertyFull extends Property {
  images: PropertyImage[];
  amenities: string[];
  host: HostInfo | null;
  rating_avg: number;
  rating_count: number;
  is_available_now: boolean;
  is_favorite?: boolean;
}

export interface SearchFilters {
  q?: string;
  property_type?: PropertyType;
  min_price?: number;
  max_price?: number;
  bedrooms?: number;
  bathrooms?: number;
  amenities?: string[];
  furnished?: boolean;
  available_now?: boolean;
  region?: string;
  city?: string;
  near_lat?: number;
  near_lng?: number;
  sort?: SortOption;
  page?: number;
  page_size?: number;
}

export type SortOption = 'newest' | 'price_asc' | 'price_desc' | 'distance' | 'recommended';

export interface Paginated<T> {
  items: T[];
  total: number;
  page: number;
  page_size: number;
}

export interface Review {
  id: string;
  property_id: string;
  reviewer_id: string;
  host_id: string;
  rating: number;
  comment: string;
  created_at: string;
  reviewer?: { id: string; full_name: string; avatar_url: string | null } | null;
}

export interface Conversation {
  id: string;
  property_id: string;
  created_at: string;
  updated_at: string;
  property: { id: string; title: string; image_url: string | null; price_monthly: number } | null;
  other_participant: { id: string; full_name: string; avatar_url: string | null } | null;
  last_message: string | null;
  unread_count: number;
}

export interface ChatMessage {
  id: string;
  conversation_id: string;
  sender_id: string;
  message: string;
  read_at: string | null;
  created_at: string;
}

export interface Inquiry {
  id: string;
  property_id: string;
  user_id: string;
  message: string;
  status: InquiryStatus;
  created_at: string;
  property?: { id: string; title: string; image_url: string | null; price_monthly: number } | null;
  user?: { id: string; full_name: string; avatar_url: string | null; phone: string | null } | null;
}

export interface ReportReasonOption {
  id:
    | 'FAKE_PROPERTY'
    | 'WRONG_INFORMATION'
    | 'SCAM_SUSPICIOUS'
    | 'INCORRECT_PRICE'
    | 'ALREADY_UNAVAILABLE'
    | 'INAPPROPRIATE_CONTENT'
    | 'OTHER';
  label: string;
}

export interface LocationHit {
  label: string;
  latitude: number;
  longitude: number;
  country: string | null;
  region: string | null;
  city: string | null;
  district: string | null;
  neighborhood: string | null;
  street: string | null;
  landmark: string | null;
}

export interface HostDashboardStats {
  active_listings: number;
  draft_listings: number;
  pending_listings: number;
  rejected_listings: number;
  suspended_listings: number;
  views: number;
  favorites: number;
  messages: number;
  inquiries: number;
  total_listings: number;
}

export interface AdminStats {
  total_users: number;
  total_hosts: number;
  total_properties: number;
  pending_listings: number;
  approved_listings: number;
  rejected_listings: number;
  suspended_listings: number;
  open_reports: number;
}

/** Draft property being built by the host wizard (steps 1–9). */
export interface ListingDraft {
  property_type: PropertyType | null;
  title: string;
  description: string;
  bedrooms: number;
  bathrooms: number;
  size_m2: string;
  floor_number: string;
  furnished: boolean;
  max_occupants: string;
  house_rules: string;
  amenities: string[];
  photos: Array<{ uri: string; category: ImageCategory; isCover: boolean }>;
  price_monthly: string;
  price_weekly: string;
  price_daily: string;
  availability: 'now' | 'date';
  availability_date: string;
  location: {
    latitude: number | null;
    longitude: number | null;
    region: string;
    city: string;
    district: string;
    neighborhood: string;
    street: string;
    landmark: string;
  };
}

export function emptyDraft(): ListingDraft {
  return {
    property_type: null,
    title: '',
    description: '',
    bedrooms: 1,
    bathrooms: 1,
    size_m2: '',
    floor_number: '',
    furnished: false,
    max_occupants: '',
    house_rules: '',
    amenities: [],
    photos: [],
    price_monthly: '',
    price_weekly: '',
    price_daily: '',
    availability: 'now',
    availability_date: '',
    location: {
      latitude: null,
      longitude: null,
      region: '',
      city: '',
      district: '',
      neighborhood: '',
      street: '',
      landmark: '',
    },
  };
}

export const PROPERTY_TYPE_LABELS: Record<PropertyType, { sw: string; en: string }> = {
  APARTMENT: { sw: 'Ghorofa', en: 'Apartment' },
  HOUSE: { sw: 'Nyumba', en: 'House' },
  ROOM: { sw: 'Chumba', en: 'Room' },
};

export const IMAGE_CATEGORIES: ImageCategory[] = [
  'EXTERIOR',
  'LIVING_ROOM',
  'BEDROOM',
  'BATHROOM',
  'KITCHEN',
  'OTHER',
];
