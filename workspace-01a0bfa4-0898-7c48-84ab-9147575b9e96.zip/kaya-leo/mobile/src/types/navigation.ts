import type { PropertyType, PropertyFull } from './models';

export type RootStackParamList = {
  Welcome: undefined;
  Login: undefined;
  SignUp: undefined;
  MainTabs: undefined;
  PropertyDetails: { propertyId: string };
  CategoryListings: { mode: 'featured' | 'recommended' | 'type'; propertyType?: PropertyType; title: string };
  Search: { initialQuery?: string } | undefined;
  Chat: { conversationId: string };
  EditProfile: undefined;
  Settings: undefined;
  HelpSupport: undefined;
  TermsPrivacy: undefined;
  MyInquiries: undefined;
  MyReviews: undefined;
  HostOnboarding: { property?: PropertyFull } | undefined;
  HostDashboard: undefined;
  LocationPicker: { initial?: { latitude: number; longitude: number } | null } | undefined;
  AdminDashboard: undefined;
  AdminListings: { status?: string } | undefined;
  AdminUsers: undefined;
  AdminReports: undefined;
};

export type MainTabParamList = {
  HomeTab: undefined;
  SearchTab: { initialQuery?: string } | undefined;
  FavoritesTab: undefined;
  MessagesTab: undefined;
  ProfileTab: undefined;
};
