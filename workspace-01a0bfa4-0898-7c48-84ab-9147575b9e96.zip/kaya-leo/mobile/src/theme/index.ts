import { StyleSheet, Platform, ViewStyle } from 'react-native';

/**
 * Kaya Leo design system — blue + white.
 * Deep navy → royal blue → bright blue → sky → very light blue backgrounds.
 */
export const colors = {
  navy: '#0A2A5E',
  navy800: '#123A78',
  royal: '#1D4ED8',
  blue: '#2563EB',
  bright: '#3B82F6',
  sky: '#7EB2FF',
  skyLight: '#DBEAFE',
  blue50: '#EFF6FF',
  bg: '#F4F8FE',
  white: '#FFFFFF',
  text: '#0F172A',
  subtext: '#5B6B84',
  muted: '#8A99B3',
  border: '#E3EBF7',
  heart: '#EF4444',
  success: '#0E9F6E',
  warning: '#D97706',
  danger: '#DC2626',
  star: '#F5A623',
};

export const spacing = { xs: 4, sm: 8, md: 12, lg: 16, xl: 20, xxl: 28, xxxl: 40 } as const;

export const radius = { sm: 8, md: 12, lg: 16, xl: 22, pill: 999 } as const;

export const typography = {
  hero: { fontSize: 30, fontWeight: '800' as const, color: colors.white, letterSpacing: -0.5 },
  title: { fontSize: 20, fontWeight: '800' as const, color: colors.text },
  h2: { fontSize: 17, fontWeight: '700' as const, color: colors.text },
  body: { fontSize: 15, fontWeight: '400' as const, color: colors.text },
  small: { fontSize: 13, color: colors.subtext },
  tiny: { fontSize: 11, color: colors.muted },
};

export const shadowCard: ViewStyle =
  Platform.select({
    ios: { shadowColor: colors.navy, shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.08, shadowRadius: 14 },
    android: { elevation: 3 },
    default: {},
  }) || {};

export const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.white,
    borderRadius: radius.lg,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    ...shadowCard,
  },
  row: { flexDirection: 'row', alignItems: 'center' },
  screen: { flex: 1, backgroundColor: colors.bg },
});

export const theme = { colors, spacing, radius, typography, styles };
