import React from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing } from '../theme';
import { useT } from '../i18n';
import { useConversations } from '../hooks/queries';
import { useAuth } from '../state/AuthContext';
import type { MainTabParamList } from '../types/navigation';

import HomeScreen from '../screens/Home/HomeScreen';
import SearchScreen from '../screens/Search/SearchScreen';
import FavoritesScreen from '../screens/Favorites/FavoritesScreen';
import ConversationsScreen from '../screens/Messages/ConversationsScreen';
import ProfileScreen from '../screens/Profile/ProfileScreen';

const Tab = createBottomTabNavigator<MainTabParamList>();

function TabIcon({ name, focused, badge }: { name: keyof typeof Ionicons.glyphMap; focused: boolean; badge?: number }) {
  return (
    <View style={tab.iconWrap}>
      <Ionicons name={name} size={22} color={focused ? colors.royal : '#7C8DA6'} />
      {focused ? <View style={tab.indicator} /> : null}
      {badge && badge > 0 ? (
        <View style={tab.badge}>
          <View style={tab.badgeInner} />
        </View>
      ) : null}
    </View>
  );
}

export function BottomTabs() {
  const { t } = useT();
  const { session } = useAuth();
  const { data: convs } = useConversations(session);
  const unread = (convs?.items || []).reduce((sum, c) => sum + (c.unread_count > 0 ? 1 : 0), 0);

  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.royal,
        tabBarInactiveTintColor: '#7C8DA6',
        tabBarLabelStyle: { fontSize: 11, fontWeight: '700', marginTop: 0 },
        tabBarStyle: {
          height: Platform.OS === 'ios' ? 86 : 64,
          paddingTop: 6,
          paddingBottom: Platform.OS === 'ios' ? 26 : 8,
          backgroundColor: colors.white,
          borderTopColor: colors.border,
        },
      }}
    >
      <Tab.Screen
        name="HomeTab"
        component={HomeScreen}
        options={{
          title: t('tab_home'),
          tabBarIcon: ({ focused }) => <TabIcon name="home" focused={focused} />,
        }}
      />
      <Tab.Screen
        name="SearchTab"
        component={SearchScreen}
        options={{
          title: t('tab_search'),
          tabBarIcon: ({ focused }) => <TabIcon name="search" focused={focused} />,
        }}
      />
      <Tab.Screen
        name="FavoritesTab"
        component={FavoritesScreen}
        options={{
          title: t('tab_favorites'),
          tabBarIcon: ({ focused }) => <TabIcon name="heart" focused={focused} />,
        }}
      />
      <Tab.Screen
        name="MessagesTab"
        component={ConversationsScreen}
        options={{
          title: t('tab_messages'),
          tabBarIcon: ({ focused }) => <TabIcon name="chatbubble-ellipses" focused={focused} badge={unread} />,
        }}
      />
      <Tab.Screen
        name="ProfileTab"
        component={ProfileScreen}
        options={{
          title: t('tab_profile'),
          tabBarIcon: ({ focused }) => <TabIcon name="person" focused={focused} />,
        }}
      />
    </Tab.Navigator>
  );
}

const tab = StyleSheet.create({
  iconWrap: { alignItems: 'center', justifyContent: 'center', width: 44, height: 30 },
  indicator: {
    position: 'absolute',
    top: -6,
    width: 18,
    height: 3,
    borderRadius: 2,
    backgroundColor: colors.royal,
  },
  badge: { position: 'absolute', top: -2, right: 4 },
  badgeInner: {
    width: 9,
    height: 9,
    borderRadius: 5,
    backgroundColor: colors.heart,
    borderWidth: 1.5,
    borderColor: colors.white,
  },
});
