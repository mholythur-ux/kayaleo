import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useAuth } from '../state/AuthContext';
import type { RootStackParamList } from '../types/navigation';

import WelcomeScreen from '../screens/Auth/WelcomeScreen';
import LoginScreen from '../screens/Auth/LoginScreen';
import SignUpScreen from '../screens/Auth/SignUpScreen';
import { BottomTabs } from './BottomTabs';
import PropertyDetailsScreen from '../screens/PropertyDetails/PropertyDetailsScreen';
import CategoryListingsScreen from '../screens/Category/CategoryListingsScreen';
import SearchScreen from '../screens/Search/SearchScreen';
import ChatScreen from '../screens/Messages/ChatScreen';
import EditProfileScreen from '../screens/Profile/EditProfileScreen';
import SettingsScreen from '../screens/Profile/SettingsScreen';
import HelpSupportScreen from '../screens/Profile/HelpSupportScreen';
import TermsPrivacyScreen from '../screens/Profile/TermsPrivacyScreen';
import MyInquiriesScreen from '../screens/Profile/MyInquiriesScreen';
import MyReviewsScreen from '../screens/Profile/MyReviewsScreen';
import HostOnboardingScreen from '../screens/Host/HostOnboardingScreen';
import HostDashboardScreen from '../screens/Host/HostDashboardScreen';
import AdminDashboardScreen from '../screens/Admin/AdminDashboardScreen';
import AdminListingsScreen from '../screens/Admin/AdminListingsScreen';
import AdminUsersScreen from '../screens/Admin/AdminUsersScreen';
import AdminReportsScreen from '../screens/Admin/AdminReportsScreen';

const Stack = createNativeStackNavigator<RootStackParamList>();

export function RootNavigator() {
  const { session } = useAuth();
  return (
    <Stack.Navigator screenOptions={{ headerShown: false, animation: 'slide_from_right' }}>
      {!session ? (
        <>
          <Stack.Screen name="Welcome" component={WelcomeScreen} />
          <Stack.Screen name="Login" component={LoginScreen} options={{ animation: 'slide_from_bottom' }} />
          <Stack.Screen name="SignUp" component={SignUpScreen} options={{ animation: 'slide_from_bottom' }} />
        </>
      ) : (
        <>
          <Stack.Screen name="MainTabs" component={BottomTabs} />
          <Stack.Screen
            name="PropertyDetails"
            component={PropertyDetailsScreen}
            options={{ headerShown: false, animation: 'slide_from_bottom' }}
          />
          <Stack.Screen name="CategoryListings" component={CategoryListingsScreen} />
          <Stack.Screen name="Search" component={SearchScreen} />
          <Stack.Screen name="Chat" component={ChatScreen} />
          <Stack.Screen name="EditProfile" component={EditProfileScreen} />
          <Stack.Screen name="Settings" component={SettingsScreen} />
          <Stack.Screen name="HelpSupport" component={HelpSupportScreen} />
          <Stack.Screen name="TermsPrivacy" component={TermsPrivacyScreen} />
          <Stack.Screen name="MyInquiries" component={MyInquiriesScreen} />
          <Stack.Screen name="MyReviews" component={MyReviewsScreen} />
          <Stack.Screen name="HostOnboarding" component={HostOnboardingScreen} options={{ animation: 'slide_from_bottom' }} />
          <Stack.Screen name="HostDashboard" component={HostDashboardScreen} />
          <Stack.Screen name="AdminDashboard" component={AdminDashboardScreen} />
          <Stack.Screen name="AdminListings" component={AdminListingsScreen} />
          <Stack.Screen name="AdminUsers" component={AdminUsersScreen} />
          <Stack.Screen name="AdminReports" component={AdminReportsScreen} />
        </>
      )}
    </Stack.Navigator>
  );
}
