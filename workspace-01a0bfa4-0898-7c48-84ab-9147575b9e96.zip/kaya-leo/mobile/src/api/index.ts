import { api } from '../services/apiClient';
import type {
  AdminStats,
  Conversation,
  HostDashboardStats,
  Inquiry,
  Paginated,
  Profile,
  PropertyFull,
  Review,
  SearchFilters,
} from '../types/models';

// ---------- properties / search ----------
export async function searchProperties(filters: SearchFilters, signal?: AbortSignal): Promise<Paginated<PropertyFull>> {
  const qs = new URLSearchParams();
  Object.entries(filters).forEach(([k, v]) => {
    if (v === undefined || v === null || v === '') return;
    if (Array.isArray(v)) {
      if (v.length) qs.set(k, v.join(','));
    } else if (typeof v === 'boolean') {
      qs.set(k, String(v));
    } else {
      qs.set(k, String(v));
    }
  });
  return api(`/properties?${qs.toString()}`, { signal });
}

export async function getProperty(id: string): Promise<{ property: PropertyFull }> {
  return api(`/properties/${id}`);
}

export async function registerView(id: string): Promise<void> {
  api(`/properties/${id}/view`, { method: 'POST', body: {} }).catch(() => {});
}

export async function getFeatured(): Promise<Paginated<PropertyFull>> {
  return api('/properties?sort=recommended&page_size=10');
}

export async function getRecommendations(): Promise<Paginated<PropertyFull>> {
  return api('/properties?sort=newest&page_size=10');
}

// ---------- favorites ----------
export const favoritesApi = {
  list: () => api<{ items: PropertyFull[]; total: number }>('/favorites'),
  ids: () => api<{ ids: string[] }>('/favorites/ids'),
  add: (propertyId: string) => api<{ is_favorite: boolean }>(`/favorites/${propertyId}`, { method: 'POST', body: {} }),
  remove: (propertyId: string) => api<{ is_favorite: boolean }>(`/favorites/${propertyId}`, { method: 'DELETE' }),
};

// ---------- conversations ----------
export const conversationsApi = {
  list: () => api<{ items: Conversation[]; total: number }>('/conversations'),
  start: (propertyId: string) =>
    api<{ conversation_id: string }>(`/conversations`, { method: 'POST', body: { property_id: propertyId } }),
  messages: (conversationId: string) =>
    api<{ messages: import('../types/models').ChatMessage[]; property: Conversation['property'] }>(
      `/conversations/${conversationId}/messages`
    ),
  send: (conversationId: string, message: string) =>
    api<{ message: import('../types/models').ChatMessage }>(`/conversations/${conversationId}/messages`, {
      method: 'POST',
      body: { message },
    }),
};

// ---------- profile ----------
export const profileApi = {
  me: () => api<{ user: Profile }>('/users/me'),
  update: (patch: Partial<Profile>) => api<{ user: Profile }>('/users/me', { method: 'PUT', body: patch }),
};

// ---------- host ----------
export const hostApi = {
  apply: (input: { full_name: string; phone: string; email: string }) =>
    api<{ user: Profile; message: string }>('/host/apply', { method: 'POST', body: input }),
  dashboard: () => api<{ stats: HostDashboardStats; inquiries: Inquiry[] }>('/host/dashboard'),
  properties: (status?: string) =>
    api<{ items: PropertyFull[]; total: number }>(`/host/properties${status ? `?status=${status}` : ''}`),
  create: (body: Record<string, unknown>) => api<{ property: PropertyFull; message: string }>('/properties', { method: 'POST', body }),
  update: (id: string, body: Record<string, unknown>) =>
    api<{ property: PropertyFull }>(`/properties/${id}`, { method: 'PUT', body }),
  remove: (id: string) => api<{ message: string }>(`/properties/${id}`, { method: 'DELETE' }),
  publish: (id: string) => api<{ property: PropertyFull; message: string }>(`/properties/${id}/publish`, { method: 'POST', body: {} }),
  pause: (id: string) => api<{ property: PropertyFull; message: string }>(`/properties/${id}/pause`, { method: 'POST', body: {} }),
  replaceImages: (id: string, images: Array<Record<string, unknown>>) =>
    api<{ property: PropertyFull }>(`/properties/${id}/images`, { method: 'POST', body: { images } }),
};

// ---------- reviews / inquiries / reports ----------
export const reviewsApi = {
  list: (propertyId: string) => api<{ items: Review[]; total: number }>(`/properties/${propertyId}/reviews`),
  mine: () => api<{ items: Review[]; total: number }>('/reviews/mine'),
  create: (propertyId: string, rating: number, comment: string) =>
    api<{ review: Review; message: string }>(`/properties/${propertyId}/reviews`, {
      method: 'POST',
      body: { rating, comment },
    }),
};

export const inquiriesApi = {
  create: (propertyId: string, message: string) =>
    api<{ inquiry: Inquiry; message: string }>(`/properties/${propertyId}/inquiries`, { method: 'POST', body: { message } }),
  mine: () => api<{ items: Inquiry[]; total: number }>('/inquiries/mine'),
  setStatus: (id: string, status: string) =>
    api<{ inquiry: Inquiry }>(`/inquiries/${id}/status`, { method: 'PUT', body: { status } }),
};

export const reportsApi = {
  create: (propertyId: string, reason: string, details: string) =>
    api<{ report: unknown; message: string }>(`/properties/${propertyId}/report`, {
      method: 'POST',
      body: { reason, details },
    }),
};

// ---------- meta ----------
export const metaApi = {
  amenities: () => api<{ items: Array<{ id: string; name: string }> }>('/amenities'),
  regions: () =>
    api<{ regions: Array<{ region: string; districts: string[] }>; neighborhoods: string[] }>('/location/regions'),
  locationSearch: (q: string) =>
    api<{ items: Array<import('../types/models').LocationHit> }>(`/location/search?q=${encodeURIComponent(q)}`),
  locationReverse: (lat: number, lng: number) =>
    api<{ item: import('../types/models').LocationHit | null }>(`/location/reverse?lat=${lat}&lng=${lng}`),
};

// ---------- admin ----------
export const adminApi = {
  stats: () => api<{ stats: AdminStats }>('/admin/stats'),
  listings: (status?: string) => api<{ items: PropertyFull[]; total: number }>(`/admin/properties${status ? `?status=${status}` : ''}`),
  moderate: (id: string, action: 'approve' | 'reject' | 'suspend' | 'request_changes', reason?: string) =>
    api<{ property: PropertyFull; message: string }>(`/admin/properties/${id}/moderate`, {
      method: 'POST',
      body: { action, reason },
    }),
  removeListing: (id: string) => api<{ message: string }>(`/admin/properties/${id}`, { method: 'DELETE' }),
  users: () => api<{ items: Profile[]; total: number }>('/admin/users'),
  setUserVerified: (id: string, is_verified: boolean) =>
    api<{ user: Profile; message: string }>(`/admin/users/${id}/verified`, { method: 'PUT', body: { is_verified } }),
  setUserRole: (id: string, role: string) =>
    api<{ user: Profile }>(`/admin/users/${id}/role`, { method: 'PUT', body: { role } }),
  reports: (status?: string) => api<{ items: Array<Record<string, unknown>>; total: number }>(`/admin/reports${status ? `?status=${status}` : ''}`),
  setReportStatus: (id: string, status: string) =>
    api<{ report: unknown }>(`/admin/reports/${id}/status`, { method: 'PUT', body: { status } }),
};
