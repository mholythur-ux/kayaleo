import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';

const url = process.env.EXPO_PUBLIC_SUPABASE_URL || '';
const anonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || '';

if (!url || !anonKey) {
  // eslint-disable-next-line no-console
  console.warn(
    '[KayaLeo] EXPO_PUBLIC_SUPABASE_URL / EXPO_PUBLIC_SUPABASE_ANON_KEY hazijawekwa. ' +
      'Copy mobile/.env.example to mobile/.env and fill in your Supabase project keys.'
  );
}

/** Supabase client used for AUTH + STORAGE (uploads) from the app.
 *  Only the anon key lives here — the service-role key stays on the server. */
export const supabase = createClient(url || 'https://placeholder.supabase.co', anonKey || 'placeholder-anon-key', {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

/** Upload a local file (uri) to a Supabase Storage bucket. Returns { url, path }. */
export async function uploadToBucket(
  bucket: 'avatars' | 'property-images',
  localUri: string,
  fileName: string,
  contentType = 'image/jpeg'
): Promise<{ url: string; path: string }> {
  const { data: sessionData } = await supabase.auth.getSession();
  const uid = sessionData.session?.user.id;
  if (!uid) throw new Error('Ingia kwanza.');
  const path = `${uid}/${Date.now()}-${fileName}`;
  const res = await fetch(localUri);
  const arraybuffer = await res.arrayBuffer();
  const { error } = await supabase.storage
    .from(bucket)
    .upload(path, arraybuffer, { contentType, upsert: false });
  if (error) throw new Error(error.message);
  const { data } = supabase.storage.from(bucket).getPublicUrl(path);
  return { url: data.publicUrl, path };
}
